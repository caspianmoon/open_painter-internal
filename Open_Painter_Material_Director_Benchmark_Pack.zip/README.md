# Open Painter Material Director benchmark pack

Read `Open_Painter_Material_Director_Test_Plan.md` first. `test_cases.json` contains the exact six model source pages, eight case prompts, follow-up prompts, modes and acceptance checks. `Run_Report_Template.md` is an unfilled evidence template.

This pack contains a plan and manifests only. It does not contain downloaded model files, prepared Blender fixtures, a runnable test harness, generated textures, or completed scores. All live tests are NOT RUN.

## Execution direction for the local test operator or coding agent

Execute this specification against the recorded local Open Painter build. Prepare and hash the six neutral asset fixtures and combined scene without reusing original texture/mask data. Run every scheduled use case through Material Director's real UI and live provider, first capturing the initial result and then the two fixed refinements. Keep generated-texture-off and generated-texture-allowed modes separate. Preserve all failures, validate independent edits, undo, offline reopening and baked handoff, and assemble the report with human visual ratings. Do not replace the AI with hand-authored proposals, hand-texture failed cases, fix product code halfway through, invent scores, or call unexecuted checks passed. Clearly report any inaccessible dependency or missing capability.
