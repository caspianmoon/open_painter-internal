# Material Director: run report

**Status:** NOT RUN  
**Run ID:**  
**Case / mode / repeat:**  
**Open Painter commit, Blender, hardware and evaluator:**  
**Provider, exact model ID, runtime and generation availability:**  
**Fixture and reference checksums:**  
**Started / completed / elapsed / active operator time:**  

## Input integrity

Record UV/geometry checks, original-image removal, source material boundaries, geometry-map freshness, exact scope, input cameras, sharing manifest, optional reference and any setup assistance. Unassisted and ASSISTED runs must not be pooled.

## Stage results

| Stage | Applied to actual model? | Visible result complete? | Elapsed time | Evidence | Outcome |
|---|---|---|---|---|---|
| Create | NOT RUN | NOT RUN | | | NOT RUN |
| Refine 1 | NOT RUN | NOT RUN | | | NOT RUN |
| Refine 2 | NOT RUN | NOT RUN | | | NOT RUN |
| Independent editability probes | NOT RUN | NOT RUN | | | NOT RUN |
| Undo to Refine 1 | NOT RUN | NOT RUN | | | NOT RUN |
| Offline save/reopen | NOT RUN | NOT RUN | | | NOT RUN |
| Export/reimport | NOT RUN | NOT RUN | | | NOT RUN |
| Fixed 4K repeat-1 check, where scheduled | NOT RUN | NOT RUN | | | NOT RUN |

## Case acceptance checks

Copy the five acceptance checks from the manifest. Give PASS, FAIL, BLOCKED or NOT RUN, with an evidence link. Do not leave an unsupported instruction marked PASS because the request ended without an exception.

## Scores

| Dimension | Reviewer 1 /5 | Reviewer 2 /5 | Reviewer 3 /5 | Median /5 | Weight | Weighted points |
|---|---:|---:|---:|---:|---:|---:|
| Material appearance | | | | | 25 | |
| Brief compliance | | | | | 20 | |
| Spatial placement | | | | | 20 | |
| Editable structure | | | | | 15 | |
| Refinement fidelity | | | | | 10 | |
| Handoff integrity | | | | | 10 | |

Weighted points = median rating / 5 x weight. Report the total only when the required evidence exists. Record visual scores for Create and both revisions separately; do not let the final score overwrite first-pass failure.

## Preservation and handoff

List changed and protected sets/components, semantic-state differences, buffer differences, mask overlap/placement checks, texture packing, normal conventions, export settings and any engine checks. An ordinary Blender reimport is not proof of Unreal or Unity compatibility.

## Failure or limitation

Category, earliest evidenced failure point, prompt/tool trace, reproducible steps, user-visible effect, hard-failure status, assisted-diagnostic result if performed, and what remains uncertain.

## Decision

Final score: NOT SCORED  
Binary acceptance checks: NOT RUN  
Hard failure: UNKNOWN  
Core delivery result: NOT RUN  
Safety result, if applicable: NOT RUN  
Comparison against matched no-AI baseline: NOT RUN  
Measured cost: UNKNOWN  

Do not publish a claim of live AI success from this empty template.
