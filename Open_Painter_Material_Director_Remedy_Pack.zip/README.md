# Material Director remedy bundle

Reviewed branch: task/open-graph-0.4.0
Reviewed commit: 2a9ff0d37daf3997b5b5817bc2744d358d8c1b0e

Contents:
- Open_Painter_Material_Director_Capability_Remedy.md: source-grounded implementation specification.
- test_director_quality_gate_regressions.py: tests importing a local checkout's real scoring module. Syntax-checked only here; not run against the repository. Some intentionally fail before the remedy.
- gallery_metadata_audit.json: parsed facts from the uploaded HTML. It does not verify unavailable external PNGs.

Run regression specifications from a machine with the checkout:

    python test_director_quality_gate_regressions.py --repo /path/to/open_painter

No live AI test outputs, replacement textures, recovered PNGs, or modified repository code are included.
