# Sources and license

Both source pages list CC0 1.0 Universal. Creator: GGBotNet.

## Soviet Assault Rifle 3D

Source: https://opengameart.org/content/ak-47-3d
Archive: https://opengameart.org/sites/default/files/soviet_assault_rifle_3d.zip

## SMG-10 3D

Source: https://opengameart.org/content/smg-10-3d
Archive: https://opengameart.org/sites/default/files/smg-10_3d.zip

License reference: https://creativecommons.org/publicdomain/zero/1.0/

Original model bytes are preserved; this builder does not prepare UVs, texture models or run Blender.
