# Open Painter: two-weapon texturing test

## Goal
Can Material Director texture a real game weapon convincingly from a short art-direction prompt?

## Models
Use the included assault rifle and SMG. Test them separately. The original downloads are also preserved in `sources/`.
These are source assets, not prepared benchmark scenes. UVs and Blender compatibility still need preflight verification.

## Prepare once, before the AI test
Import only each weapon's meshes into a fresh file. Preserve geometry, usable UVs and existing material boundaries; use neutral materials and neutral part names. If UVs need preparation, do that once and record it before freezing the starting file. Do not invent material-region masks for Director.
Use the existing fixed **Eevee** harness. No Cycles. Keep cameras, lights, World, resolution, exposure and render settings unchanged throughout. Check that the neutral model is visible before running any AI prompt.
Keep the selected AI model and generated-texture setting identical for both weapons. Generated surface textures are enabled for this test; record whether they actually get generated and assigned.

## Run the same three prompts on each weapon
Start a fresh Director conversation from that weapon's neutral file.

**1. Create**
> Texture this like it belongs in a realistic post-apocalyptic game.

**2. Refine the existing result**
> This doesn't look realistic enough. Improve it.

**3. Refine it again**
> Make it look like it was textured by a professional game artist. Remove anything that looks obviously procedural or artificial.

Do not add material recipes, roughness values, rust instructions or semantic masks to these prompts. Material interpretation and art direction are the capabilities under test. Do not restart between the three prompts or manually repair the AI material. These follow-ups are a fixed challenge, not a claim that each previous result is necessarily bad.

## Save the evidence
Save neutral, initial, refinement 1 and refinement 2 as separate `.blend` checkpoints. At each checkpoint, capture the same fixed Eevee front, back, left, right and close-up views. Keep the prompts, responses and errors with the images. Package the actual images with the gallery, not just relative links in a lone HTML file.
If Create applies nothing, record `NO_MATERIAL_APPLIED`, preserve the response and capture the failure state when possible. Mark later turns `SKIPPED_AFTER_CREATE_FAILURE`. A failed screenshot is `CAPTURE_FAILED`, not an artistic result or a successful test.

## Review side by side
For each weapon, compare the initial material with both revisions. Judge appearance, believable material separation, placement of wear/detail, art-direction fit and whether each revision helped or harmed the result. Check that material components remain independently editable.
Ask: **Would I use this in a realistic game without manually retexturing it?** Record yes/no and a short explanation. No named reviewer or custom human-authored reference file is required to run this development test. Keep unreviewed results unscored.
The two weapons can share a palette and surface sources. That is not a failure. Look for geometry-appropriate placement and scale, rather than demanding different materials everywhere.
