"""Native Blender 5.2 texture brush assets and unified settings."""

import bpy


def ensure_brush(context):
    paint = context.scene.tool_settings.image_paint
    if paint.brush is None:
        bpy.ops.brush.asset_activate(
            asset_library_type="ESSENTIALS",
            relative_asset_identifier="brushes/essentials_brushes-mesh_texture.blend/Brush/Paint Hard",
        )
    if paint.brush is None:
        raise ValueError("Choose a Texture Paint brush from Blender’s asset shelf.")
    return paint.brush


def draw(layout, context):
    paint = context.scene.tool_settings.image_paint
    brush = paint.brush
    if not brush:
        layout.label(text="Enter Paint to load a brush.")
        return
    unified = paint.unified_paint_settings
    for key, toggle in (
        ("size", "use_unified_size"),
        ("strength", "use_unified_strength"),
        ("color", "use_unified_color"),
    ):
        layout.prop(unified if getattr(unified, toggle, False) else brush, key)
    layout.prop(brush, "spacing")
    layout.template_ID(brush, "texture", new="texture.new")
