"""Native paint canvas selection and debounced raster change detection."""

from time import monotonic
from zlib import crc32

import bpy

from ..core.image_manager import pixels
from ..core.layer_stack import active
from .brush_bridge import ensure_brush
from .channel_paint import mark_changed, target

_checks = {}


def begin(context: bpy.types.Context, ts, channel: str, mask: bool = False) -> bpy.types.Image:
    layer = active(ts)
    if layer is None:
        raise ValueError("Select a paint layer or painted mask first.")
    obj = context.object
    assigned = {r.object for r in ts.assignments if r.object}
    if obj not in assigned:
        obj = next(iter(assigned), None)
    if obj is None:
        raise ValueError("Assign a UV-unwrapped mesh to this texture set first.")
    if not obj.data.uv_layers:
        raise ValueError(f"No UV map found on {obj.name}.")
    image = target(ts, layer, channel, mask)
    if context.object and context.object.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    context.view_layer.objects.active = obj
    obj.select_set(True)
    obj.active_material_index = next(r.slot_index for r in ts.assignments if r.object == obj)
    paint = context.scene.tool_settings.image_paint
    paint.mode = "IMAGE"
    paint.canvas = image
    bpy.ops.object.mode_set(mode="TEXTURE_PAINT")
    ensure_brush(context)
    project = context.scene.open_painter
    project.paint_image = image
    project.paint_set_id = ts.id
    project.paint_layer_id = layer.id
    project.paint_channel = channel
    project.paint_mask = mask
    _checks[context.scene.as_pointer()] = (monotonic(), crc32(pixels(image)))
    for area in context.screen.areas if context.screen else []:
        if area.type == "IMAGE_EDITOR":
            area.spaces.active.image = image
        if area.type == "VIEW_3D":
            area.spaces.active.shading.type = "MATERIAL"
    return image


def detect(scene: bpy.types.Scene, force: bool = False) -> bool:
    project = scene.open_painter
    image = project.paint_image
    if not image:
        return False
    key = scene.as_pointer()
    now = monotonic()
    last, checksum = _checks.get(key, (0, None))
    if not force and (now - last < 0.75 or not image.is_dirty):
        return False
    current = crc32(pixels(image))
    _checks[key] = (now, current)
    if current == checksum:
        return False
    ts = next((s for s in project.texture_sets if s.id == project.paint_set_id), None)
    layer = (
        next((item for item in ts.layers if item.id == project.paint_layer_id), None)
        if ts
        else None
    )
    if layer:
        mark_changed(ts, layer, project.paint_channel, project.paint_mask)
        return True
    return False


def reset():
    _checks.clear()
