import bpy

from ..constants import CHANNEL_ITEMS
from .texture_set import OP_TextureSet


class OP_Project(bpy.types.PropertyGroup):
    id: bpy.props.StringProperty()
    format_version: bpy.props.IntProperty(default=1)
    texture_sets: bpy.props.CollectionProperty(type=OP_TextureSet)
    active_texture_set: bpy.props.IntProperty(default=0)
    status: bpy.props.StringProperty()
    paint_image: bpy.props.PointerProperty(type=bpy.types.Image)
    paint_set_id: bpy.props.StringProperty()
    paint_layer_id: bpy.props.StringProperty()
    paint_channel: bpy.props.EnumProperty(name="Channel", items=CHANNEL_ITEMS, default="ROUGHNESS")
    paint_mask: bpy.props.BoolProperty()
