"""Substance-style Assets / Viewport / Texture Sets / Layers / Properties docks."""

from time import monotonic

import bpy
import gpu

from ...constants import CHANNEL_LABELS
from ...core.layer_stack import active, channel_for
from ...core.project_manager import active_set
from . import assets, state
from . import drawing as d


class Canvas:
    def __init__(self, context):
        d.sync_theme(context)
        self.context = context
        self.state = state.get(context.area)
        self.scale = context.preferences.system.ui_scale
        self.w = context.region.width / self.scale
        inset = sum(
            r.height
            for r in context.area.regions
            if r.type in {"HEADER", "TOOL_HEADER"} and r.height > 1
        )
        self.h = (context.region.height - inset) / self.scale
        self.left = min(248, max(190, self.w * 0.19))
        self.right = min(346, max(286, self.w * 0.25))
        self.state.hits = []
        self.clip = None
        self.state.width = context.region.width
        self.state.height = self.h * self.scale
        self.state.left = self.left * self.scale
        self.state.right = self.right * self.scale
        self.state.ui_scale = self.scale

    def rect(self, x, y, w, h, color):
        s = self.scale
        d.rect(x * s, y * s, w * s, h * s, color)

    def text(self, value, x, y, size=11, color=None, width=None):
        s = self.scale
        d.text(
            value, x * s, y * s, size * d.FONT_SIZE / 11 * s, color, width * s if width else None
        )

    def widget(self, x, y, w, h, kind="regular", selected=False, hover=False):
        s = self.scale
        d.widget(x * s, y * s, w * s, h * s, kind, selected, hover)

    def hit(self, x, y, w, h, action, payload=None):
        if self.clip:
            low, high = self.clip
            high_y = min(y + h, high)
            y = max(y, low)
            h = high_y - y
            if h <= 0:
                return
        s = self.scale
        self.state.hits.append((x * s, y * s, w * s, h * s, action, payload))

    def button(self, label, x, y, w, h, action, payload=None, selected=False):
        hover = self.state.hover == (action, payload)
        self.widget(x, y, w, h, selected=selected, hover=hover)
        color = d.WIDGETS["regular"]["text_sel" if selected else "text"]
        width = d.text_width(label, d.FONT_SIZE * self.scale) / self.scale
        self.text(label, x + max(4, (w - width) / 2), y + (h - 11) / 2 + 1, 11, color, w - 8)
        self.hit(x, y, w, h, action, payload)

    def header(self, label, x, y, w, detail=""):
        self.rect(x, y, w, 29, d.HEADER)
        self.text(label.title(), x + 12, y + 10, 11)
        self.rect(x, y, w, 1, d.LINE)

    def slider(self, label, x, y, w, value, action, payload, minimum=0, maximum=1):
        # Blender-style compact numeric field: label and value share one row.
        data = (payload, minimum, maximum, x * self.scale, w * self.scale)
        self.widget(x, y, w, 22, "numslider", hover=self.state.hover == (action, data))
        fraction = max(0, min(1, (value - minimum) / (maximum - minimum)))
        self.rect(x + 3, y + 2, (w - 6) * fraction, 18, d.ACCENT)
        self.text(label, x + 8, y + 7, 11)
        number = f"{value:.3f}" if maximum <= 1 else f"{value:.0f}"
        self.text(number, x + w - 54, y + 7, 11)
        self.hit(x, y, w, 22, action, data)


def draw():
    context = bpy.context
    if not state.is_painter(context) or context.region.type != "WINDOW":
        return
    canvas = Canvas(context)
    gpu.state.blend_set("ALPHA")
    try:
        toolbar(canvas)
        browser(canvas)
        right_docks(canvas)
        status(canvas)
        tooltip(canvas)
    finally:
        gpu.state.blend_set("NONE")


def toolbar(c):
    w, h = c.w, c.h
    ts = active_set(c.context)
    c.rect(0, h - 43, w, 43, d.HEADER)
    c.text("Open Painter", 15, h - 26, 11)
    x = c.left + 16
    c.button("Paint", x, h - 34, 57, 25, "PAINT")
    c.button("Mask", x + 63, h - 34, 54, 25, "PAINT_MASK")
    c.button("Finish", x + 123, h - 34, 56, 25, "FINISH")
    c.button("3D", x + 194, h - 34, 35, 25, "VIEW", "VIEW_3D", c.context.area.type == "VIEW_3D")
    c.button(
        "2D", x + 233, h - 34, 35, 25, "VIEW", "IMAGE_EDITOR", c.context.area.type == "IMAGE_EDITOR"
    )
    if w - c.right - x > 460:
        c.text("Material", x + 294, h - 25, 11, d.MUTED)
        c.hit(x + 284, h - 35, 85, 28, "POPUP", "VIEWPORT")
    action_width = (c.right - 46) / 2
    c.button("Bake Mesh Maps", w - c.right + 10, h - 34, action_width, 25, "POPUP", "BAKE")
    c.button(
        "Export Textures",
        w - c.right + 14 + action_width,
        h - 34,
        action_width,
        25,
        "POPUP",
        "EXPORT",
    )
    c.button("×", w - 31, h - 34, 23, 25, "EXIT")
    # Keep Blender's native viewport unobstructed between the docks.
    if c.context.area.type == "VIEW_3D":
        c.text(ts.name if ts else "No texture set", c.left + 18, h - 67, 11, d.MUTED)
        c.text("3D VIEW", c.left + 18, 40, 10, d.MUTED)
    else:
        c.text("2D TEXTURE VIEW", c.left + 18, 40, 10, d.MUTED)


def browser(c):
    left, h = c.left, c.h
    s = c.state
    c.rect(0, 22, left, h - 65, d.BG)
    c.rect(left - 1, 22, 1, h - 65, d.LINE)
    c.header("ASSETS", 0, h - 73, left, "LIBRARY")
    c.widget(12, h - 110, left - 24, 25, "text", selected=s.search)
    c.text(
        s.query or ("Type to search…" if s.search else "Search assets"),
        22,
        h - 102,
        11,
        d.TEXT if s.query else d.MUTED,
        left - 45,
    )
    c.hit(12, h - 110, left - 24, 25, "SEARCH")
    names = [
        ("Mat", "MATERIALS"),
        ("Smart", "SMART"),
        ("Brushes", "BRUSHES"),
        ("Alphas", "ALPHAS"),
    ]
    tab_width = (left - 24) / 4
    for i, (label, key) in enumerate(names):
        c.button(
            label, 12 + i * tab_width, h - 144, tab_width - 2, 24, "ASSET_TAB", key, s.tab == key
        )
    entries = assets.items(c.context, s)
    gap = 8
    card = (left - 34) / 2
    top = h - 158
    capacity = max(0, int((top - 99) / (card + 27)) * 2)
    s.asset_scroll = max(0, min(s.asset_scroll, max(0, len(entries) - capacity)))
    for index, entry in enumerate(entries[s.asset_scroll : s.asset_scroll + capacity]):
        col = index % 2
        row = index // 2
        x = 12 + col * (card + gap)
        y = top - (row + 1) * (card + 27)
        c.widget(x, y + 23, card, card, "text", hover=s.hover == ("ASSET", entry))
        d.sphere(
            (x + card / 2) * c.scale,
            (y + 23 + card / 2) * c.scale,
            card * 0.38 * c.scale,
            entry[3],
            entry[4],
            entry[5],
        )
        c.text(entry[0], x + 2, y + 6, 10, d.TEXT, card)
        c.hit(x, y, card, card + 24, "ASSET", entry)
    c.text(f"{len(entries)} assets", 13, 79, 10, d.MUTED)
    c.button("Import Assets", 12, 46, left / 2 - 17, 25, "IMPORT")
    c.button("Save Material", left / 2 + 2, 46, left / 2 - 14, 25, "SAVE")


def right_docks(c):
    ts = active_set(c.context)
    x = c.w - c.right
    w = c.right
    h = c.h
    c.rect(x, 22, w, h - 65, d.BG)
    c.rect(x, 22, 1, h - 65, d.LINE)
    top = h - 73
    c.header("TEXTURE SET LIST", x, top, w)
    project = c.context.scene.open_painter
    sets = list(project.texture_sets)
    c.state.texture_scroll = max(0, min(c.state.texture_scroll, max(0, len(sets) - 3)))
    for i, item in enumerate(sets[c.state.texture_scroll : c.state.texture_scroll + 3]):
        y = top - 28 * (i + 1)
        c.widget(
            x + 8,
            y,
            w - 16,
            26,
            "list_item",
            selected=item == ts,
            hover=c.state.hover == ("SET", i + c.state.texture_scroll),
        )
        c.text(item.name, x + 18, y + 8, 12, d.TEXT, w - 108)
        c.text(item.resolution, x + w - 55, y + 8, 10)
        c.hit(x + 8, y, w - 16, 26, "SET", i + c.state.texture_scroll)
    c.hit(x, top - max(1, min(3, len(sets))) * 28, w, max(1, min(3, len(sets))) * 28, "SCROLL_SETS")
    y = top - max(1, min(3, len(sets))) * 28 - 32
    available = w - 20
    widths = [0.2, 0.2, 0.25, 0.2, 0.15]
    offset = x + 10
    for label, fraction, action, payload in zip(
        ("+ New", "Assign", "Settings", "Copy", "−"),
        widths,
        ("NEW_SET", "ASSIGN", "POPUP", "COPY_SET", "DELETE_SET"),
        (None, None, "TEXTURE", None, None),
    ):
        width = available * fraction
        c.button(label, offset, y, width - 3, 23, action, payload)
        offset += width
    y -= 37
    c.header("LAYERS", x, y, w, "STACK")
    y -= 33
    c.button("+ Paint", x + 10, y, 65, 25, "LAYER", "PAINT")
    c.button("+ Fill", x + 81, y, 55, 25, "LAYER", "FILL")
    c.button("Folder", x + 142, y, 60, 25, "LAYER", "FOLDER")
    c.button("Mask", x + 208, y, 52, 25, "POPUP", "ADD_MASK")
    list_top = y - 10
    list_height = min(220, max(100, min(h * 0.235, len(ts.layers) * 32 + 6 if ts else 100)))
    c.rect(x + 7, list_top - list_height, w - 14, list_height, d.HEADER)
    if ts and ts.layers:
        entries = list(reversed(list(enumerate(ts.layers))))
        capacity = max(1, int(list_height / 32))
        c.state.layer_scroll = max(0, min(c.state.layer_scroll, max(0, len(entries) - capacity)))
        for row, (index, layer) in enumerate(
            entries[c.state.layer_scroll : c.state.layer_scroll + capacity]
        ):
            ly = list_top - (row + 1) * 32
            selected = index == ts.active_layer
            c.widget(
                x + 8,
                ly,
                w - 16,
                31,
                "list_item",
                selected=selected,
                hover=c.state.hover == ("SELECT_LAYER", index),
            )
            c.hit(x + 8, ly, w - 16, 31, "SELECT_LAYER", index)
            c.text(
                "●" if layer.visible else "○",
                x + 15,
                ly + 11,
                11,
                d.TEXT if layer.visible else d.MUTED,
            )
            c.hit(x + 9, ly, 25, 31, "VISIBILITY", index)
            indent = 10 if layer.parent_id else 0
            color = channel_for(layer, "BASE_COLOR")
            swatch = tuple(color.color[:3]) + (1,) if color else d.CARD
            c.rect(x + 39 + indent, ly + 5, 22, 22, swatch if layer.type == "FILL" else d.CARD)
            if layer.type != "FILL":
                c.text("P" if layer.type == "PAINT" else "▸", x + 47 + indent, ly + 11, 11)
            c.text(layer.name, x + 76 + indent, ly + 11, 11, d.TEXT, w - 152 - indent)
            if layer.masks:
                c.rect(
                    x + w - 69,
                    ly + 5,
                    20,
                    22,
                    d.TEXT if not (selected and c.state.mask_selected) else d.ACCENT,
                )
                d.circle((x + w - 59) * c.scale, (ly + 16) * c.scale, 6 * c.scale, d.HEADER)
                c.hit(x + w - 72, ly + 2, 27, 28, "SELECT_MASK", index)
            c.text(f"{layer.opacity * 100:.0f}", x + w - 35, ly + 11, 10, d.TEXT)
        c.hit(x, list_top - list_height, w, list_height, "SCROLL_LAYERS")
        # Scroll target must not shadow row clicks; event routing handles wheel separately.
    else:
        c.text("Add a paint or fill layer", x + 25, list_top - 40, 12, d.MUTED)
        c.text("to start texturing.", x + 25, list_top - 60, 11, d.MUTED)
    y = list_top - list_height - 32
    for index, (label, action) in enumerate(
        [
            ("↑", "UP"),
            ("↓", "DOWN"),
            ("Duplicate", "DUPLICATE"),
            ("Delete", "DELETE"),
            ("Parent", "PARENT"),
        ]
    ):
        widths = [24, 24, (w - 93) * 0.40, (w - 93) * 0.3, (w - 93) * 0.3]
        offset = sum(widths[:index]) + index * 4
        c.button(label, x + 10 + offset, y, widths[index], 23, "LAYER", action)
    prop_top = y - 37
    properties(c, ts, x, prop_top, w)
    c.hit(x, 22, w, max(0, prop_top - 22), "SCROLL_PROPERTIES")


def properties(c, ts, x, top, w):
    layer = active(ts) if ts else None
    title = "Properties"
    if layer:
        title += " · " + ("MASK" if c.state.mask_selected and layer.masks else layer.type)
    c.header(title, x, top, w)
    if not layer:
        c.text("Select a layer to edit its properties.", x + 14, top - 28, 11, d.MUTED, w - 25)
        return
    origin = gpu.state.viewport_get()
    gpu.state.scissor_test_set(True)
    gpu.state.scissor_set(
        int(origin[0] + x * c.scale),
        int(origin[1] + 22 * c.scale),
        int(w * c.scale),
        max(1, int((top - 22) * c.scale)),
    )
    c.clip = (22, top)
    try:
        property_fields(c, ts, layer, x, top, w)
    finally:
        c.clip = None
        gpu.state.scissor_test_set(False)


def property_fields(c, ts, layer, x, top, w):
    y = top - 36 + c.state.properties_scroll
    c.text(layer.name, x + 14, y + 4, 12, d.TEXT, w - 80)
    c.button("Edit", x + w - 55, y - 2, 43, 23, "POPUP", "LAYER")
    y -= 34
    if c.state.mask_selected and layer.masks:
        mask = layer.masks[min(layer.active_mask, len(layer.masks) - 1)]
        c.text(mask.name, x + 14, y + 7, 11, d.MUTED)
        c.button(
            mask.generator.replace("_", " ").title()
            if mask.source == "GENERATOR"
            else mask.source.title(),
            x + 14,
            y - 24,
            w - 28,
            25,
            "POPUP",
            "MASK",
        )
        y -= 61
        if y > 48:
            c.slider(
                "Mask strength", x + 14, y, w - 28, mask.strength, "SLIDER", ("MASK", "strength")
            )
        y -= 47
        if y > 48:
            c.button(
                "✓ Invert" if mask.invert else "Invert mask",
                x + 14,
                y,
                w / 2 - 20,
                24,
                "INVERT_MASK",
            )
            c.button("Paint mask", x + w / 2 + 1, y, w / 2 - 15, 24, "PAINT_MASK")
        return
    c.button(layer.blend_mode.title(), x + 14, y, w / 2 - 20, 23, "POPUP", "BLEND")
    c.text("Blending", x + w / 2 + 5, y + 7, 10, d.MUTED)
    y -= 28
    c.slider("Opacity", x + 14, y, w - 28, layer.opacity, "SLIDER", ("LAYER", "opacity"))
    y -= 28
    if layer.type == "FOLDER":
        c.text("Masks and opacity affect the whole folder.", x + 14, y, 10, d.MUTED, w - 26)
        return
    chip_width = (w - 28) / 6
    for i, key in enumerate(("BASE_COLOR", "ROUGHNESS", "METALLIC", "NORMAL", "HEIGHT", "AO")):
        channel = channel_for(layer, key)
        label = {
            "BASE_COLOR": "BC",
            "ROUGHNESS": "R",
            "METALLIC": "M",
            "NORMAL": "N",
            "HEIGHT": "H",
            "AO": "AO",
        }[key]
        c.button(
            label,
            x + 14 + i * chip_width,
            y,
            chip_width - 3,
            22,
            "CHANNEL",
            key,
            bool(channel and channel.enabled),
        )
    y -= 30
    if layer.type == "PAINT":
        project = c.context.scene.open_painter
        c.text("Painting: " + CHANNEL_LABELS[project.paint_channel], x + 14, y + 7, 11, d.MUTED)
        paint = c.context.scene.tool_settings.image_paint
        brush = paint.brush
        if brush:
            unified = paint.unified_paint_settings
            for key, label, maximum in [
                ("size", "Size", 250),
                ("strength", "Strength", 1),
                ("spacing", "Spacing", 100),
            ]:
                y -= 37
                if y < 45:
                    break
                owner = unified if getattr(unified, "use_unified_" + key, False) else brush
                c.slider(
                    label,
                    x + 14,
                    y,
                    w - 28,
                    getattr(owner, key),
                    "SLIDER",
                    ("BRUSH", key),
                    1 if key != "strength" else 0,
                    maximum,
                )
        else:
            c.button("Start painting", x + 14, y - 25, w - 28, 27, "PAINT")
        return
    for key in ("BASE_COLOR", "ROUGHNESS", "METALLIC"):
        channel = channel_for(layer, key)
        if not channel or not channel.enabled:
            continue
        if y < 46:
            break
        if key == "BASE_COLOR":
            c.text("Base color", x + 14, y + 7, 11, d.MUTED)
            c.rect(x + w * 0.5, y, w * 0.5 - 14, 23, tuple(channel.color))
            c.hit(x + 14, y, w - 28, 25, "POPUP", "COLOR")
            y -= 28
        else:
            c.slider(
                CHANNEL_LABELS[key], x + 14, y, w - 28, channel.value, "SLIDER", ("CHANNEL", key)
            )
            y -= 28


def status(c):
    project = c.context.scene.open_painter
    c.rect(0, 0, c.w, 22, d.HEADER)
    c.text(c.state.message or project.status or "Ready", 13, 7, 10, d.MUTED, c.left - 22)
    ts = active_set(c.context)
    detail = (
        f"{ts.resolution} × {ts.resolution}  |  {len(ts.layers)} layers  |  Linear PBR"
        if ts
        else "Create a texture set and assign your mesh"
    )
    c.text(detail, c.left + 16, 7, 10, d.MUTED, c.w - c.left - c.right - 25)
    c.text("Open Painter  0.1", c.w - 130, 7, 10, d.MUTED)


HELP = {
    "NEW_SET": "Create a texture set for the selected mesh",
    "ASSIGN": "Assign the selected mesh to this texture set",
    "COPY_SET": "Duplicate texture set",
    "DELETE_SET": "Remove texture set",
    "SEARCH": "Search assets by name",
    "SLIDER": "Drag to adjust · Shift for precision · Double-click to enter a value · Esc to cancel",
    "SELECT_LAYER": "Select layer · F2 to rename · Right-click for properties",
    "VISIBILITY": "Toggle layer visibility",
    "SELECT_MASK": "Edit layer mask",
    "PAINT": "Start painting on the active layer",
    "PAINT_MASK": "Paint on the active layer mask",
    "FINISH": "Finish the current paint session",
    "EXIT": "Close Open Painter in this area",
}


def tooltip(c):
    ui = c.state
    if not ui.hover or ui.drag or monotonic() - ui.hover_since < 0.7:
        return
    action, payload = ui.hover
    label = HELP.get(action)
    if action == "CHANNEL":
        label = CHANNEL_LABELS[payload]
    elif action == "ASSET":
        label = "Apply " + payload[0]
    elif action == "POPUP":
        label = payload.replace("_", " ").title()
    if not label:
        return
    width = min(c.w - 16, d.text_width(label, d.FONT_SIZE * c.scale) / c.scale + 20)
    x = min(max(8, ui.mouse[0] / c.scale + 12), c.w - width - 8)
    y = max(25, ui.mouse[1] / c.scale - 32)
    c.widget(x, y, width, 25, "tooltip")
    c.text(label, x + 10, y + 8, 11, d.WIDGETS["tooltip"]["text"], width - 20)
