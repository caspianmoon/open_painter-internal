"""Stable on-disk identifiers and ownership markers."""

VERSION = "0.1.1"
OWNER = "open_painter_managed"
CHANNELS = ("BASE_COLOR", "ROUGHNESS", "METALLIC", "NORMAL", "HEIGHT", "AO")
CHANNEL_LABELS = dict(
    zip(CHANNELS, ("BaseColor", "Roughness", "Metallic", "Normal", "Height", "AO"))
)
CHANNEL_ITEMS = [(c, CHANNEL_LABELS[c], "") for c in CHANNELS]
RESOLUTIONS = [(str(n), str(n), f"{n} × {n} pixels") for n in (512, 1024, 2048, 4096, 8192)]
DEFAULTS = {
    "BASE_COLOR": (0.5, 0.5, 0.5, 1),
    "ROUGHNESS": (0.5, 0.5, 0.5, 1),
    "METALLIC": (0, 0, 0, 1),
    "NORMAL": (0.5, 0.5, 1, 1),
    "HEIGHT": (0.5, 0.5, 0.5, 1),
    "AO": (1, 1, 1, 1),
}
