"""A fixed-size Principled preview graph; preserve all unrelated nodes."""

import bpy

from ..constants import CHANNELS, OWNER


def repair(ts):
    material = ts.material
    if not material or not material.get(OWNER):
        material = bpy.data.materials.new(f"OP · {ts.name}")
        material[OWNER] = True
        material["texture_set_id"] = ts.id
        ts.material = material
    material.use_nodes = True
    nodes, links = material.node_tree.nodes, material.node_tree.links

    def node(role, kind, location):
        found = next(
            (n for n in nodes if n.get(OWNER) and n.get("role") == role and n.bl_idname == kind),
            None,
        )
        if found is None:
            found = nodes.new(kind)
            found[OWNER], found["role"] = True, role
            found.label = "Open Painter · " + role
        found.location = location
        return found

    output = node("Output", "ShaderNodeOutputMaterial", (800, 0))
    output.is_active_output = True
    bsdf = node("Surface", "ShaderNodeBsdfPrincipled", (500, 0))
    links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    tex = {}
    for i, channel in enumerate(CHANNELS):
        tex[channel] = node(channel, "ShaderNodeTexImage", (-600, 400 - i * 250))
        image = next((o.image for o in ts.outputs if o.channel == channel), None)
        tex[channel].image = image
    ao = node("AO Preview", "ShaderNodeMixRGB", (0, 300))
    ao.blend_type = "MULTIPLY"
    ao.inputs[0].default_value = 1 if ts.preview_ao else 0
    links.new(tex["BASE_COLOR"].outputs["Color"], ao.inputs[1])
    links.new(tex["AO"].outputs["Color"], ao.inputs[2])
    links.new(ao.outputs[0], bsdf.inputs["Base Color"])
    for channel, socket in (("ROUGHNESS", "Roughness"), ("METALLIC", "Metallic")):
        links.new(tex[channel].outputs["Color"], bsdf.inputs[socket])
    normal = node("Normal", "ShaderNodeNormalMap", (0, -200))
    bump = node("Height", "ShaderNodeBump", (250, -200))
    bump.inputs["Distance"].default_value = ts.height_distance
    links.new(tex["NORMAL"].outputs["Color"], normal.inputs["Color"])
    links.new(normal.outputs["Normal"], bump.inputs["Normal"])
    links.new(tex["HEIGHT"].outputs["Color"], bump.inputs["Height"])
    links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])
    for ref in ts.assignments:
        if ref.object and ref.slot_index < len(ref.object.material_slots):
            slot = ref.object.material_slots[ref.slot_index]
            if slot.material is None:
                slot.material = material
    return material
