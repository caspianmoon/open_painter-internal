"""Pure NumPy blend operations in linear space."""

import numpy as np


def blend(base, source, alpha, mode="NORMAL"):
    if mode == "NORMAL":
        result = source
    elif mode == "MULTIPLY":
        result = base * source
    elif mode == "ADD":
        result = base + source
    elif mode == "SUBTRACT":
        result = base - source
    elif mode == "OVERLAY":
        result = np.where(base <= 0.5, 2 * base * source, 1 - 2 * (1 - base) * (1 - source))
    else:
        raise ValueError(f"Unsupported blend mode: {mode}")
    return base + alpha * (result - base)


def sample_uv(texture, u, v):
    """Bilinear repeat sampling; UV origin follows Blender's bottom-left pixels."""
    h, w = texture.shape[:2]
    x, y = (u % 1) * w - 0.5, (v % 1) * h - 0.5
    ix, iy = np.floor(x).astype(np.int32), np.floor(y).astype(np.int32)
    fx, fy = (x - ix)[..., None], (y - iy)[..., None]
    a = texture[iy % h, ix % w] * (1 - fx) + texture[iy % h, (ix + 1) % w] * fx
    b = texture[(iy + 1) % h, ix % w] * (1 - fx) + texture[(iy + 1) % h, (ix + 1) % w] * fx
    return a * (1 - fy) + b * fy
