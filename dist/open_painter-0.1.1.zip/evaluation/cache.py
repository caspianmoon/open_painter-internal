"""Debounced evaluation lifecycle; only transient scheduling lives in memory."""

from time import monotonic

import bpy
from bpy.app.handlers import persistent

from ..constants import OWNER
from ..utils.logging import logger

_pending = {}


def tick():
    from .evaluator import LayerEvaluator

    for scene in bpy.data.scenes:
        if not hasattr(scene, "open_painter"):
            continue
        from ..painting.paint_session import detect

        detect(scene)
        for ts in scene.open_painter.texture_sets:
            if not ts.dirty:
                _pending.pop(ts.id, None)
                continue
            now = monotonic()
            serial, since = _pending.setdefault(ts.id, (ts.edit_serial, now))
            if serial != ts.edit_serial:
                _pending[ts.id] = (ts.edit_serial, now)
                continue
            if now - since < 0.3:
                continue
            try:
                LayerEvaluator(scene).evaluate_texture_set(ts.id)
                scene.open_painter.status = ""
            except Exception as exc:
                scene.open_painter.status = str(exc)
                logger.error("Evaluation: %s", exc)
                ts.dirty = False
            _pending.pop(ts.id, None)
    return 0.2


@persistent
def on_load(_):
    from ..painting.paint_session import reset

    reset()
    _pending.clear()
    for scene in bpy.data.scenes:
        if hasattr(scene, "open_painter"):
            for ts in scene.open_painter.texture_sets:
                ts.dirty = True
                for output in ts.outputs:
                    output.dirty = True


@persistent
def on_save(_):
    from ..painting.paint_session import detect
    from .evaluator import LayerEvaluator

    for scene in bpy.data.scenes:
        if not hasattr(scene, "open_painter"):
            continue
        detect(scene, force=True)
        for ts in scene.open_painter.texture_sets:
            if ts.dirty:
                try:
                    LayerEvaluator(scene).evaluate_texture_set(ts.id)
                except Exception as exc:
                    scene.open_painter.status = f"Saved project; preview needs attention: {exc}"
                    logger.error("Save preview: %s", exc)
    for image in bpy.data.images:
        if image.get(OWNER) and image.has_data:
            image.pack()


def register():
    bpy.app.handlers.load_post.append(on_load)
    bpy.app.handlers.undo_post.append(on_load)
    bpy.app.handlers.redo_post.append(on_load)
    bpy.app.handlers.save_pre.append(on_save)
    if not bpy.app.background:
        bpy.app.timers.register(tick, first_interval=0.5, persistent=True)


def unregister():
    from ..painting.paint_session import restore_faces

    for scene in bpy.data.scenes:
        if hasattr(scene, "open_painter"):
            restore_faces(scene.open_painter)
    for handlers, fn in (
        (bpy.app.handlers.load_post, on_load),
        (bpy.app.handlers.undo_post, on_load),
        (bpy.app.handlers.redo_post, on_load),
        (bpy.app.handlers.save_pre, on_save),
    ):
        if fn in handlers:
            handlers.remove(fn)
    if bpy.app.timers.is_registered(tick):
        bpy.app.timers.unregister(tick)
    from ..painting.paint_session import reset

    reset()
    _pending.clear()
