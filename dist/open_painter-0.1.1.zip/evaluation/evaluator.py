"""Bottom-to-top, isolated-folder composition into six controlled images."""

from time import perf_counter

import numpy as np

from ..constants import CHANNELS, DEFAULTS
from ..core import image_manager, material_manager
from ..core.layer_stack import channel_for
from ..utils.logging import logger
from .blend_modes import blend
from .channel_eval import source


class LayerEvaluator:
    """Evaluate only dirty channel outputs; persistent layer data is authoritative."""

    def __init__(self, scene):
        self.scene = scene
        self.geometry_cache = {}

    def evaluate_texture_set(self, texture_set_id: str, force=False):
        ts = next((s for s in self.scene.open_painter.texture_sets if s.id == texture_set_id), None)
        if ts is None:
            raise ValueError("No active texture set.")
        from ..core.validation import hierarchy_issues

        issues = hierarchy_issues(ts)
        if issues:
            raise ValueError(" | ".join(issues))
        self.geometry_cache.clear()
        started = perf_counter()
        for channel in CHANNELS:
            out = image_manager.output(ts, channel)
            if force or out.dirty:
                self.evaluate_channel(ts.id, channel)
        self.geometry_cache.clear()
        ts.dirty = False
        for layer in ts.layers:
            layer.dirty = False
            for prop in layer.channels:
                prop.dirty = False
        material_manager.repair(ts)
        logger.debug("Evaluated %s in %.3fs", ts.name, perf_counter() - started)

    def evaluate_channel(self, texture_set_id: str, channel: str):
        ts = next(s for s in self.scene.open_painter.texture_sets if s.id == texture_set_id)
        n = int(ts.resolution)
        result = np.empty((n, n, 4), dtype=np.float32)
        cache = {}
        children = {}
        for layer in ts.layers:
            children.setdefault(layer.parent_id, []).append(layer)

        def compose(parent_id, y0, y1, initial, ancestry):
            rgb = np.array(initial, dtype=np.float32)
            coverage = np.zeros(1, dtype=np.float32)
            for layer in children.get(parent_id, []):
                if not layer.visible:
                    continue
                if layer.id in ancestry:
                    raise ValueError("Layer hierarchy contains a cycle. Reparent the folder.")
                if layer.type == "FOLDER":
                    src, alpha = compose(layer.id, y0, y1, (0, 0, 0), ancestry | {layer.id})
                    # Child composition is premultiplied against black; recover straight color.
                    src = np.divide(src, alpha, out=np.zeros_like(src), where=alpha > 1e-8)
                else:
                    prop = channel_for(layer, channel)
                    if not prop or not prop.enabled:
                        continue
                    rgba = source(prop, layer.type, n, y0, y1, cache, ts, self.geometry_cache)
                    src, alpha = rgba[..., :3], rgba[..., 3:4]
                if hasattr(layer, "masks") and layer.masks:
                    from .mask_eval import evaluate_masks

                    alpha = alpha * evaluate_masks(ts, layer, n, y0, y1, cache)[..., None]
                alpha = np.clip(alpha * layer.opacity, 0, 1)
                rgb = blend(rgb, src, alpha, layer.blend_mode)
                coverage = alpha + coverage * (1 - alpha)
            return rgb, coverage

        for y0 in range(0, n, 128):
            y1 = min(n, y0 + 128)
            rgb, _ = compose("", y0, y1, DEFAULTS[channel][:3], set())
            if channel == "NORMAL":
                vectors = rgb * 2 - 1
                lengths = np.linalg.norm(vectors, axis=-1, keepdims=True)
                vectors = np.divide(
                    vectors, lengths, out=np.zeros_like(vectors), where=lengths > 1e-8
                )
                rgb = vectors * 0.5 + 0.5
            result[y0:y1, :, :3] = np.clip(rgb, 0, 1)
            result[y0:y1, :, 3] = 1
        out = image_manager.output(ts, channel)
        image_manager.write(out.image, result, pack=False)
        out.dirty = False
        out.revision += 1
        return out.image
