"""Draw handlers and input lifecycle, removable without modifying other workspaces."""

from time import monotonic

import bpy
from bpy.app.handlers import persistent

from . import renderer, state

_handlers = []
_configured = {}


def tick():
    from .. import editor
    from .interaction import configure

    for window in bpy.context.window_manager.windows:
        editor.scan(window)
        if window.scene.open_painter.paint_image:
            from ...painting.paint_session import finish, synchronize
            from ...utils.logging import logger

            with bpy.context.temp_override(window=window):
                try:
                    synchronize(bpy.context)
                except Exception as exc:
                    finish(bpy.context, evaluate=False)
                    window.scene.open_painter.status = str(exc)
                    logger.error("Paint target: %s", exc)
        for area in window.screen.areas:
            if editor.is_area(area):
                area.tag_redraw()
                region = next((r for r in area.regions if r.type == "WINDOW"), None)
                if region:
                    with bpy.context.temp_override(window=window, area=area, region=region):
                        now = monotonic()
                        key = area.as_pointer()
                        if now - _configured.get(key, 0) > 1.0:
                            configure(area)
                            _configured[key] = now
                        if window.as_pointer() not in state.windows:
                            bpy.ops.open_painter.dock_events("INVOKE_DEFAULT")
    return 0.15


@persistent
def on_load(_):
    _configured.clear()
    state.reset()


def register():
    if bpy.app.background:
        return
    for space in (bpy.types.SpaceView3D, bpy.types.SpaceImageEditor):
        _handlers.append((space, space.draw_handler_add(renderer.draw, (), "WINDOW", "POST_PIXEL")))
    bpy.app.timers.register(tick, first_interval=0.5, persistent=True)
    bpy.app.handlers.load_post.append(on_load)


def unregister():
    for space, handler in _handlers:
        space.draw_handler_remove(handler, "WINDOW")
    _handlers.clear()
    if bpy.app.timers.is_registered(tick):
        bpy.app.timers.unregister(tick)
    if on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(on_load)
    _configured.clear()
    state.reset()
