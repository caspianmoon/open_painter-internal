"""Ordered layers with stable hierarchy, duplication and cycle-safe parenting."""

from ..constants import CHANNELS, DEFAULTS
from ..utils.ids import new_id


def invalidate(ts) -> None:
    ts.dirty = True
    ts.edit_serial += 1
    for out in ts.outputs:
        out.dirty = True
    for i, layer in enumerate(ts.layers):
        layer.order = i
        layer.dirty = True


def add(ts, kind="FILL", name=None):
    layer = ts.layers.add()
    layer.id, layer.type = new_id(), kind
    layer.name = name or {"FILL": "Fill Layer", "PAINT": "Paint Layer", "FOLDER": "Folder"}[kind]
    ensure_channels(layer)
    ts.active_layer = len(ts.layers) - 1
    invalidate(ts)
    return layer


def ensure_channels(layer):
    """Also upgrades legacy folders, which stored no per-channel settings."""
    for channel in CHANNELS:
        if channel_for(layer, channel):
            continue
        prop = layer.channels.add()
        prop.channel, prop.layer_id = channel, layer.id
        prop.color, prop.value = DEFAULTS[channel], DEFAULTS[channel][0]
        prop.enabled = layer.type == "FOLDER" or (
            layer.type == "FILL" and channel in {"BASE_COLOR", "ROUGHNESS", "METALLIC"}
        )


def active(ts):
    return ts.layers[ts.active_layer] if 0 <= ts.active_layer < len(ts.layers) else None


def channel_for(layer, channel):
    return next((c for c in layer.channels if c.channel == channel), None)


def parent(ts, layer, folder_id: str) -> None:
    by_id = {item.id: item for item in ts.layers}
    cursor = folder_id
    seen = {layer.id}
    while cursor:
        if cursor in seen:
            raise ValueError("A folder cannot contain itself or its ancestors.")
        seen.add(cursor)
        folder = by_id.get(cursor)
        if folder is None or folder.type != "FOLDER":
            raise ValueError("Parent folder is missing.")
        cursor = folder.parent_id
    layer.parent_id = folder_id
    invalidate(ts)


def remove(ts, index: int) -> None:
    layer = ts.layers[index]
    for child in ts.layers:
        if child.parent_id == layer.id:
            child.parent_id = layer.parent_id
    ts.layers.remove(index)
    ts.active_layer = min(index, len(ts.layers) - 1)
    invalidate(ts)


def move(ts, index: int, direction: int) -> None:
    target = max(0, min(len(ts.layers) - 1, index + direction))
    ts.layers.move(index, target)
    ts.active_layer = target
    invalidate(ts)


def snapshot(source) -> dict:
    """Detach RNA values before mutating a Blender collection."""
    import bpy

    result = {}
    for prop in source.bl_rna.properties:
        key = prop.identifier
        if key == "rna_type" or prop.is_readonly and prop.type != "COLLECTION":
            continue
        value = getattr(source, key)
        if prop.type == "COLLECTION":
            result[key] = [snapshot(item) for item in value]
        elif prop.type == "POINTER" and isinstance(value, bpy.types.PropertyGroup):
            result[key] = snapshot(value)
        elif getattr(prop, "is_array", False):
            result[key] = list(value)
        else:
            result[key] = value
    return result


def restore(data: dict, target) -> None:
    for key, value in data.items():
        prop = target.bl_rna.properties[key]
        if prop.type == "COLLECTION":
            for item in value:
                restore(item, getattr(target, key).add())
        elif prop.type == "POINTER" and isinstance(value, dict):
            restore(value, getattr(target, key))
        else:
            setattr(target, key, value)


def copy_properties(source, target):
    restore(snapshot(source), target)


def duplicate(ts, index):
    ids = {ts.layers[index].id}
    while True:
        expanded = ids | {item.id for item in ts.layers if item.parent_id in ids}
        if expanded == ids:
            break
        ids = expanded
    sources = [snapshot(item) for item in ts.layers if item.id in ids]
    mapping = {item["id"]: new_id() for item in sources}
    first = len(ts.layers)
    for source in sources:
        target = ts.layers.add()
        restore(source, target)
        target.id = mapping[source["id"]]
        target.name += " Copy"
        target.parent_id = mapping.get(source["parent_id"], source["parent_id"])
        for mask in target.masks:
            mask.id = new_id()
            if mask.source == "PAINT" and mask.image:
                mask.image = mask.image.copy()
        for channel in target.channels:
            channel.layer_id = target.id
            if target.type == "PAINT" and channel.image:
                channel.image = channel.image.copy()
    ts.active_layer = first
    invalidate(ts)
    return ts.layers[first]
