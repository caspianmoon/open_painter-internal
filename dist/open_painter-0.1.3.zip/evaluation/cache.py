"""Debounced evaluation lifecycle; only transient scheduling lives in memory."""

from time import monotonic

import bpy
from bpy.app.handlers import persistent

from ..constants import OWNER
from ..utils.logging import logger

_pending = {}
_paint_input = {}
_evaluators = {}


def paint_input(scene, pressed):
    _paint_input[scene.as_pointer()] = (pressed, monotonic())


def tick():
    from .evaluator import LayerEvaluator

    live = {
        ts.id
        for scene in bpy.data.scenes
        if hasattr(scene, "open_painter")
        for ts in scene.open_painter.texture_sets
    }
    for identifier in set(_evaluators) - live:
        _evaluators.pop(identifier, None)
        _pending.pop(identifier, None)
    for scene in bpy.data.scenes:
        if not hasattr(scene, "open_painter"):
            continue
        from ..painting.paint_session import detect

        activity = _paint_input.get(scene.as_pointer())
        windows = [w for w in bpy.context.window_manager.windows if w.scene == scene]
        painting = any(
            op.bl_idname == "PAINT_OT_image_paint" for w in windows for op in w.modal_operators
        )
        if painting:
            # Blender's brush modal can consume the release before our handler.
            _paint_input[scene.as_pointer()] = (True, monotonic())
            continue
        if activity:
            pressed, when = activity
            if monotonic() - when > 0.12:
                detect(scene, force=True)
                _paint_input.pop(scene.as_pointer(), None)
        elif scene.open_painter.paint_image:
            from ..ui.editor import is_area

            if not any(is_area(area) for w in windows for area in w.screen.areas):
                detect(scene)
        for ts in scene.open_painter.texture_sets:
            if not ts.dirty:
                _pending.pop(ts.id, None)
                _evaluators.pop(ts.id, None)
                continue
            now = monotonic()
            serial, since = _pending.setdefault(ts.id, (ts.edit_serial, now))
            if serial != ts.edit_serial:
                _pending[ts.id] = (ts.edit_serial, now)
                _evaluators.pop(ts.id, None)
                continue
            if now - since < 0.3:
                continue
            try:
                from ..constants import CHANNELS
                from ..core import image_manager, material_manager
                from ..core.validation import hierarchy_issues

                issues = hierarchy_issues(ts)
                if issues:
                    raise ValueError(" | ".join(issues))
                evaluator = _evaluators.setdefault(ts.id, LayerEvaluator(scene))
                outputs = [image_manager.output(ts, channel) for channel in CHANNELS]
                dirty = next((output for output in outputs if output.dirty), None)
                if dirty:
                    evaluator.evaluate_channel(ts.id, dirty.channel)
                if any(output.dirty for output in outputs):
                    return 0.03
                material_manager.repair(ts)
                ts.dirty = False
                for layer in ts.layers:
                    layer.dirty = False
                    for channel in layer.channels:
                        channel.dirty = False
                scene.open_painter.status = ""
            except Exception as exc:
                scene.open_painter.status = str(exc)
                logger.error("Evaluation: %s", exc)
                ts.dirty = False
            _pending.pop(ts.id, None)
            _evaluators.pop(ts.id, None)
            return 0.03
    return 0.2


@persistent
def on_load(_):
    from ..painting.paint_session import reset

    reset()
    _pending.clear()
    _paint_input.clear()
    _evaluators.clear()
    for scene in bpy.data.scenes:
        if hasattr(scene, "open_painter"):
            for ts in scene.open_painter.texture_sets:
                ts.dirty = True
                for output in ts.outputs:
                    output.dirty = True


@persistent
def on_save(_):
    from ..painting.paint_session import detect
    from .evaluator import LayerEvaluator

    for scene in bpy.data.scenes:
        if not hasattr(scene, "open_painter"):
            continue
        detect(scene, force=True)
        for ts in scene.open_painter.texture_sets:
            if ts.dirty:
                try:
                    LayerEvaluator(scene).evaluate_texture_set(ts.id)
                except Exception as exc:
                    scene.open_painter.status = f"Saved project; preview needs attention: {exc}"
                    logger.error("Save preview: %s", exc)
    for image in bpy.data.images:
        if image.get(OWNER) and image.has_data:
            image.pack()


def register():
    bpy.app.handlers.load_post.append(on_load)
    bpy.app.handlers.undo_post.append(on_load)
    bpy.app.handlers.redo_post.append(on_load)
    bpy.app.handlers.save_pre.append(on_save)
    if not bpy.app.background:
        bpy.app.timers.register(tick, first_interval=0.5, persistent=True)


def unregister():
    from ..painting.paint_session import restore_faces

    for scene in bpy.data.scenes:
        if hasattr(scene, "open_painter"):
            restore_faces(scene.open_painter)
    for handlers, fn in (
        (bpy.app.handlers.load_post, on_load),
        (bpy.app.handlers.undo_post, on_load),
        (bpy.app.handlers.redo_post, on_load),
        (bpy.app.handlers.save_pre, on_save),
    ):
        if fn in handlers:
            handlers.remove(fn)
    if bpy.app.timers.is_registered(tick):
        bpy.app.timers.unregister(tick)
    from ..painting.paint_session import reset

    reset()
    _pending.clear()
    _paint_input.clear()
    _evaluators.clear()
