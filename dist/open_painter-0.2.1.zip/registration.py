"""Single ordered registry, reversible without leaking callbacks."""

import bpy

from .preferences import OP_Preferences
from .properties.bake import OP_BakedMap, OP_BakeSettings, OP_ObjectRef
from .properties.channel import OP_Channel, OP_Output
from .properties.export import OP_ExportSettings
from .properties.layer import OP_Layer
from .properties.mask import OP_Mask
from .properties.project import OP_Project
from .properties.texture_set import OP_Assignment, OP_TextureSet
from .ui.assets_panel import OP_OT_import_material, OP_OT_library, OP_OT_save_material, OP_PT_assets
from .ui.baking_panel import OP_OT_bake, OP_PT_bake, OP_UL_high
from .ui.brush_operators import OP_OT_brush_action, OP_OT_import_alpha
from .ui.dock.interaction import OP_OT_dock_events, OP_OT_dock_popup
from .ui.editor import OP_EditorType, OP_OT_close_editor, OP_OT_open_editor
from .ui.export_panel import OP_OT_export, OP_PT_export
from .ui.layer_list import OP_OT_layer, OP_PT_layers, OP_UL_layers
from .ui.operators import OP_OT_texture_set
from .ui.painting_panel import OP_OT_paint, OP_PT_paint
from .ui.panels import OP_PT_main, OP_PT_texture_set, OP_UL_assignments, OP_UL_texture_sets
from .ui.properties_panel import OP_OT_mask, OP_PT_masks, OP_UL_masks
from .ui.workspace import OP_OT_workspace

from .ui.native import CLASSES as NATIVE_CLASSES
from .ui.texture_operations import CLASSES as TEXTURE_UI_CLASSES

from .properties.effect import OP_TextureEffect

CLASSES = (
    OP_TextureEffect,
    OP_EditorType,
    OP_OT_open_editor,
    OP_OT_close_editor,
    OP_Preferences,
    OP_Channel,
    OP_Output,
    OP_Mask,
    OP_Layer,
    OP_Assignment,
    OP_ObjectRef,
    OP_BakedMap,
    OP_BakeSettings,
    OP_ExportSettings,
    OP_TextureSet,
    OP_Project,
    OP_OT_texture_set,
    OP_UL_texture_sets,
    OP_UL_assignments,
    OP_PT_main,
    OP_PT_texture_set,
    OP_OT_layer,
    OP_UL_layers,
    OP_PT_layers,
    OP_OT_mask,
    OP_UL_masks,
    OP_PT_masks,
    OP_OT_bake,
    OP_UL_high,
    OP_PT_bake,
    OP_OT_save_material,
    OP_OT_import_material,
    OP_OT_library,
    OP_PT_assets,
    OP_OT_paint,
    OP_OT_import_alpha,
    OP_OT_brush_action,
    OP_PT_paint,
    OP_OT_export,
    OP_PT_export,
    OP_OT_workspace,
    OP_OT_dock_popup,
    OP_OT_dock_events,
) + TEXTURE_UI_CLASSES + NATIVE_CLASSES


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.open_painter = bpy.props.PointerProperty(type=OP_Project)
    from .evaluation import cache

    cache.register()
    from .ui.dock import lifecycle

    lifecycle.register()
    from .ui import editor

    editor.register()
    from .ui.native import toolbar, asset_type_buttons
    bpy.types.VIEW3D_HT_tool_header.prepend(asset_type_buttons)
    bpy.types.IMAGE_HT_tool_header.prepend(asset_type_buttons)
    bpy.types.VIEW3D_HT_tool_header.append(toolbar)


def unregister():
    from .ui import editor, workspace
    from .ui.dock import lifecycle

    from .ui.native import toolbar, asset_type_buttons
    bpy.types.VIEW3D_HT_tool_header.remove(asset_type_buttons)
    bpy.types.IMAGE_HT_tool_header.remove(asset_type_buttons)
    bpy.types.VIEW3D_HT_tool_header.remove(toolbar)
    editor.unregister()
    lifecycle.unregister()
    workspace.unregister()
    from .evaluation import cache

    cache.unregister()
    if hasattr(bpy.types.Scene, "open_painter"):
        del bpy.types.Scene.open_painter
    for cls in reversed(CLASSES):
        if "bl_rna" in cls.__dict__:
            bpy.utils.unregister_class(cls)
