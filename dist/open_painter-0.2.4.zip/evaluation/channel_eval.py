"""Resolve raster/procedural channel inputs and texture-space effect stacks.

Unfiltered sources retain cooperative row tiling. Shared scalar procedurals are
cached across channels. Neighborhood effects evaluate the actual full raster
once, then serve slices; no effect wraps across row-tile boundaries.
"""

import numpy as np

from ..core.image_manager import pixels
from .blend_modes import sample_uv
from ..texture_engine import filters, procedurals

TILE_ROWS = 16

NEIGHBORHOOD_EFFECTS = frozenset({
    "BLUR", "GAUSSIAN_BLUR", "DIRECTIONAL_BLUR", "RADIAL_BLUR", "SLOPE_BLUR",
    "HIGH_PASS", "SHARPEN", "DILATE", "ERODE", "MORPHOLOGICAL_EXPAND",
    "MORPHOLOGICAL_CONTRACT", "EDGE_DETECT", "SMOOTH_MASK", "WARP",
    "DIRECTIONAL_WARP", "VECTOR_WARP", "UV_DISTORTION", "TWIRL", "RIPPLE", "WAVE",
    "NON_UNIFORM_TRANSFORM", "HEIGHT_TO_NORMAL", "NORMAL_COMBINE",
})


EFFECT_UI_FIELDS = {
    "LEVELS": ("black", "white", "gamma", "output_black", "output_white"),
    "GAMMA": ("gamma",), "CLAMP": ("black", "white"),
    "HISTOGRAM_SCAN": ("amount", "softness", "contrast"),
    "HISTOGRAM_RANGE": ("black", "white", "softness"), "THRESHOLD": ("amount",),
    "BRIGHTNESS_CONTRAST": ("amount", "contrast"),
    "POSTERIZE": ("steps",), "QUANTIZE": ("steps",),
    "SHARPEN": ("radius", "amount"),
    "DIRECTIONAL_BLUR": ("radius", "angle", "samples"),
    "RADIAL_BLUR": ("radius", "samples"),
    "SLOPE_BLUR": ("radius", "amount", "noise", "scale", "seed", "samples", "mode"),
    "WARP": ("radius", "amount", "noise", "scale", "seed"),
    "DIRECTIONAL_WARP": ("radius", "amount", "angle", "noise", "scale", "seed"),
    "VECTOR_WARP": ("radius", "amount", "noise", "scale", "seed"),
    "UV_DISTORTION": ("radius", "amount", "noise", "scale", "seed"),
    "TWIRL": ("radius", "angle"), "RIPPLE": ("radius", "amount"),
    "WAVE": ("radius", "amount", "angle"),
    "NON_UNIFORM_TRANSFORM": ("transform_scale", "angle", "offset"),
    "HSL": ("hue", "saturation", "lightness"),
    "HSV": ("hue", "saturation", "lightness"),
    "HUE_SHIFT": ("hue",), "SATURATION": ("saturation",),
    "GRADIENT_MAP": ("color", "color2"), "COLOR_BALANCE": ("color",),
    "COLORIZE": ("color", "amount"), "TINT": ("color", "amount"),
    "TEMPERATURE": ("amount",), "REPLACE_COLOR": ("color", "color2", "softness"),
    "NORMAL_COMBINE": ("image", "amount"), "NORMAL_STRENGTH": ("amount",),
    "HEIGHT_TO_NORMAL": ("amount",), "AO_STRENGTH": ("amount",),
    "ROUGHNESS_CONTRAST": ("contrast",), "CHANNEL_MIXER": ("matrix", "bias"),
    "EDGE_DETECT": ("amount",),
}
for _kind in ("BLUR", "GAUSSIAN_BLUR", "HIGH_PASS", "DILATE", "ERODE",
              "MORPHOLOGICAL_EXPAND", "MORPHOLOGICAL_CONTRACT", "SMOOTH_MASK"):
    EFFECT_UI_FIELDS[_kind] = ("radius",)
for _kind in ("ROUGHNESS_REMAP", "METALLIC_REMAP", "HEIGHT_REMAP"):
    EFFECT_UI_FIELDS[_kind] = EFFECT_UI_FIELDS["LEVELS"]


def effect_ui_fields(kind):
    """Native control schema, shared with mask/channel properties panels."""
    labels = {"black": "Input Black", "white": "Input White", "noise": "Driving Noise",
              "scale": "Noise Scale", "seed": "Noise Seed", "hue": "Hue Shift",
              "color": "Color", "color2": "Second Color", "image": "Detail Normal"}
    if kind in {"THRESHOLD", "HISTOGRAM_SCAN"}:
        labels["amount"] = "Position"
    elif kind == "BRIGHTNESS_CONTRAST":
        labels["amount"] = "Brightness"
    elif kind in {"WARP", "SLOPE_BLUR", "DIRECTIONAL_WARP", "VECTOR_WARP", "UV_DISTORTION", "WAVE", "RIPPLE"}:
        labels["amount"] = "Displacement Factor"
    elif kind in {"NORMAL_COMBINE", "NORMAL_STRENGTH", "HEIGHT_TO_NORMAL", "AO_STRENGTH", "EDGE_DETECT"}:
        labels["amount"] = "Intensity"
    if kind == "GRADIENT_MAP":
        labels.update(color="Black Color", color2="White Color")
    return tuple((name, labels.get(name, name.replace("_", " ").title()))
                 for name in EFFECT_UI_FIELDS.get(kind, ()))


def effect_parameters(effect):
    """Translate persistent effect controls to the pure texture-filter API.

    Effect strength is stack opacity and is deliberately not passed as filter
    displacement. Displacement uses radius * amount in pixels. RNA angles use
    radians; the independent filter API uses degrees.
    """
    defaults = {"radius": 2, "amount": .5, "contrast": 1, "gamma": 1,
                "black": 0, "white": 1, "output_black": 0, "output_white": 1,
                "hue": 0, "saturation": 1, "lightness": 0, "softness": .05,
                "steps": 4, "samples": 8, "mode": "BLUR", "offset": (0, 0),
                "color": (0, 0, 0), "color2": (1, 1, 1),
                "matrix": (1, 0, 0, 0, 1, 0, 0, 0, 1), "bias": (0, 0, 0)}
    params = {key: getattr(effect, key, value) for key, value in defaults.items()}
    params["angle"] = np.degrees(getattr(effect, "angle", 0))
    params["scale"] = tuple(getattr(effect, "transform_scale", (1, 1)))
    params["tolerance"] = params["softness"]
    params["position"] = params["amount"]
    params["brightness"] = params["amount"]
    params["value"] = params["lightness"]
    params["strength"] = params["amount"]
    if effect.kind in {"WARP", "SLOPE_BLUR", "DIRECTIONAL_WARP", "VECTOR_WARP",
                       "UV_DISTORTION", "RIPPLE", "WAVE"}:
        params["strength"] = params["radius"] * params["amount"]
    return params


def apply_effect(data, effect):
    """Apply one persistent effect to a complete texture; preserve RGBA coverage.

    Grayscale colorization/normal conversion can return RGB. Effect opacity blends
    against the original expanded grayscale. Reusable by layer and mask stacks.
    """
    if not effect.enabled or effect.strength <= 0:
        return data
    source = np.asarray(data, np.float32)
    alpha = source[..., 3:4] if source.ndim == 3 and source.shape[-1] == 4 else None
    original = source[..., :3] if alpha is not None else source
    params = effect_parameters(effect)
    if effect.kind in {"WARP", "SLOPE_BLUR", "DIRECTIONAL_WARP", "VECTOR_WARP", "UV_DISTORTION"}:
        h, w = source.shape[:2]
        y, x = np.indices((h, w), dtype=np.float32)
        u, v = (x + .5) / w, (y + .5) / h
        noise = getattr(effect, "noise", "FBM")
        scale, seed = getattr(effect, "scale", 8), getattr(effect, "seed", 1)
        field = procedurals.evaluate(noise, u, v, seed=seed, scale=scale)
        if effect.kind in {"VECTOR_WARP", "UV_DISTORTION"}:
            field = np.stack((field, procedurals.evaluate(noise, u, v, seed=seed + 37, scale=scale)), axis=-1)
        params["field"] = field
    if effect.kind == "NORMAL_COMBINE":
        detail = getattr(effect, "image", None)
        if detail is None:
            raise ValueError("Normal Combine needs a detail normal texture.")
        image = pixels(detail)[..., :3]
        if image.shape[:2] != source.shape[:2]:
            h, w = source.shape[:2]
            y, x = np.indices((h, w), dtype=np.float32)
            image = sample_uv(image, (x + .5) / w, (y + .5) / h)
        params["detail"] = filters.apply(image, "NORMAL_STRENGTH", strength=params["amount"])
    filtered = filters.apply(original, effect.kind, **params)
    if original.ndim == 2 and filtered.ndim == 3:
        original = original[..., None]
    elif original.ndim == 3 and filtered.ndim == 2:
        filtered = filtered[..., None]
    result = original + (filtered - original) * effect.strength
    if alpha is not None:
        if result.shape[-1] == 1:
            result = np.repeat(result, 3, axis=-1)
        result = np.concatenate((result, alpha), axis=-1)
    return np.asarray(result, np.float32)


def apply_texture_effects(data, effects):
    for effect in effects:
        data = apply_effect(data, effect)
    return data


def _coordinates(prop, n, y0, y1):
    u, v = np.meshgrid((np.arange(n, dtype=np.float32) + .5) / n,
                       (np.arange(y0, y1, dtype=np.float32) + .5) / n)
    u, v = (u - .5) * prop.scale[0], (v - .5) * prop.scale[1]
    cs, sn = np.cos(prop.rotation), np.sin(prop.rotation)
    return cs * u - sn * v + .5 + prop.offset[0], sn * u + cs * v + .5 + prop.offset[1]


def _procedural_block(prop, n, y0, y1, ts, geometry_cache):
    """Cache source scalar by coordinates, excluding the destination channel."""
    key = ("procedural", getattr(ts, "id", ""),
           getattr(geometry_cache, "geometry_stamp", None) if prop.projection == "TRIPLANAR" else None,
           n, y0, y1, prop.procedural, prop.procedural_scale, prop.procedural_seed,
           prop.projection, tuple(prop.scale), prop.rotation, tuple(prop.offset),
           prop.triplanar_hardness)
    if key not in geometry_cache:
        if prop.projection == "TRIPLANAR":
            from ..painting.projection import geometry
            if "geometry" in geometry_cache:
                positions, normals = geometry_cache["geometry"]
            else:
                positions, normals = geometry(ts, n)
                geometry_cache["geometry"] = (positions, normals)
            positions, normals = positions[y0:y1], normals[y0:y1]
            weights = np.abs(normals)
            weights = (weights / np.maximum(weights.max(axis=-1, keepdims=True), 1e-8)) ** prop.triplanar_hardness
            weights /= np.maximum(weights.sum(axis=-1, keepdims=True), 1e-8)
            result = np.zeros((y1 - y0, n), np.float32)
            cs, sn = np.cos(prop.rotation), np.sin(prop.rotation)
            for axis, (a, b) in enumerate(((1, 2), (0, 2), (0, 1))):
                if not np.any(weights[..., axis] > 1e-8):
                    continue
                u, v = positions[..., a] * prop.scale[0], positions[..., b] * prop.scale[1]
                u, v = cs * u - sn * v + prop.offset[0], sn * u + cs * v + prop.offset[1]
                result += procedurals.evaluate(prop.procedural, u, v, seed=prop.procedural_seed,
                                                scale=prop.procedural_scale) * weights[..., axis]
        else:
            u, v = _coordinates(prop, n, y0, y1)
            result = procedurals.evaluate(prop.procedural, u, v, seed=prop.procedural_seed,
                                           scale=prop.procedural_scale)
        geometry_cache[key] = result
        return result
    return geometry_cache[key]


def _procedural_tile(prop, n, y0, y1, ts, geometry_cache):
    # Canonical row blocks allow full-raster filters, brush regions and preview
    # jobs to share exactly the same raw source cache instead of duplicating it.
    parts = []
    for low in range(y0 // TILE_ROWS * TILE_ROWS, y1, TILE_ROWS):
        high = min(low + TILE_ROWS, n)
        value = _procedural_block(prop, n, low, high, ts, geometry_cache)
        parts.append(value[max(y0 - low, 0):min(y1 - low, high - low)])
    return parts[0] if len(parts) == 1 else np.concatenate(parts)


def _raw_source(prop, kind, n, y0, y1, cache, ts, geometry_cache):
    rgba = _base_source(prop, kind, n, y0, y1, cache, ts, geometry_cache)
    # Mask fill properties also have a `procedural` field, but an image fill must
    # remain an image fill. Their dedicated PROCEDURAL source is evaluated by masks.
    if kind != "FILL" or not hasattr(prop, "channel") or not getattr(prop, "procedural", ""):
        return rgba
    scalar = _procedural_tile(prop, n, y0, y1, ts, geometry_cache)
    out = np.broadcast_to(rgba, (y1 - y0, n, 4)).copy()
    if prop.channel == "HEIGHT":
        out[..., :3] = (.5 + (scalar - .5) * prop.procedural_height)[..., None]
    elif prop.channel in {"BASE_COLOR", "EMISSION"}:
        out[..., :3] *= (1 + (scalar - .5) * prop.procedural_detail)[..., None]
    elif prop.channel == "NORMAL":
        # A one-pixel scalar halo gives the same centered derivatives as a full
        # raster while avoiding a full-resolution RGB normal cache at 8K.
        parts = []
        if y0:
            parts.append(_procedural_tile(prop, n, y0 - 1, y0, ts, geometry_cache))
        parts.append(scalar)
        if y1 < n:
            parts.append(_procedural_tile(prop, n, y1, y1 + 1, ts, geometry_cache))
        height = np.concatenate(parts)
        normal = filters.height_to_normal(height, prop.procedural_height * n)
        start = 1 if y0 else 0
        out[..., :3] = filters.normal_combine(out[..., :3], normal[start:start + y1 - y0])
    else:
        out[..., :3] += ((scalar - .5) * prop.procedural_detail * .35)[..., None]
    if prop.projection == "UV" and prop.tiling == "NONE":
        u, v = _coordinates(prop, n, y0, y1)
        out[..., 3] *= (u >= 0) & (u <= 1) & (v >= 0) & (v <= 1)
    out[..., :3] = np.clip(out[..., :3], 0, 1)
    return out


def source(prop, kind, n, y0, y1, cache, ts, geometry_cache):
    effects = tuple(effect for effect in getattr(prop, "effects", ()) if effect.enabled and effect.strength > 0)
    if not effects:
        return _raw_source(prop, kind, n, y0, y1, cache, ts, geometry_cache)
    if not any(effect.kind in NEIGHBORHOOD_EFFECTS for effect in effects):
        # Levels, hue and other pointwise operations remain cooperative and need
        # neither a full-resolution temporary nor a second whole-image cache.
        rgba = _raw_source(prop, kind, n, y0, y1, cache, ts, geometry_cache)
        return apply_texture_effects(np.broadcast_to(rgba, (y1 - y0, n, 4)), effects)
    from .operation_contracts import stack_footprint
    from .tiles import expand
    halo = stack_footprint(effects)
    if halo is not None:
        low, high = expand(y0, y1, halo, n)
        raster = np.empty((high - low, n, 4), np.float32)
        for start in range(low, high, TILE_ROWS):
            stop = min(start + TILE_ROWS, high)
            raster[start - low:stop - low] = _raw_source(prop, kind, n, start, stop, cache, ts, geometry_cache)
        return apply_texture_effects(raster, effects)[y0 - low:y1 - low]
    # The pixel cache belongs to the current channel evaluation; keep filtered
    # RGBA here rather than retaining every layer/channel result in geometry cache.
    key = ("filtered_channel", prop.as_pointer(), n, getattr(ts, "edit_serial", 0))
    if key not in cache:
        raster = np.empty((n, n, 4), np.float32)
        for low in range(0, n, TILE_ROWS):
            high = min(low + TILE_ROWS, n)
            raster[low:high] = _raw_source(prop, kind, n, low, high, cache, ts, geometry_cache)
        cache[key] = apply_texture_effects(raster, effects)
    return cache[key][y0:y1]


def _base_source(prop, kind, n, y0, y1, cache, ts, geometry_cache):
    if getattr(prop, "image_name", "") and not prop.image:
        raise ValueError(
            f"Texture image is missing: {prop.image_name}. Reload or clear the channel texture."
        )
    if prop.image:
        from .image_snapshots import read
        key = (prop.image.as_pointer(), "linear")
        if key not in cache:
            cache[key] = read(cache, prop.image, linear=True)
        if kind == "PAINT" and cache[key].shape[:2] == (n, n):
            # Paint pixels already occupy the output UV grid. Resampling four
            # neighbours per pixel was the dominant cost of every brush update.
            rgba = cache[key][y0:y1].copy()
            if prop.image.is_float:
                np.divide(
                    rgba[..., :3], rgba[..., 3:4], out=rgba[..., :3], where=rgba[..., 3:4] > 1e-8
                )
                rgba[..., :3][rgba[..., 3] <= 1e-8] = 0
            return rgba
        if kind == "FILL" and prop.projection == "TRIPLANAR":
            from ..painting.projection import geometry, triplanar

            if "geometry" in geometry_cache:
                positions, normals = geometry_cache["geometry"]
            else:
                positions, normals = geometry(ts, n)
                geometry_cache["geometry"] = (positions, normals)
            return triplanar(cache[key], positions[y0:y1], normals[y0:y1], prop)
        u, v = np.meshgrid(
            (np.arange(n, dtype=np.float32) + 0.5) / n,
            (np.arange(y0, y1, dtype=np.float32) + 0.5) / n,
        )
        if kind == "FILL":
            u, v = (u - 0.5) * prop.scale[0], (v - 0.5) * prop.scale[1]
            cs, sn = np.cos(prop.rotation), np.sin(prop.rotation)
            u, v = cs * u - sn * v + 0.5 + prop.offset[0], sn * u + cs * v + 0.5 + prop.offset[1]
        rgba = (
            sample_uv(cache[key], u, v, prop.filtering, prop.tiling)
            if kind == "FILL"
            else sample_uv(cache[key], u, v)
        )
        if kind == "PAINT" and prop.image.is_float:
            # Blender's native float brush buffers are premultiplied.
            rgba[..., :3] = np.divide(
                rgba[..., :3],
                rgba[..., 3:4],
                out=np.zeros_like(rgba[..., :3]),
                where=rgba[..., 3:4] > 1e-8,
            )
        return rgba
    if kind == "PAINT":
        return np.array([0, 0, 0, 0], dtype=np.float32)
    if prop.channel in {"BASE_COLOR", "NORMAL", "EMISSION"}:
        return np.array(prop.color, dtype=np.float32)
    return np.array([prop.value, prop.value, prop.value, 1], dtype=np.float32)
