import bpy, time, re, os, random, numpy
from bpy.props import *
from bpy_extras.io_utils import ImportHelper
from . import Modifier, lib, Mask, transition, ImageAtlas, UDIM, NormalMapModifier, ListItem, BaseOperator, Decal, channel_common, layer_common, modifier_common
from .common import *
#from . import bake_common
from .node_arrangements import *
from .node_connections import *
from .subtree import *
from .input_outputs import *

DEFAULT_NEW_IMG_SUFFIX = ' Layer'
if not is_bl_newer_than(3, 2):
    DEFAULT_NEW_VCOL_SUFFIX = ' VCol'
else: DEFAULT_NEW_VCOL_SUFFIX = ' Attribute'
DEFAULT_NEW_VDM_SUFFIX = ' VDM'

TEMP_TREE_PREFIX = '____TEMP__'

def active_layer_op_poll(context):
    if not context.object: return False
    group_node = get_active_ypaint_node()
    if not group_node: return False
    layer = ListItem.get_active_layer(group_node.node_tree.yp)
    if not layer: return False
    return True

class YRefreshNeighborUV(bpy.types.Operator):
    """Refresh Neighbor UV"""
    bl_idname = "wm.y_refresh_neighbor_uv"
    bl_label = "Refresh Neighbor UV"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return hasattr(context, 'layer') and hasattr(context, 'channel') and hasattr(context, 'image') and context.image

    def execute(self, context):
        set_uv_neighbor_resolution(context.layer)
        return {'FINISHED'}

class YUseLinearColorSpace(bpy.types.Operator):
    """This addon need to linear color space image to works properly"""
    bl_idname = "wm.y_use_linear_color_space"
    bl_label = "Use Linear Color Space"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def execute(self, context):
        node = get_active_ypaint_node()
        yp = node.node_tree.yp
        check_yp_linear_nodes(yp)

        return {'FINISHED'}

class YFixMissingSource(bpy.types.Operator):
    """Fix missing source of the layer"""
    bl_idname = "wm.y_fix_missing_layer_source"
    bl_label = "Fix Missing Layer Source"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return hasattr(context, 'layer') #and hasattr(context, 'channel') and hasattr(context, 'image') and context.image

    def execute(self, context):
        layer_common.check_layer_source(context.layer)
        reconnect_layer_nodes(context.layer)
        rearrange_layer_nodes(context.layer)
        return {'FINISHED'}

class YNewVcolToOverrideChannel(bpy.types.Operator):
    bl_idname = "wm.y_new_vcol_to_override_channel"
    bl_label = "New "+get_vertex_color_label()+" to Layer Channel Source"
    bl_description = "New "+get_vertex_color_label()+" to custom layer channel source"
    bl_options = {'UNDO'}

    name : StringProperty(default='')

    data_type : EnumProperty(
        name = get_vertex_color_label()+' Data Type',
        description = get_vertex_color_label(10)+' data type',
        items = vcol_data_type_items,
        default = 'BYTE_COLOR'
    )

    domain : EnumProperty(
        name = get_vertex_color_label()+' Domain',
        description = get_vertex_color_label(10)+' domain',
        items = vcol_domain_items,
        default = 'CORNER'
    )

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    @classmethod
    def description(self, context, properties):
        return get_operator_description(self)

    def invoke(self, context, event):
        self.ch = context.parent

        yp = self.ch.id_data.yp
        m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.ch.path_from_id())
        if not m: return []
        layer = yp.layers[int(m.group(1))]
        root_ch = yp.channels[int(m.group(2))]
        self.tree = get_tree(layer)

        self.name = layer.name + ' ' + root_ch.name +  ' Override'

        if get_user_preferences().skip_property_popups and not event.shift:
            return self.execute(context)

        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context):
        row = split_layout(self.layout, 0.4)

        col = row.column()
        col.label(text='Name:')

        if is_bl_newer_than(3, 2):
            col.label(text='Domain:')
            col.label(text='Data Type:')

        col = row.column()
        col.prop(self, 'name', text='')

        if is_bl_newer_than(3, 2):
            crow = col.row(align=True)
            crow.prop(self, 'domain', expand=True)
            crow = col.row(align=True)
            crow.prop(self, 'data_type', expand=True)

    def execute(self, context):

        T = time.time()

        ch = self.ch
        yp = ch.id_data.yp
        m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', ch.path_from_id())
        if not m: 
            self.report({'ERROR'}, 'Not a valid channel!')
            return {'CANCELLED'}
        root_ch = yp.channels[int(m.group(2))]

        tree = self.tree
        obj = context.object
        mat = obj.active_material
        wm = context.window_manager

        if self.name == '' :
            self.report({'ERROR'}, get_vertex_color_label(10)+" cannot be empty!")
            return {'CANCELLED'}

        # Make sure channel is on
        if not ch.enable:
            ch.enable = True

        # Make sure override is on
        if not ch.override:
            ch.override = True

        objs = [obj] if obj.type == 'MESH' else []
        if mat.users > 1:
            for o in get_scene_objects():
                if o.type != 'MESH': continue
                if mat.name in o.data.materials and o not in objs:
                    objs.append(o)

        for o in objs:
            if self.name not in get_vertex_colors(o):
                if not is_bl_newer_than(3, 3) and len(get_vertex_colors(o)) >= 8: continue
                vcol = new_vertex_color(o, self.name, self.data_type, self.domain, color_fill=(1.0, 1.0, 1.0, 1.0))
                set_active_vertex_color(o, vcol)

        # Update vcol cache
        if ch.override_type == 'VCOL':
            source_label = root_ch.name + ' Override : ' + ch.override_type
            vcol_node, dirty = check_new_node(tree, ch, 'source', get_vcol_bl_idname(), source_label, True)
        else: vcol_node, dirty = check_new_node(tree, ch, 'cache_vcol', get_vcol_bl_idname(), '', True)

        set_source_vcol_name(vcol_node, self.name)

        # Set vcol name attribute
        yp.halt_update = True
        ch.override_vcol_name = self.name
        yp.halt_update = False

        ch.override_type = 'VCOL'
        ch.active_edit = True

        # Update UI
        wm.ypui.need_update = True
        print('INFO: '+get_vertex_color_label()+' is created in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

def update_channel_idx_new_layer(self, context):

    node = get_active_ypaint_node()
    yp = node.node_tree.yp

    # Bump map will use cubic interpolation
    channel_idx = BaseOperator.get_self_channel_idx(self)
    if channel_idx != -1 and channel_idx < len(yp.channels):
        channel = yp.channels[channel_idx]
    else: channel = None

    if channel and channel.special_type == 'HEIGHT':
        self.interpolation = 'Cubic'
        if hasattr(self, 'mask_interpolation'): self.mask_interpolation = 'Cubic'

class YNewVDMLayer(bpy.types.Operator):
    bl_idname = "wm.y_new_vdm_layer"
    bl_label = "New VDM Layer"
    bl_description = "New Vector Displacement Layer"
    bl_options = {'UNDO'}

    name : StringProperty(name='Layer Name', default='')

    width : IntProperty(name='Width', default=1024, min=1, max=16384)
    height : IntProperty(name='Height', default=1024, min=1, max=16384)

    image_resolution : EnumProperty(
        name = 'Image Resolution',
        items = image_resolution_items,
        default = '1024'
    )

    use_custom_resolution : BoolProperty(
        name = 'Custom Resolution',
        description = 'Use custom Resolution to adjust the width and height individually',
        default = False
    )

    blend_type : EnumProperty(
        name = 'Blend Type',
        items = blend_type_items,
        #default = 'ADD'
    )

    use_udim : BoolProperty(
        name = 'Use UDIM Tiles',
        description = 'Use UDIM Tiles',
        default = False
    )

    enable_subdiv_setup : BoolProperty(
        name = 'Enable Displacement Setup',
        description = 'Enable Displacement Setup on Normal channel',
        default = True
    )

    # NOTE: UDIM is not supported yet, so no UDIM checking
    uv_map : StringProperty(
        name = 'UV Map', 
        description = 'UV Map to use for layer coordinate',
        default = '') #, update=BaseOperator.update_uv_map_name)
    uv_map_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    @classmethod
    def poll(cls, context):
        return context.object and context.object.type == 'MESH' and get_active_ypaint_node()

    @classmethod
    def description(self, context, properties):
        return get_operator_description(self)

    def invoke(self, context, event):
        ypup = get_user_preferences()
        obj = context.object
        node = get_active_ypaint_node()
        yp = node.node_tree.yp

        # Set default name
        name = obj.active_material.name + DEFAULT_NEW_VDM_SUFFIX
        self.name = get_unique_name(name, bpy.data.images)

        # Set default blend type
        self.blend_type = 'ADD'

        # Use user preference default image size
        if ypup.default_image_resolution == 'CUSTOM':
            self.use_custom_resolution = True
            self.width = self.height = ypup.default_new_image_size
        elif ypup.default_image_resolution != 'DEFAULT':
            self.image_resolution = ypup.default_image_resolution

        # Set default UV name
        #uv_name = get_default_uv_name(obj, yp)
        uv_name = get_active_render_uv(obj)
        self.uv_map = uv_name

        # UV Map collections update
        self.uv_map_coll.clear()
        for uv in get_uv_layers(obj):
            if not uv.name.startswith(TEMP_UV):
                self.uv_map_coll.add().name = uv.name

        if get_user_preferences().skip_property_popups and not event.shift:
            return self.execute(context)

        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context):

        node = get_active_ypaint_node()
        yp = node.node_tree.yp
        first_vdm = get_first_vdm_layer(yp)

        layout = self.layout

        split_val = 0.4

        row = split_layout(layout, split_val)
        right_aligned_label(row, text='Name:')
        row.prop(self, 'name', text='')

        BaseOperator.draw_base_image_settings(self, layout, split_val)

        row = split_layout(layout, split_val)
        right_aligned_label(row, 'Blend Type:')
        row.prop(self, 'blend_type', text='')

        row = split_layout(layout, split_val)
        right_aligned_label(row, 'UV Map:')

        if not first_vdm:
            row.prop_search(self, "uv_map", self, "uv_map_coll", text='', icon='GROUP_UVS')
        else: row.label(text=self.uv_map + '*') # + ' (used by other VDM)')

        # NOTE: UDIM is not supported yet
        if False:
            row = split_layout(layout, split_val)
            row.label(text='')
            row.prop(self, 'use_udim')

        if first_vdm:
            layout.label(text='* Only one UV map is currently supported')

        #height_root_ch = get_root_height_channel(yp)
        #if height_root_ch and not height_root_ch.enable_subdiv_setup:
        if get_displacement_method() == 'BUMP':
            col = layout.column()
            col.label(text='Displacement Setup is not enabled yet!', icon='ERROR')
            col.prop(self, 'enable_subdiv_setup')

    def check(self, context):
        if not self.use_custom_resolution:
            self.width = int(self.image_resolution)
            self.height = int(self.image_resolution)

        return True

    def execute(self, context):
        T = time.time()

        wm = context.window_manager
        node = get_active_ypaint_node()
        yp = node.node_tree.yp

        mat = get_active_material()
        objs = get_all_objects_with_same_materials(mat)

        vdisp_root_ch = get_root_vdisp_channel(yp)
        if not vdisp_root_ch:
            #self.report({'ERROR'}, "There should be a Vector Displacement channel!")
            #return {'CANCELLED'}
            #bpy.ops.wm.y_auto_setup_new_ypaint_channel(mode='VDISP')
            channel_common.auto_setup_active_yp_new_channel('VDISP')
            vdisp_root_ch = get_root_vdisp_channel(yp)
        channel_idx = get_channel_index(vdisp_root_ch)

        alpha = True
        color = (0, 0, 0, 0)

        if self.use_udim:
            tilenums = UDIM.get_tile_numbers(objs, self.uv_map)

            img = bpy.data.images.new(
                name=self.name, width=self.width, height=self.height, 
                alpha=alpha, float_buffer=True, tiled=True
            )

            # Fill tiles
            for tilenum in tilenums:
                UDIM.fill_tile(img, tilenum, color, self.width, self.height)
            UDIM.initial_pack_udim(img, color)

        else:
            img = bpy.data.images.new(
                name=self.name, width=self.width, height=self.height, 
                alpha=alpha, float_buffer=True
            )

        #img.generated_type = self.generated_type
        img.generated_type = 'BLANK'
        img.generated_color = color
        if hasattr(img, 'use_alpha'):
            img.use_alpha = True

        update_image_editor_image(context, img)

        yp.halt_update = True

        layer = layer_common.add_new_layer(
            group_tree=node.node_tree, layer_name=self.name,
            layer_type='IMAGE', channel_idx=channel_idx,
            blend_type=self.blend_type, 
            normal_blend_type='MIX', # Unused anymore
            normal_map_type='VECTOR_DISPLACEMENT_MAP',# Unused anymore
            texcoord_type='UV', uv_name=self.uv_map, image=img,
            interpolation = 'Cubic'
        )

        yp.halt_update = False

        # Reconnect and rearrange nodes
        reconnect_yp_nodes(node.node_tree)
        rearrange_yp_nodes(node.node_tree)

        # Update UI
        ypui = context.window_manager.ypui
        ypui.layer_ui.expand_channels = False
        ypui.layer_ui.expand_content = False
        ypui.layer_ui.expand_source = False
        ch = layer.channels[channel_idx]
        ch.expand_content = True
        ypui.need_update = True

        # Set uv map active render
        for obj in objs:
            uv_layers = get_uv_layers(obj)
            uv = uv_layers.get(self.uv_map)
            if uv and not uv.active_render:
                uv.active_render = True

        # Call operator to do displacement setup
        if self.enable_subdiv_setup and get_displacement_method() == 'BUMP':
            bpy.ops.wm.y_quick_displacement_setup(displacement_method='BOTH', max_polys=1000, use_adaptive_subdivision=False)

        print('INFO: VDM Layer', layer.name, 'is created in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YNewLayer(bpy.types.Operator):
    bl_idname = "wm.y_new_layer"
    bl_label = "New Layer"
    bl_description = "New Layer"
    bl_options = {'REGISTER', 'UNDO'}

    name : StringProperty(name='Layer Name', default='')

    type : EnumProperty(
        name = 'Layer Type',
        items = layer_type_items,
        default = 'IMAGE'
    )

    # For image layer
    width : IntProperty(name='Width', default=1024, min=1, max=16384)
    height : IntProperty(name='Height', default=1024, min=1, max=16384)
    #color : FloatVectorProperty(name='Color', size=4, subtype='COLOR', default=(0.0,0.0,0.0,0.0), min=0.0, max=1.0)
    #alpha : BoolProperty(name='Alpha', default=True)
    hdr : BoolProperty(
        name = '32-bit Float',
        description = 'Use 32-bit float image',
        default = False
    )

    interpolation : EnumProperty(
        name = 'Image Interpolation Type',
        description = 'Image interpolation type',
        items = interpolation_type_items,
        default = 'Linear'
    )

    texcoord_type : EnumProperty(
        name = 'Layer Coordinate Type',
        description = 'Layer Coordinate Type',
        items = texcoord_type_items,
        default = 'UV'
    )

    channel_idx : EnumProperty(
        name = 'Channel',
        description = 'Channel of new layer, can be changed later',
        items = BaseOperator.channel_items,
        update = update_channel_idx_new_layer
    )

    blend_type : EnumProperty(
        name = 'Blend',
        description = 'Blend type',
        items = blend_type_items,
    )

    height_blend_type : EnumProperty(
        name = 'Height Blend Type',
        description = 'Height blend type',
        items = height_blend_type_items,
    )

    normal_blend_type : EnumProperty(
        name = 'Normal Blend Type',
        description = 'Normal blend type',
        items = normal_blend_type_items,
        default = 'MIX'
    )

    solid_color : FloatVectorProperty(
        name = 'Solid Color',
        size = 3,
        subtype = 'COLOR',
        default=(1.0, 1.0, 1.0), min=0.0, max=1.0
    )

    add_mask : BoolProperty(
        name = 'Add Mask',
        description = 'Add mask to new layer',
        default = False
    )

    mask_type : EnumProperty(
        name = 'Mask Type',
        description = 'Mask type',
        items = (
            ('IMAGE', 'Image', '', 'IMAGE_DATA', 0),
            ('VCOL', get_vertex_color_label(), '', 'GROUP_VCOL', 1),
            ('COLOR_ID', 'Color ID', '', 'COLOR', 2),
            ('EDGE_DETECT', 'Edge Detect', '', 'MESH_CUBE', 3)
        ),
        default = 'IMAGE'
    )

    mask_color : EnumProperty(
        name = 'Mask Color',
        description = 'Mask Color',
        items = (
            ('WHITE', 'White (Full Opacity)', ''),
            ('BLACK', 'Black (Full Transparency)', ''),
        ),
        default = 'BLACK'
    )

    mask_width : IntProperty(name='Mask Width', default=1024, min=1, max=4096)
    mask_height : IntProperty(name='Mask Height', default=1024, min=1, max=4096)

    mask_image_resolution : EnumProperty(
        name = 'Image Resolution',
        items = image_resolution_items,
        default = '1024'
    )
    
    mask_use_custom_resolution : BoolProperty(
        name = 'Custom Resolution',
        description= 'Use custom Resolution to adjust the width and height individually',
        default = False
    )

    mask_interpolation : EnumProperty(
        name = 'Mask Image Interpolation Type',
        description = 'Mask image interpolation type',
        items = interpolation_type_items,
        default = 'Linear'
    )

    mask_texcoord_type : EnumProperty(
        name = 'Mask Coordinate Type',
        description = 'Mask Coordinate Type',
        items = texcoord_type_items,
        default = 'UV'
    )

    mask_uv_name : StringProperty(
        name='UV Map for Mask', 
        description = 'UV Map to use for mask coordinate',
        default='', update=BaseOperator.update_mask_uv_map_name
    )

    mask_use_hdr : BoolProperty(
        name = '32-bit Float',
        description = 'Use 32-bit float image for mask',
        default = False
    )

    mask_color_id : FloatVectorProperty(
        name = 'Color ID',
        size = 3,
        subtype = 'COLOR',
        default=(1.0, 0.0, 1.0), min=0.0, max=1.0
    )

    mask_vcol_fill : BoolProperty(
        name = 'Fill Selected Geometry with '+get_vertex_color_label()+' / Color ID Mask',
        description = 'Fill selected geometry with '+get_vertex_color_label(00)+' or color ID mask',
        default = True
    )
    
    mask_image_filepath : StringProperty(
        name = 'Mask Image Path',
        description = 'Path to mask image',
        default = '',
        subtype = 'FILE_PATH',
        options = {'SKIP_SAVE'}
    )

    mask_relative : BoolProperty(name="Relative Mask Path", default=True, description="Apply relative paths")

    uv_map : StringProperty(
        name = 'UV Map',
        description = 'UV Map to use for layer coordinate',
        default = '',
        update = BaseOperator.update_uv_map_name
    )

    normal_map_type : EnumProperty(
        name = 'Normal Map Type',
        description = 'Normal map type of this layer',
        items = layer_common.get_normal_map_type_items
    )

    normal_space : EnumProperty(
        name = 'Normal Map Space',
        description = 'Normal map space of this layer',
        items = normal_space_items,
        default = 'TANGENT'
    )

    use_udim : BoolProperty(
        name = 'Use UDIM Tiles',
        description = 'Use UDIM Tiles',
        default = False
    )

    use_udim_for_mask : BoolProperty(
        name = 'Use UDIM Tiles for Mask',
        description='Use UDIM Tiles for Mask',
        default = False
    )

    use_image_atlas : BoolProperty(
        name = 'Use Image Atlas',
        description = 'Use shared image for multiple layers/masks, can save image slots for Blender with OpenGL',
        default = False
    )

    use_image_atlas_for_mask : BoolProperty(
        name = 'Use Image Atlas for Mask',
        description='Use Image Atlas for Mask',
        default = False
    )

    hemi_space : EnumProperty(
        name = 'Fake Lighting Space',
        description = 'Fake lighting space',
        items = hemi_space_items,
        default = 'WORLD'
    )

    hemi_use_prev_normal : BoolProperty(
        name = 'Use previous Normal',
        description = 'Take account previous Normal',
        default = True
    )

    vcol_data_type : EnumProperty(
        name = get_vertex_color_label()+' Data Type',
        description = get_vertex_color_label(10)+' data type',
        items = vcol_data_type_items,
        default = 'BYTE_COLOR'
    )

    vcol_domain : EnumProperty(
        name = get_vertex_color_label()+' Domain',
        description = get_vertex_color_label(10)+' domain',
        items = vcol_domain_items,
        default = 'CORNER'
    )

    mask_vcol_data_type : EnumProperty(
        name = 'Mask '+get_vertex_color_label()+' Data Type',
        description = 'Mask '+get_vertex_color_label(00)+' data type',
        items = vcol_data_type_items,
        default = 'BYTE_COLOR'
    )

    mask_vcol_domain : EnumProperty(
        name = 'Mask '+get_vertex_color_label()+' Domain',
        description = 'Mask '+get_vertex_color_label(00)+' domain',
        items = vcol_domain_items,
        default = 'CORNER'
    )

    use_divider_alpha : BoolProperty(
        name = 'Divide RGB by Alpha',
        description='Divide RGB by its alpha value (very recommended for '+get_vertex_color_label(00)+' layer)',
        default = False
    )

    # For edge detection
    edge_detect_radius : FloatProperty(
        name = 'Edge Detect Radius',
        description = 'Edge detect radius',
        default=0.05, min=0.0, max=10.0
    )

    edge_detect_method : EnumProperty(
        name = 'Edge Detection Method',
        description = 'Edge detection method (Cycles Only)',
        items = (
            ('DOT', 'Dot Product', ''),
            ('CROSS', 'Cross Product', '')
        ),
        default='CROSS',
    )

    mask_edge_detect_radius : FloatProperty(
        name = 'Edge Detect Mask Radius',
        description = 'Edge detect mask radius',
        default=0.05, min=0.0, max=10.0
    )

    mask_edge_detect_method : EnumProperty(
        name = 'Edge Detection Method for Mask',
        description = 'Edge detection method for mask(Cycles Only)',
        items = (
            ('DOT', 'Dot Product', ''),
            ('CROSS', 'Cross Product', '')
        ),
        default='CROSS',
    )

    mask_use_prev_normal : BoolProperty(
        name = 'Use previous Normal for Mask',
        description = 'Take account previous Normal for mask',
        default = True
    )

    ao_distance : FloatProperty(
        name = 'Ambient Occlusion Distance',
        description = 'Ambient occlusion distance',
        default=1.0, min=0.0, max=10.0
    )

    uv_map_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    image_resolution : EnumProperty(
        name = 'Image Resolution',
        items = image_resolution_items,
        default = '1024'
    )

    use_custom_resolution : BoolProperty(
        name= 'Custom Resolution',
        description = 'Use custom Resolution to adjust the width and height individually',
        default = False
    )

    #add_modifier : BoolProperty(
    #    name = 'Add Modifier',
    #    description = 'Add modifier to new layer',
    #    default = False
    #)

    modifier_type : EnumProperty(
        name = 'Modifier Type',
        description = 'Modifier type',
        items = (
            ('INVERT', 'Invert', 'Invert input RGB and/or Alpha', 'MODIFIER', 0),
            ('COLOR_RAMP', 'Color Ramp', '', 'MODIFIER', 1),
            ('RGB_CURVE', 'RGB Curve', '', 'MODIFIER', 2),
            ('HUE_SATURATION', 'Hue Saturation', '', 'MODIFIER', 3),
            ('BRIGHT_CONTRAST', 'Brightness Contrast', '', 'MODIFIER', 4),
            ('MATH', 'Math', '', 'MODIFIER', 5)
        ),
        default = 'RGB_CURVE'
    )

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()
        #return hasattr(context, 'group_node') and context.group_node

    @classmethod
    def description(self, context, properties):
        return get_operator_description(self)

    def invoke(self, context, event):

        ypup = get_user_preferences()
        node = get_active_ypaint_node()
        yp = node.node_tree.yp
        obj = context.object

        if self.type == 'IMAGE':
            name = obj.active_material.name + DEFAULT_NEW_IMG_SUFFIX
            items = bpy.data.images
        elif self.type == 'VCOL' and obj.type == 'MESH':
            name = obj.active_material.name + DEFAULT_NEW_VCOL_SUFFIX
            items = get_vertex_color_names(obj)
        elif self.type == 'PREV_LAYERS':
            if self.modifier_type == 'RGB_CURVE':
                name = 'RGB Curve'
            elif self.modifier_type == 'COLOR_RAMP':
                name = 'Color Ramp'
            elif self.modifier_type == 'HUE_SATURATION':
                name = 'Hue Saturation'
            elif self.modifier_type == 'BRIGHT_CONTRAST':
                name = 'Brightness Contrast'
            elif self.modifier_type == 'MATH':
                name = 'Math'
            elif self.modifier_type == 'INVERT':
                name = 'Invert'
            items = yp.layers
        else:
            name = layer_type_labels[self.type]
            items = yp.layers

        # Use user preference default image size
        if ypup.default_image_resolution == 'CUSTOM':
            self.use_custom_resolution = True
            self.width = self.height = ypup.default_new_image_size
            self.mask_use_custom_resolution = True
            self.mask_width = self.mask_height = ypup.default_new_image_size
        elif ypup.default_image_resolution != 'DEFAULT':
            self.image_resolution = ypup.default_image_resolution
            self.mask_image_resolution = ypup.default_image_resolution

        # Make sure add mask is inactive
        if self.type not in {'COLOR', 'BACKGROUND'}: #, 'GROUP'}:
            self.add_mask = False

        # Set spread fix by default on vertex color layer
        self.use_divider_alpha = True if self.type in {'VCOL'} else False

        # Use white color mask as default for group
        if self.type == 'GROUP':
            self.mask_color = 'WHITE'
        else: self.mask_color = 'BLACK'

        # Fake lighting default blend type is add
        if self.type in {'HEMI', 'EDGE_DETECT'}:
            self.blend_type = 'ADD'
        if self.type == 'AO':
            self.blend_type = 'MULTIPLY'
        else: self.blend_type = 'MIX'

        # Disable use previous normal for edge detect since it has very little effect
        if self.type == 'EDGE_DETECT':
            self.hemi_use_prev_normal = False

        if self.add_mask and self.mask_type == 'EDGE_DETECT':
            self.mask_use_prev_normal = False

        # Layer name
        self.name = get_unique_name(name, items)

        # Layer name must also unique
        if self.type == 'IMAGE':
            self.name = get_unique_name(self.name, yp.layers)

        # Make sure decal is off when adding non mappable layer
        if not is_mapping_possible(self.type) and self.texcoord_type == 'Decal':
            self.texcoord_type = 'UV'
            self.mask_texcoord_type = 'UV'

        # Check if color id already being used
        while True:
            # Use color id tolerance value as lowest value to avoid pure black color
            self.mask_color_id = (random.uniform(COLORID_TOLERANCE, 1.0), random.uniform(COLORID_TOLERANCE, 1.0), random.uniform(COLORID_TOLERANCE, 1.0))
            if not is_colorid_already_being_used(yp, self.mask_color_id): break

        if not is_object_work_with_uv(obj):
            self.texcoord_type = 'Generated'
            self.mask_texcoord_type = 'Generated'

        if obj.type == 'MESH':
            uv_name = get_default_uv_name(obj, yp)
            self.uv_map = uv_name
            if self.add_mask: self.mask_uv_name = uv_name

            # UV Map collections update
            self.uv_map_coll.clear()
            for uv in get_uv_layers(obj):
                if not uv.name.startswith(TEMP_UV):
                    self.uv_map_coll.add().name = uv.name

        if get_user_preferences().skip_property_popups and not event.shift:
            return self.execute(context)

        width = 320
        if self.type == 'EDGE_DETECT' or (self.add_mask and self.mask_type == 'EDGE_DETECT'):
            width = 370

        return context.window_manager.invoke_props_dialog(self, width=width)

    #def is_mask_using_udim(self):
    #    return self.use_udim_for_mask and is_udim_supported()

    #def is_mask_using_image_atlas(self):
    #    return self.use_image_atlas_for_mask and not self.is_mask_using_udim()

    def check(self, context):
        ypup = get_user_preferences()

        if not self.use_custom_resolution:
            self.width = int(self.image_resolution)
            self.height = int(self.image_resolution)

        if not self.mask_use_custom_resolution:
            self.mask_width = int(self.mask_image_resolution)
            self.mask_height = int(self.mask_image_resolution)

        # New image cannot use more pixels than the image atlas
        if self.use_image_atlas:
            if self.hdr: max_size = ypup.hdr_image_atlas_size
            else: max_size = ypup.image_atlas_size
            if self.width > max_size: self.width = max_size
            if self.height > max_size: self.height = max_size

        if self.use_image_atlas_for_mask:
            if self.mask_use_hdr: mask_max_size = ypup.hdr_image_atlas_size
            else: mask_max_size = ypup.image_atlas_size
            if self.mask_width > mask_max_size: self.mask_width = mask_max_size
            if self.mask_height > mask_max_size: self.mask_height = mask_max_size

        # Init mask uv name
        if self.add_mask and self.mask_uv_name == '':

            obj = context.object
            node = get_active_ypaint_node()
            yp = node.node_tree.yp

            uv_name = get_default_uv_name(obj, yp)
            self.mask_uv_name = uv_name

        # Update image interpolation
        update_channel_idx_new_layer(self, context)

        return True

    def get_to_be_cleared_image_atlas(self, context, yp):
        if self.type == 'IMAGE' and not self.add_mask and self.use_image_atlas:
            return ImageAtlas.check_need_of_erasing_segments(yp, 'TRANSPARENT', self.width, self.height, self.hdr)
        if self.add_mask and self.mask_type == 'IMAGE' and self.use_image_atlas_for_mask:
            return ImageAtlas.check_need_of_erasing_segments(yp, self.mask_color, self.mask_width, self.mask_height, self.hdr)

        return None

    def draw(self, context):
        #yp = self.group_node.node_tree.yp
        node = get_active_ypaint_node()
        yp = node.node_tree.yp
        obj = context.object

        layout = self.layout.column()

        if len(yp.channels) == 0:
            layout.label(text='No channel found! Still want to create a layer?', icon='ERROR')
            return

        try:
            channel_idx = BaseOperator.get_self_channel_idx(self)
            if channel_idx != -1:
                channel = yp.channels[channel_idx]
            else: channel = None
        except: channel = None

        split_val = 0.4

        if self.add_mask and self.mask_type == 'IMAGE' and self.mask_image_filepath:
            row = split_layout(layout, split_val)

            right_aligned_label(row, 'Layer Type:')
            row.prop(self, 'type', text='')

            layout.separator()
        
        row = split_layout(layout, split_val)
        right_aligned_label(row, 'Name:')
        row.prop(self, 'name', text='')

        if self.type not in {'GROUP', 'BACKGROUND'}:
            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Channel:')

            rrow = row.row(align=True)
            BaseOperator.draw_self_channel_idx(self, rrow, yp)
            if channel:
                if channel.special_type == 'NORMAL':
                    rrow.prop(self, 'normal_blend_type', text='')
                elif channel.special_type == 'HEIGHT':
                    rrow.prop(self, 'height_blend_type', text='')
                else: 
                    rrow.prop(self, 'blend_type', text='')

                if channel.special_type == 'NORMAL':
                    row = split_layout(layout, split_val)
                    right_aligned_label(row, 'Space:')
                    row.prop(self, 'normal_space', text='')

        if self.type == 'COLOR':
            row = split_layout(layout, split_val)
            right_aligned_label(row, text='Color:')
            row.prop(self, 'solid_color', text='')

        if self.type == 'VCOL' and is_bl_newer_than(3, 2):
            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Domain:')
            crow = row.row(align=True)
            crow.prop(self, 'vcol_domain', expand=True)

            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Data Type:')
            crow = row.row(align=True)
            crow.prop(self, 'vcol_data_type', expand=True)

        if self.type == 'HEMI':
            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Space:')
            row.prop(self, 'hemi_space', text='')

        if self.type == 'EDGE_DETECT':
            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Edge Detect Radius:')
            row.prop(self, 'edge_detect_radius', text='')

            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Cycles Method:')
            rrow = row.row(align=True)
            rrow.prop(self, 'edge_detect_method', expand=True)

        if self.type == 'AO':
            row = split_layout(layout, split_val)
            right_aligned_label(row, 'AO Distance:')
            row.prop(self, 'ao_distance', text='')

        if self.type in {'HEMI', 'EDGE_DETECT', 'AO'}:
            row = split_layout(layout, split_val)
            row.label(text='')
            row.prop(self, 'hemi_use_prev_normal')

        if self.type == 'IMAGE':
            BaseOperator.draw_base_image_settings(self, layout, split_val)

        if self.type not in {'VCOL', 'GROUP', 'COLOR', 'BACKGROUND', 'HEMI', 'EDGE_DETECT', 'AO', 'PREV_LAYERS'}:
            row = split_layout(layout, split_val)
            right_aligned_label(row, text='Mapping:')

            crow = row.row(align=True)
            crow.prop(self, 'texcoord_type', text='')
            if obj.type == 'MESH' and self.texcoord_type == 'UV':
                #crow.prop_search(self, "uv_map", obj.data, "uv_layers", text='', icon='GROUP_UVS')
                crow.prop_search(self, "uv_map", self, "uv_map_coll", text='', icon='GROUP_UVS')

        if self.type in {'PREV_LAYERS'}:
            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Modifier Type:')
            row.prop(self, 'modifier_type', text='')

        if self.type in {'VCOL'}:
            row = split_layout(layout, split_val)
            row.label(text='')
            row.prop(self, 'use_divider_alpha')

        if self.type == 'IMAGE':
            acol = layout.column(align=True)
            if is_udim_supported():
                row = split_layout(acol, split_val)
                row.label(text='')
                row.prop(self, 'use_udim')

            row = split_layout(acol, split_val)
            row.label(text='')
            row.prop(self, 'use_image_atlas')

        if self.type != 'IMAGE':

            row = split_layout(layout, split_val)
            row.label(text='')
            row.prop(self, 'add_mask', text='Add Mask')

            if self.add_mask:

                row = split_layout(layout, split_val)
                right_aligned_label(row, 'Mask Type:')
                row.prop(self, 'mask_type', text='')

                if self.mask_type == 'COLOR_ID':
                    row = split_layout(layout, split_val)
                    right_aligned_label(row, text='Mask Color ID:')
                    row.prop(self, 'mask_color_id', text='')

                    if obj.mode == 'EDIT':
                        row = split_layout(layout, split_val)
                        row.label(text='')
                        row.prop(self, 'mask_vcol_fill', text='Fill Selected Faces')

                elif self.mask_type == 'EDGE_DETECT':
                    row = split_layout(layout, split_val)
                    right_aligned_label(row, 'Edge Detect Radius:')
                    row.prop(self, 'mask_edge_detect_radius', text='')

                    row = split_layout(layout, split_val)
                    right_aligned_label(row, 'Cycles Method:')
                    rrow = row.row(align=True)
                    rrow.prop(self, 'mask_edge_detect_method', expand=True)

                    row = split_layout(layout, split_val)
                    row.label(text='')
                    row.prop(self, 'mask_use_prev_normal', text='Use Previous Normal')

                elif self.mask_type == 'IMAGE':
                    if self.mask_image_filepath:
                        row = split_layout(layout, split_val)
                        right_aligned_label(row, 'Mask Image Path:')
                        row.prop(self, 'mask_image_filepath', text='')

                    else:
                        row = split_layout(layout, split_val)
                        right_aligned_label(row, 'Mask Color:')
                        row.prop(self, 'mask_color', text='')

                        BaseOperator.draw_base_mask_image_settings(self, layout, split_val)

                    row = split_layout(layout, split_val)
                    right_aligned_label(row, 'Mask Interpolation:')
                    row.prop(self, 'mask_interpolation', text='')

                    row = split_layout(layout, split_val)
                    right_aligned_label(row, text='Mask Mapping:')

                    crow = row.row(align=True)
                    crow.prop(self, 'mask_texcoord_type', text='')
                    if self.mask_texcoord_type == 'UV' and obj.type == 'MESH':
                        crow.prop_search(self, "mask_uv_name", self, "uv_map_coll", text='', icon='GROUP_UVS')
                
                    if not self.mask_image_filepath:
                        acol = layout.column(align=True)
                        if is_udim_supported():
                            row = split_layout(acol, split_val)
                            row.label(text='')
                            row.prop(self, 'use_udim_for_mask')

                        row = split_layout(acol, split_val)
                        row.label(text='')
                        row.prop(self, 'use_image_atlas_for_mask', text='Use Image Atlas')

                elif is_bl_newer_than(3, 2) and self.mask_type == 'VCOL':

                    row = split_layout(layout, split_val)
                    right_aligned_label(row, 'Mask Domain:')
                    crow = row.row(align=True)
                    crow.prop(self, 'mask_vcol_domain', expand=True)

                    row = split_layout(layout, split_val)
                    right_aligned_label(row, 'Mask Data Type:')
                    crow = row.row(align=True)
                    crow.prop(self, 'mask_vcol_data_type', expand=True)

                    if obj.mode == 'EDIT':
                        row = split_layout(layout, split_val)
                        row.label(text='')
                        row.prop(self, 'mask_vcol_fill', text='Fill Selected Faces')

        if self.get_to_be_cleared_image_atlas(context, yp):
            col = layout.column(align=True)
            col.label(text='INFO: An unused atlas segment can be used.', icon='ERROR')
            col.label(text='It will take a couple seconds to clear.')

        if self.type == 'AO':
            col = layout.column(align=True)
            col.label(text='Realtime AO can look different in baked/rendered view!', icon='ERROR')

        if self.type == 'EDGE_DETECT' or (self.add_mask and self.mask_type == 'EDGE_DETECT'):
            col = layout.column(align=True)
            col.label(text='Realtime Edge Detect can look different in baked/rendered view!', icon='ERROR')

    def execute(self, context):

        T = time.time()

        #ypup = get_user_preferences()
        wm = context.window_manager
        area = context.area
        obj = context.object
        mat = obj.active_material
        node = get_active_ypaint_node()
        yp = node.node_tree.yp
        ypui = context.window_manager.ypui
        vcol_names = get_vertex_color_names(obj)

        # Check if object is not a mesh
        if (self.type == 'VCOL' or (self.add_mask and self.mask_type == 'VCOL')) and obj.type != 'MESH':
            self.report({'ERROR'}, get_vertex_color_label(10)+" only works with mesh object!")
            return {'CANCELLED'}

        if (not is_bl_newer_than(3, 3) and
                (
                ((self.type == 'VCOL' or (self.add_mask and self.mask_type == 'VCOL')) 
                and len(vcol_names) >= 8) 
            or
                ((self.type == 'VCOL' and (self.add_mask and self.mask_type == 'VCOL')) 
                and len(vcol_names) >= 7)
                )
            ):
            self.report({'ERROR'}, "Mesh can only use 8 "+get_vertex_color_label(00)+"!")
            return {'CANCELLED'}

        # Check if layer with same name is already available
        if self.type == 'IMAGE':
            same_name = [i for i in bpy.data.images if i.name == self.name]
        elif self.type == 'VCOL':
            same_name = [i for i in vcol_names if i == self.name]
        else: same_name = [lay for lay in yp.layers if lay.name == self.name]
        if same_name:
            if self.type == 'IMAGE':
                self.report({'ERROR'}, "Image named '" + self.name +"' is already available!")
            elif self.type == 'VCOL':
                self.report({'ERROR'}, get_vertex_color_label()+" named '" + self.name +"' is already available!")
            else:
                self.report({'ERROR'}, "Layer named '" + self.name +"' is already available!")
            return {'CANCELLED'}

        # Edge Detect mask is only possible in Blender 2.93 or above
        if not is_bl_newer_than(2, 93) and (self.type in {'EDGE_DETECT', 'AO'} or self.add_mask and self.mask_type == 'EDGE_DETECT'):
            self.report({'ERROR'}, "Realtime layer/mask mask is only supported in Blender 2.93 or above!")
            return {'CANCELLED'}

        # Clearing unused image atlas segments
        img_atlas = self.get_to_be_cleared_image_atlas(context, yp)
        if img_atlas: ImageAtlas.clear_unused_segments(img_atlas.yia)

        # Get channel index
        try: channel_idx = BaseOperator.get_self_channel_idx(self)
        except: channel_idx = 0

        # Default colorspace
        colorspace = get_linear_color_name() if self.hdr else get_srgb_name()

        # Colorspace based on channel setting
        if not self.hdr:
            channel = yp.channels[channel_idx] if channel_idx < len(yp.channels) and channel_idx >= 0 else None
            if channel and (channel.colorspace == 'LINEAR' or channel.special_type in {'NORMAL', 'HEIGHT', 'VDISP'}):
                colorspace = get_noncolor_name()

        img = None
        segment = None
        if self.type == 'IMAGE':

            alpha = True
            color = (0, 0, 0, 0)

            if self.use_udim:
                objs = get_all_objects_with_same_materials(mat)
                tilenums = UDIM.get_tile_numbers(objs, self.uv_map)

            if self.use_image_atlas:
                if self.use_udim:
                    segment = UDIM.get_set_udim_atlas_segment(tilenums, self.width, self.height, color, colorspace, self.hdr, yp)
                else:
                    segment = ImageAtlas.get_set_image_atlas_segment(self.width, self.height, 'TRANSPARENT', self.hdr, yp=yp, colorspace=colorspace)
                img = segment.id_data
            else:

                if self.use_udim:
                    img = bpy.data.images.new(
                        name=self.name, width=self.width, height=self.height, 
                        alpha=alpha, float_buffer=self.hdr, tiled=True
                    )

                    # Fill tiles
                    for tilenum in tilenums:
                        UDIM.fill_tile(img, tilenum, color, self.width, self.height)
                    UDIM.initial_pack_udim(img, color)

                else:
                    img = bpy.data.images.new(
                        name=self.name, width=self.width, height=self.height, 
                        alpha=alpha, float_buffer=self.hdr
                    )

                    #img.generated_type = self.generated_type
                    img.generated_type = 'BLANK'
                    img.generated_color = color
                    if hasattr(img, 'use_alpha'):
                        img.use_alpha = True

                # Set alpha mode to premultiplied to make sure alpha will be packed correctly
                if img.is_float and is_bl_newer_than(2, 80):
                    img.alpha_mode = 'PREMUL'

                # Set colorspace
                img.colorspace_settings.name = colorspace

            update_image_editor_image(context, img)

        vcol = None
        if self.type == 'VCOL':

            objs = [obj] if obj.type == 'MESH' else []
            if mat.users > 1:
                for o in get_scene_objects():
                    if o.type != 'MESH': continue
                    if mat.name in o.data.materials and o not in objs:
                        objs.append(o)

            for o in objs:
                if self.name not in get_vertex_colors(o):
                    if not is_bl_newer_than(3, 3) and len(get_vertex_colors(o)) >= 8: continue

                    color = (0.0, 0.0, 0.0, 0.0)
                    if not is_bl_newer_than(2, 92):
                        color = (1.0, 1.0, 1.0, 1.0)

                    vcol = new_vertex_color(o, self.name, self.vcol_data_type, self.vcol_domain, color_fill=color)
                    set_active_vertex_color(o, vcol)

        yp.halt_update = True

        layer = layer_common.add_new_layer(
            node.node_tree, self.name, self.type, 
            channel_idx, self.blend_type, self.normal_blend_type, 
            self.normal_map_type, self.texcoord_type, uv_name=self.uv_map, 
            image=img, vcol=vcol, segment=segment, solid_color=self.solid_color,
            add_mask=self.add_mask, mask_type=self.mask_type, 
            mask_image_filepath=self.mask_image_filepath, mask_relative=self.mask_relative,
            mask_texcoord_type=self.mask_texcoord_type, mask_color=self.mask_color, 
            mask_use_hdr=self.mask_use_hdr, mask_uv_name=self.mask_uv_name,
            mask_width=self.mask_width, mask_height=self.mask_height, use_image_atlas_for_mask=self.use_image_atlas_for_mask, 
            hemi_space=self.hemi_space, hemi_use_prev_normal=self.hemi_use_prev_normal, 
            mask_color_id=self.mask_color_id, mask_vcol_fill=self.mask_vcol_fill,
            mask_vcol_data_type=self.mask_vcol_data_type, mask_vcol_domain=self.mask_vcol_domain, use_divider_alpha=self.use_divider_alpha,
            use_udim_for_mask=self.use_udim_for_mask, interpolation=self.interpolation, mask_interpolation=self.mask_interpolation,
            mask_edge_detect_radius=self.mask_edge_detect_radius, mask_edge_detect_method=self.mask_edge_detect_method,
            edge_detect_radius=self.edge_detect_radius, edge_detect_method=self.edge_detect_method,
            mask_use_prev_normal=self.mask_use_prev_normal, ao_distance=self.ao_distance, normal_space=self.normal_space,
            height_blend_type = self.height_blend_type,
            add_modifier = self.type == 'PREV_LAYERS',
            modifier_type = self.modifier_type
        )

        if segment:
            ImageAtlas.set_segment_mapping(layer, segment, img)
            refresh_temp_uv(obj, layer)

        yp.halt_update = False

        # Reconnect and rearrange nodes
        reconnect_yp_nodes(node.node_tree)
        rearrange_yp_nodes(node.node_tree)

        # Update UI
        if self.type not in {'IMAGE', 'VCOL', 'COLOR', 'BACKGROUND', 'GROUP'}:
            ypui.layer_ui.expand_content = True
            ypui.layer_ui.expand_source = True
        else:
            ypui.layer_ui.expand_content = False
            ypui.layer_ui.expand_source = False
        ypui.layer_ui.expand_vector = False

        if BaseOperator.get_self_channel_idx(self) != -1:
            ypui.layer_ui.expand_channels = False
            #if len(yp.channels) > 0 and yp.channels[channel_idx].special_type in {'NORMAL', 'HEIGHT', 'VDISP'}:
            #    layer.channels[channel_idx].expand_content = True
        else:
            ypui.layer_ui.expand_channels = True

        loaded_image_mask = self.mask_type == 'IMAGE' and self.mask_image_filepath
        if self.add_mask and (loaded_image_mask or self.mask_type == 'EDGE_DETECT'):
            ypui.layer_ui.expand_masks = True
            layer.masks[0].expand_content = True
            if self.mask_type == 'EDGE_DETECT':
                layer.masks[0].expand_source = True
            elif loaded_image_mask:
                layer.masks[0].expand_vector = True
        else:
            ypui.layer_ui.expand_masks = False
            for i, mask in enumerate(layer.masks):
                mask.expand_content = False
                mask.expand_source = False

        ypui.need_update = True

        print('INFO: Layer', layer.name, 'created in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YOpenImageToOverrideChannel(bpy.types.Operator, ImportHelper, BaseOperator.OpenImage):
    """Open Image to Override Channel"""
    bl_idname = "wm.y_open_image_to_override_layer_channel"
    bl_label = "Open Image to Override Channel Layer"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def invoke(self, context, event):
        self.ch = context.parent
        return self.running_fileselect_modal(context, event)

    def execute(self, context):
        ch = self.ch
        T = time.time()

        wm = context.window_manager
        node = get_active_ypaint_node()

        loaded_images = self.get_loaded_images()

        images = []
        for i, new_img in enumerate(loaded_images):

            # Check for existing images
            old_image_found = False
            for old_img in bpy.data.images:
                if old_img.filepath == new_img.filepath:
                    images.append(old_img)
                    old_image_found = True
                    break

            if not old_image_found:
                images.append(new_img)

        # Remove already existing images
        for img in loaded_images:
            if img not in images:
                remove_datablock(bpy.data.images, img)

        yp = ch.id_data.yp
        m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', ch.path_from_id())
        if not m: return []
        layer = yp.layers[int(m.group(1))]
        root_ch = yp.channels[int(m.group(2))]
        tree = get_tree(layer)

        # Make sure channel is on
        if not ch.enable:
            ch.enable = True

        image = images[0] if len(images) > 0 else None

        if image:
            # Make sure override is on
            if not ch.override:
                ch.override = True

            # Set relative
            if self.relative:
                try: image.filepath = bpy.path.relpath(image.filepath)
                except: pass

            # Set colorspace
            if root_ch.colorspace == 'LINEAR' and not image.is_dirty:
                image.colorspace_settings.name = get_noncolor_name()

            # Update image cache
            if ch.override_type == 'IMAGE':
                source_tree = get_channel_source_tree(ch, layer)
                source_label = root_ch.name + ' Override : ' + ch.override_type
                image_node, dirty = check_new_node(source_tree, ch, 'source', 'ShaderNodeTexImage', source_label, True)
            else:
                image_node, dirty = check_new_node(tree, ch, 'cache_image', 'ShaderNodeTexImage', '', True)

            image_node.image = image
            if root_ch.special_type == 'HEIGHT': image_node.interpolation = 'Cubic'
            ch.override_type = 'IMAGE'
            ch.active_edit = True

        # Update list items
        ListItem.refresh_list_items(yp)

        # Update UI
        wm.ypui.need_update = True
        print('INFO: Image(s) opened in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class BaseMultipleImagesLayer(BaseOperator.OpenImage):

    texcoord_type : EnumProperty(
        name = 'Layer Coordinate Type',
        description = 'Layer Coordinate Type',
        items = texcoord_type_items,
        default = 'UV'
    )

    uv_map : StringProperty(
        name = 'UV Map',
        description = 'UV Map to use for layer coordinate',
        default = '')
    uv_map_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    add_mask : BoolProperty(
        name = 'Add Mask',
        description = 'Add mask to new layer',
        default = False
    )

    mask_type : EnumProperty(
        name = 'Mask Type',
        description = 'Mask type',
        items = (
            ('IMAGE', 'Image', '', 'IMAGE_DATA', 0),
            ('VCOL', get_vertex_color_label(), '', 'GROUP_VCOL', 1)
        ),
        default = 'IMAGE'
    )

    mask_color : EnumProperty(
        name = 'Mask Color',
        description = 'Mask Color',
        items = (
            ('WHITE', 'White (Full Opacity)', ''),
            ('BLACK', 'Black (Full Transparency)', ''),
        ),
        default = 'BLACK'
    )

    mask_width : IntProperty(name='Mask Width', default=1024, min=1, max=4096)
    mask_height : IntProperty(name='Mask Height', default=1024, min=1, max=4096)

    mask_image_resolution : EnumProperty(
        name = 'Image Resolution',
        items = image_resolution_items,
        default = '1024'
    )
    
    mask_use_custom_resolution : BoolProperty(
        name = 'Custom Resolution',
        description = 'Use custom Resolution to adjust the width and height individually',
        default = False
    )

    mask_uv_name : StringProperty(
        name='UV Map for Mask', 
        description = 'UV Map to use for mask coordinate',
        default='', update=BaseOperator.update_mask_uv_map_name
    )

    mask_use_hdr : BoolProperty(
        name = '32-bit Float',
        description = 'Use 32-bit float image for mask',
        default = False
    )

    use_udim_for_mask : BoolProperty(
        name = 'Use UDIM Tiles for Mask',
        description = 'Use UDIM Tiles for Mask',
        default = False
    )

    use_image_atlas_for_mask : BoolProperty(
        name = 'Use Image Atlas for Mask',
        description = 'Use Image Atlas for Mask',
        default = False
    )

    # NOTE: Most PBR textures are optimized to use 'displacement only without bump' in conjunction with normal map
    # Since this addon already produce normal map with the displacement, it's better to use only bump map by default
    normal_height_priority : EnumProperty(
        name = 'Height/Normal Map Priority',
        description = 'What to do when height and normal map are both found',
        items = (
            ('HEIGHT_ONLY', 'Height Map Only', ''),
            ('NORMAL_ONLY', 'Normal Map Only', ''),
            ('BOTH', 'Both Height and Normal Map', '')
        ),
        default = 'HEIGHT_ONLY'
    )

    normal_map_flip_y : BoolProperty(
        name = 'Flip G (Normal Map)',
        description = 'Invert G channel on loaded normal map (useful for DirectX normal maps)',
        default = False
    )

    #def is_mask_using_udim(self):
    #    return self.use_udim_for_mask and is_udim_supported()

    #def is_mask_using_image_atlas(self):
    #    return self.use_image_atlas_for_mask and not self.is_mask_using_udim()

    def is_synonym_in_image_name(self, syname, img_name):

        # Check entire name of synonym if it's in image name
        if len(syname) > 1:
            if (img_name.endswith(syname) or # Example: 'rocks_normalgl'
                '_' + syname in img_name or # Example: 'rocks_normalgl_4k'
                ' ' + syname in img_name # Example: 'rocks normalgl 4k'
                ):
                return True
        else:
            if img_name.endswith(('_' + syname, '.' + syname)): # Example 'rocks_n', 'rocks.n'
                return True

        if ' ' in syname:
            # Check if synonym without whitespace is in image name
            no_whitespace = syname.replace(' ', '')
            if (img_name.endswith(no_whitespace) or # Example: 'rocks_ambientocclusion'
                '_' + no_whitespace + '_' in img_name or # Example: 'rocks_ambientocclusion_4k'
                ' ' + no_whitespace + ' ' in img_name # Example: 'rocks ambientocclusion 4k'
                ):
                return True

            # Check if synonym with underscore is in image name
            underscore = syname.replace(' ', '_')
            if (img_name.endswith(underscore) or # Example: 'rocks_ambient_occlusion'
                '_' + underscore + '_' in img_name or # Example: 'rocks_ambient_occlusion_4k'
                ' ' + underscore + ' ' in img_name # Example: 'rocks ambient_occlusion 4k'
                ):
                return True

        # Check parts of synonym if it's in image name
        for i in range(3, 6):
            if len(syname) > i:
                part = syname[:i]
                if (img_name.endswith(('_' + part, '.' + part)) or  # Example: 'rocks_diff' / 'rocks.diff'
                    '_' + part + '_' in img_name or # Example: 'rocks_diff_4k'
                    ' ' + part + ' ' in img_name # Example: 'rocks diff 4k'
                    ):
                    return True

        # Check if initial of synonym is in the end of image name
        # Avoid initial a because it's too common
        #initial = syname[0] if syname not in {'displacement', 'base color'} else ''
        #if initial not in {'a', ''} and img_name.endswith(('_' + initial, '.' + initial)): # Example: 'rock_r' / 'rock.r'
        #    return True

        return False

    def open_images_to_single_layer(self, context:bpy.context, directory:str='', import_list=[], non_import_images=[], channel_image_dict={}) -> bool:
    
        T = time.time()
        
        images = []
        images.extend(non_import_images)

        # Load images from directory
        if import_list:
            images.extend(list(load_image(path, directory) for path in import_list))

        valid_channels = []
        valid_images = []
        valid_synonyms = []

        # Filter image to make sure it's not empty
        filtered_images = []
        for image in images:
            if not image: continue
            filtered_images.append(image)
        images = filtered_images

        # Check for DirectX and OpenGL images
        dx_image = None
        gl_image = None
        for image in images:

            # Get filename without extension
            name = os.path.splitext(os.path.basename(image.filepath))[0]
            lname = name.lower()
            if 'normaldx' in lname or 'nor_dx' in lname:
                dx_image = image
            if 'normalgl' in lname or 'nor_gl' in lname:
                gl_image = image

        synonym_libs = {
            'color' : ['albedo', 'diffuse', 'base color', 'd'], 
            'alpha' : ['opacity', 'a'], 
            'ambient occlusion' : ['ao'], 
            'metallic' : ['metalness', 'm'],
            'roughness' : ['glossiness', 'smoothness', 'r'],
            #'normal' : ['displacement', 'height', 'bump', 'n'], # Prioritize displacement/bump before actual normal map
            'normal' : ['n'],
            'height' : ['displacement', 'bump']
        }

        wm = context.window_manager
        node = get_active_ypaint_node()
        yp = node.node_tree.yp

        for ch in yp.channels:

            # One channel will only use one image
            if ch in valid_channels: continue
            ch_name = ch.name.lower()

            # Get synonyms
            synonyms = []
            if ch_name in synonym_libs:
                synonyms = synonym_libs[ch_name]
            synonyms.append(ch_name)

            # Normal channel can use both bump and normal override images
            main_image_found = False
                
            for syname in synonyms:

                # Break if channel already used
                if main_image_found: break
            
                for image in images:

                    # DirectX image will be skipped if there's OpenGL image
                    if ch.special_type == 'NORMAL' and dx_image and gl_image and image == dx_image:
                        continue

                    if image in channel_image_dict.values():

                        # Get alias based on channel-image dictionary
                        for ch_name, img in channel_image_dict.items():
                            if img == image:
                                alias = ch_name.lower()
                                if syname in ch_name.lower():
                                    break

                    elif image.filepath != '':
                        # Get alias base on filename without extension
                        alias = os.path.splitext(bpy.path.basename(image.filepath))[0].lower()
                    else: 
                        # Get alias base on filename
                        alias = image.name.lower()

                    # Remove trailing digits and spaces from the filename
                    alias = re.sub(r'[\d\s]+$', '', alias)

                    # Check if synonym is in image name
                    if self.is_synonym_in_image_name(syname, alias):

                        valid_images.append(image)
                        valid_channels.append(ch)
                        valid_synonyms.append(syname)

                        main_image_found = True
                        break

        if not valid_images:
            # Remove loaded images
            for image in images:
                #if image not in existing_images:
                if image in non_import_images: continue
                remove_datablock(bpy.data.images, image)
            return False

        layer = None
        main_image = None
        for i, image in enumerate(valid_images):
            root_ch = valid_channels[i]
            syname = valid_synonyms[i]

            # Set relative
            if self.relative and bpy.data.filepath != '':
                try: image.filepath = bpy.path.relpath(image.filepath)
                except: pass

            ch_idx = get_channel_index(root_ch)

            # Use non-color for non-color channel
            if root_ch.colorspace == 'LINEAR' and not image.is_dirty:
                image.colorspace_settings.name = get_noncolor_name()

            # Use image directly to layer for the first index
            if i == 0:
                yp.halt_update = True
                                                 
                layer = layer_common.add_new_layer(
                    group_tree=node.node_tree, layer_name=image.name,
                    layer_type='IMAGE', channel_idx=int(ch_idx),
                    blend_type='MIX', normal_blend_type='MIX', 
                    normal_map_type='BUMP_MAP', texcoord_type=self.texcoord_type,
                    uv_name=self.uv_map, image=image,
                    vcol=None, segment=None, solid_color=(1, 1, 1), 
                    add_mask=self.add_mask, mask_type=self.mask_type, mask_color=self.mask_color, mask_use_hdr=self.mask_use_hdr, 
                    mask_uv_name=self.mask_uv_name, mask_width=self.mask_width, mask_height=self.mask_height, 
                    use_image_atlas_for_mask=self.use_image_atlas_for_mask, use_udim_for_mask=self.use_udim_for_mask
                )

                yp.halt_update = False
                tree = get_tree(layer)
                main_image = image
            else:
                ch = layer.channels[ch_idx]
                ch.enable = True

                image_node, dirty = check_new_node(tree, ch, 'cache_image', 'ShaderNodeTexImage', '', True)
                image_node.image = image
                if root_ch.special_type == 'HEIGHT': image_node.interpolation = 'Cubic'

                # Add invert modifier for glosiness
                if syname in {'glossiness', 'smoothness'}:
                    modifier_common.add_new_modifier(ch, 'INVERT')

                if image == main_image:
                    ch.override = False
                else:
                    ch.override = True
                    ch.override_type = 'IMAGE'

        # Normal/height priority
        normal_ch, height_ch = get_layer_normal_height_ch_pairs(layer)
        if normal_ch and height_ch:
            if self.normal_height_priority == 'HEIGHT_ONLY':
                normal_ch.enable = False
            elif self.normal_height_priority == 'NORMAL_ONLY':
                height_ch.enable = False

        # Check image projections
        layer_common.check_layer_projections(layer)

        ## Reconnect and rearrange nodes
        reconnect_yp_nodes(node.node_tree)
        rearrange_yp_nodes(node.node_tree)

        # Remove unused images
        for image in images:
            if image not in valid_images and image.users == 0: # and image not in existing_images:
                remove_datablock(bpy.data.images, image)

        # Update UI
        wm.ypui.need_update = True

        # Make sure to expand channels so it can be obvious which channels are active
        wm.ypui.expand_channels = True

        # Expand vector transformation because it's highly likely user want to tweak this
        wm.ypui.layer_ui.expand_content = False
        wm.ypui.layer_ui.expand_vector = True
        wm.ypui.layer_ui.expand_channels = True

        print('INFO: Image(s) opened in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return True

    def invoke_operator(self, context):
        obj = context.object
        node = get_active_ypaint_node()
        yp = node.node_tree.yp if node else None
        ypup = get_user_preferences()

        # Use user preference default image size
        if ypup.default_image_resolution == 'CUSTOM':
            self.mask_use_custom_resolution = True
            self.mask_width = self.mask_height = ypup.default_new_image_size
        elif ypup.default_image_resolution != 'DEFAULT':
            self.mask_image_resolution = ypup.default_image_resolution

        if not is_object_work_with_uv(obj):
            self.texcoord_type = 'Generated'

        # Use active uv layer name by default
        if obj.type == 'MESH':
            uv_name = get_default_uv_name(obj, yp)
            self.uv_map = uv_name
            if self.add_mask and self.mask_type == 'IMAGE': self.mask_uv_name = uv_name

            # UV Map collections update
            self.uv_map_coll.clear()
            for uv in obj.data.uv_layers:
                if not uv.name.startswith(TEMP_UV):
                    self.uv_map_coll.add().name = uv.name

    def draw_operator(self, context, display_relative_toggle=True, split_val=0.325):
        obj = context.object
        node = get_active_ypaint_node()
        yp = node.node_tree.yp if node else None

        layout = self.layout

        row = split_layout(layout, split_val)
        right_aligned_label(row, 'Mapping:')
        crow = row.row(align=True)
        crow.prop(self, 'texcoord_type', text='')
        if obj.type == 'MESH' and self.texcoord_type == 'UV':
            #crow.prop_search(self, "uv_map", obj.data, "uv_layers", text='', icon='GROUP_UVS')
            crow.prop_search(self, "uv_map", self, "uv_map_coll", text='', icon='GROUP_UVS')

        height_root_ch = get_root_height_channel(yp) if yp else None
        if not yp or height_root_ch:
            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Normal Map:')

            crow = row.row(align=True)
            crow.prop(self, 'normal_height_priority', text='')
            crow.prop(self, 'normal_map_flip_y', text='', icon_value=lib.get_icon('g'))

        row = split_layout(layout, split_val)
        row.label(text='')
        row.prop(self, 'add_mask', text='Add Mask')

        if self.add_mask:
            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Mask Type:')
            row.prop(self, 'mask_type', text='')

            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Mask Color:')
            row.prop(self, 'mask_color', text='')

            if self.mask_type == 'IMAGE':
                row = split_layout(layout, split_val)
                row.label(text='')
                row.prop(self, 'mask_use_hdr')

                row = split_layout(layout, split_val)
                row.label(text='')
                row.prop(self, 'mask_use_custom_resolution')

                if not self.mask_use_custom_resolution:
                    row = split_layout(layout, split_val)
                    right_aligned_label(row, 'Mask Resolution:')
                    crow = row.row(align=True)
                    crow.prop(self, 'mask_image_resolution', expand=True)
                else:
                    row = split_layout(layout, split_val)
                    rcol = row.column(align=True)
                    right_aligned_label(rcol, 'Mask Width:')
                    right_aligned_label(rcol, 'Mask Height:')

                    rcol = row.column(align=True)
                    rcol.prop(self, 'mask_width', text='')
                    rcol.prop(self, 'mask_height', text='')

                row = split_layout(layout, split_val)
                right_aligned_label(row, 'Mask UV Map:')
                row.prop_search(self, "mask_uv_name", self, "uv_map_coll", text='', icon='GROUP_UVS')

                if is_udim_supported():
                    row = split_layout(layout, split_val)
                    row.label(text='')
                    row.prop(self, 'use_udim_for_mask')

                row = split_layout(layout, split_val)
                row.label(text='')
                row.prop(self, 'use_image_atlas_for_mask', text='Use Image Atlas')

        if display_relative_toggle:
            layout.prop(self, 'relative')

    def check_operator(self, context:bpy.context):
        ypup = get_user_preferences()

        if not self.mask_use_custom_resolution:
            self.mask_width = int(self.mask_image_resolution)
            self.mask_height = int(self.mask_image_resolution)

        # New image cannot use more pixels than the image atlas
        if self.use_image_atlas_for_mask:
            if self.mask_use_hdr: mask_max_size = ypup.hdr_image_atlas_size
            else: mask_max_size = ypup.image_atlas_size
            if self.mask_width > mask_max_size: self.mask_width = mask_max_size
            if self.mask_height > mask_max_size: self.mask_height = mask_max_size

        # Init mask uv name
        if self.add_mask and self.mask_uv_name == '':

            node = get_active_ypaint_node()
            yp = node.node_tree.yp
            obj = context.object

            uv_name = get_default_uv_name(obj, yp)
            self.mask_uv_name = uv_name

        return True

def search_for_images(tree):
    images = []

    for node in tree.nodes:
        if node.type == 'TEX_IMAGE':
            if node.image:
                images.append(node.image)

        if node.type == 'GROUP' and node.node_tree and not node.node_tree.yp.is_ypaint_node:
            images.extend(search_for_images(node.node_tree))

    return images

def search_for_image_node(node, channel_name, channel_image_dict={}):
    if node.type == 'TEX_IMAGE' and node.image:
        #print("add", node.image.name, "to", channel_name)
        channel_image_dict[channel_name] = node.image
    elif node.type == "BUMP":
        for inp in node.inputs:
            if inp.is_linked:
                # print("input=", inp.name, " linked=",inp.is_linked," type=" ,inp.type)
                for link in inp.links:
                    # print("link=", link.from_node.name, " type=", link.from_node.type)
                    ch_name = inp.name
                    if ch_name == "Height":
                        ch_name = "Bump"
                        # Skip if already in dictionary
                        if ch_name in channel_image_dict:
                            continue 
                    search_for_image_node(link.from_node, ch_name, channel_image_dict)
    else:
        #print("else node=", node.name, "type=", node.type)
        for inp in node.inputs:
            if inp.is_linked:
                # print("input=", inp.name, " linked=",inp.is_linked," type=" ,inp.type)
                for link in inp.links:
                    # print("link=", link.from_node.name, " type=", link.from_node.type)
                    search_for_image_node(link.from_node, channel_name, channel_image_dict)
                if channel_name in channel_image_dict:
                    break
                
class YOpenImagesFromMaterialToLayer(bpy.types.Operator, ImportHelper, BaseMultipleImagesLayer):
    bl_idname = "wm.y_open_images_from_material_to_single_layer"
    bl_label = "Open Images from Material to single " + get_addon_title() + " Layer"
    bl_description = "Open images inside material node tree to single " + get_addon_title() + " layer"
    bl_options = {'REGISTER', 'UNDO'}

    mat_name : StringProperty(name='Material', default='')
    mat_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)
    asset_library_path : StringProperty(default='')

    fail_self_load : BoolProperty(default=False)

    read_method : EnumProperty(
        name = 'Read Method',
        description = '',
        items = (
            ('IMAGE_NAMES', 'Read Image Names', 'Read all image names in material'),
            ('READ_NODE', 'Read Node Connections', 'Read node connections in material'),
        ),
        default = 'READ_NODE'
    )

    @classmethod
    def poll(cls, context):
        #return get_active_ypaint_node()
        return context.object

    @classmethod
    def description(self, context, properties):
        return get_operator_description(self)

    def invoke(self, context, event):
        self.invoke_operator(context)

        # Skip dialog box if fail happen
        if self.fail_self_load:
            return self.execute(context)

        self.mat_coll.clear()

        obj = context.object
        cur_mats = []
        if obj.data and hasattr(obj.data, 'materials'):
            cur_mats = obj.data.materials

        # Get material lists from current file
        mat_found = False
        for mat in bpy.data.materials:
            if mat.name not in {'Dots Stroke'} and mat.name not in cur_mats:
                self.mat_coll.add().name = mat.name
                if self.mat_name == mat.name: 
                    mat_found = True

        if self.asset_library_path == '':
            if not mat_found:
                self.mat_name = ''
        
        # Only allow skipping the popup when opening through the asset library
        if self.asset_library_path != '' and get_user_preferences().skip_property_popups and not event.shift:
            return self.execute(context)

        return context.window_manager.invoke_props_dialog(self)

    def check(self, context):
        return self.check_operator(context)

    def draw(self, context):
        split_val = 0.325

        row = split_layout(self.layout, split_val, align=True)
        right_aligned_label(row, 'Material:')
        if self.asset_library_path == '':
            row.prop_search(self, "mat_name", self, "mat_coll", text='', icon='MATERIAL_DATA')
        else: row.label(text=self.mat_name, icon='MATERIAL_DATA')

        row = split_layout(self.layout, split_val)
        right_aligned_label(row, 'Read method:')
        row.prop(self, 'read_method', text="")

        self.draw_operator(context, display_relative_toggle=False, split_val=split_val)

    def execute(self, context):

        if self.fail_self_load:
            self.report({'ERROR'}, "Material asset can't be the same as the active material!")
            return {'CANCELLED'}

        if self.mat_name == '':
            self.report({'ERROR'}, "Source material cannot be empty!")
            return {'CANCELLED'}

        obj = context.object
        if not obj.data or not hasattr(obj.data, 'materials'):
            self.report({'ERROR'}, "Cannot use " + get_addon_title() + " with object '" + obj.name + "'!")
            return {'CANCELLED'}

        # Get material from local first
        mat = bpy.data.materials.get(self.mat_name)

        # If not found get from the asset library
        from_asset_library = self.asset_library_path != ''
        if not mat and from_asset_library and is_bl_newer_than(3):
            with bpy.data.libraries.load(str(self.asset_library_path), assets_only=True) as (data_from, data_to):
                for mat in data_from.materials:
                    if mat == self.mat_name:
                        data_to.materials.append(mat)
            mat = bpy.data.materials.get(self.mat_name)

        if not mat:
            self.report({'ERROR'}, "Source material cannot be found!")
            return {'CANCELLED'}

        # Images to be processed
        images = []

        # Channel name and their image dictionary
        channel_image_dict = {}

        # Get active material output
        output = get_material_output(mat, create_one=True)

        if self.read_method == 'READ_NODE':
            # Search images based on node connections
            for inp in output.inputs:
                if inp.is_linked and inp.name == "Displacement":
                    for link in inp.links:
                        search_for_image_node(link.from_node, "Bump", channel_image_dict)

            bsdf_node = get_closest_bsdf_backward(output)

            if bsdf_node:
                for inp in bsdf_node.inputs:
                    if inp.is_linked:
                        for link in inp.links:
                            ch_name = inp.name
                            if ch_name == "Base Color":
                                ch_name = "Color"
                            search_for_image_node(link.from_node, ch_name, channel_image_dict)
            else:
                # Check image node connected directly to material output
                image_node = get_closest_image_node_backward(output)
                if image_node:
                    images.append(image_node.image)
                    channel_image_dict['Color'] = image_node.image

            for img in channel_image_dict.values():
                if img not in images: images.append(img)

        elif self.read_method == 'IMAGE_NAMES':

            if mat.node_tree:
                images = search_for_images(mat.node_tree)

        yp_node = get_closest_yp_node_backward(output)
        otree = None
        if yp_node:
            try: bpy.ops.wm.y_update_yp_trees('INVOKE_DEFAULT')
            except Exception as e:
                print('EXCEPTIION: Cannot update opened tree. Error Message: '+e)

            otree = yp_node.node_tree
            oyp = otree.yp
            for root_ch in oyp.channels:

                # Check for bake target
                for bt in oyp.bake_targets:
                    if bt.data_type != 'IMAGE': continue

                    if is_bake_target_using_exact_channel(bt, root_ch):
                        baked_node = otree.nodes.get(bt.baked_node)
                        images.append(baked_node.image)
                        channel_image_dict[root_ch.name] = baked_node.image
                        break

        # Check for existing images if the image source is from asset library
        if from_asset_library:
            filtered_images = []
            existing_images = []
            duplicated_images = []
            for new_img in images:
                for old_img in bpy.data.images:
                    if old_img in images: continue
                    if old_img.filepath == new_img.filepath and old_img.filepath != '':
                        existing_images.append(old_img)
                        duplicated_images.append(new_img)
                        break

            # Add existing images to list
            for img in existing_images:
                if img not in filtered_images:
                    filtered_images.append(img)

            # Add imported images to list
            for img in images:
                if img not in filtered_images and img not in duplicated_images:
                    filtered_images.append(img)

            # Remove duplicated images
            for img in duplicated_images:
                remove_datablock(bpy.data.images, img)

            # Use filtered images
            images = filtered_images

        if len(images) == 0:
            self.report({'ERROR'}, "Couldn't find images inside of the material!")
            return {'CANCELLED'}

        # Use quick setup if yp node is not found
        node = get_active_ypaint_node()
        quick_setup_happen = False
        if not node:
            bpy.ops.wm.y_quick_ypaint_node_setup()
            quick_setup_happen = True

        failed = False
        if not self.open_images_to_single_layer(context, directory='', import_list=[], non_import_images=images, channel_image_dict=channel_image_dict):
            self.report({'ERROR'}, "Cannot find valid images!")
            failed = True

        # Remove material if it has only fake users
        if from_asset_library and ((mat.use_fake_user and mat.users == 1) or mat.users == 0):
            if otree:
                remove_all_nodes_from_tree(otree)
                remove_datablock(bpy.data.node_groups, otree)     
            remove_datablock(bpy.data.materials, mat)

        if failed:
            if quick_setup_happen:
                bpy.ops.wm.y_remove_yp_node()
            return {'CANCELLED'}

        return {'FINISHED'}

class YOpenLayersFromMaterial(bpy.types.Operator):
    bl_idname = "wm.y_open_layers_from_material"
    bl_label = "Open Layers from " + get_addon_title() + " Material"
    bl_description = "Open layers from material to current " + get_addon_title() + " material"
    bl_options = {'REGISTER', 'UNDO'}

    mat_name : StringProperty(name='Material', default='')
    asset_library_path : StringProperty(default='')

    @classmethod
    def poll(cls, context):
        return context.object and get_active_ypaint_node()

    @classmethod
    def description(self, context, properties):
        return get_operator_description(self)

    def remove_mat(self, mat, from_asset_library):
        # Remove material if it has only fake users (from asset library)
        if from_asset_library and ((mat.use_fake_user and mat.users == 1) or mat.users == 0):
            remove_datablock(bpy.data.materials, mat)

    def execute(self, context):
        if self.mat_name == '':
            self.report({'ERROR'}, "Source material cannot be empty!")
            return {'CANCELLED'}

        obj = context.object
        if not obj.data or not hasattr(obj.data, 'materials'):
            self.report({'ERROR'}, "Cannot use "+get_addon_title()+" with object '"+obj.name+"'!")
            return {'CANCELLED'}

        # Get material from local first
        mat = bpy.data.materials.get(self.mat_name)

        # If not found get from the asset library
        from_asset_library = self.asset_library_path != ''
        if not mat and from_asset_library and is_bl_newer_than(3):
            with bpy.data.libraries.load(str(self.asset_library_path), assets_only=True) as (data_from, data_to):
                for mat_name in data_from.materials:
                    if mat_name == self.mat_name:
                        data_to.materials.append(mat_name)
            mat = bpy.data.materials.get(self.mat_name)

        if not mat:
            self.report({'ERROR'}, "Material cannot be found!")
            return {'CANCELLED'}

        if not mat.node_tree:
            self.remove_mat(mat, from_asset_library)
            self.report({'ERROR'}, "Material has no node tree!")
            return {'CANCELLED'}

        # Find yp node in source material
        source_yp_node = None
        for node in mat.node_tree.nodes:
            if node.type == 'GROUP' and hasattr(node.node_tree, 'yp') and node.node_tree.yp.is_ypaint_node:
                source_yp_node = node
                break

        if not source_yp_node:
            self.remove_mat(mat, from_asset_library)
            self.report({'ERROR'}, "Material has no "+get_addon_title()+" node!")
            return {'CANCELLED'}

        source_tree = source_yp_node.node_tree
        # Rename material so it can be correctly removed after pasting layer
        if from_asset_library: source_tree.name = TEMP_TREE_PREFIX + source_tree.name
        source_yp = source_tree.yp

        if len(source_yp.layers) == 0:
            self.remove_mat(mat, from_asset_library)
            remove_temporary_trees()
            self.report({'ERROR'}, "Material has no layers!")
            return {'CANCELLED'}

        # Do update before copying layers
        if version_tuple(source_yp.version) < version_tuple(get_current_version_str()):
            try:
                print('Open Layers: Updating source layers to version '+get_current_version_str()+'...')
                bpy.ops.wm.y_update_yp_trees('INVOKE_DEFAULT')
            except Exception as e:
                self.remove_mat(mat, from_asset_library)
                remove_temporary_trees()
                self.report({'ERROR'}, "Failed to update source layers: "+str(e))
                return {'CANCELLED'}

        # Copy all layers to clipboard
        wmp = context.window_manager.ypprops
        wmp.clipboard_tree = source_tree.name
        wmp.clipboard_layer = '' # Empty means all layers

        try:
            bpy.ops.wm.y_paste_layer('INVOKE_DEFAULT')
        except Exception as e:
            self.remove_mat(mat, from_asset_library)
            remove_temporary_trees()
            self.report({'ERROR'}, "Failed to paste layers: "+str(e))
            return {'CANCELLED'}

        self.remove_mat(mat, from_asset_library)

        return {'FINISHED'}

class YOpenImagesToSingleLayer(bpy.types.Operator, ImportHelper, BaseMultipleImagesLayer):
    bl_idname = "wm.y_open_images_to_single_layer"
    bl_label = "Open Images to single Layer"
    bl_description = "Open images to single layer"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        #return hasattr(context, 'group_node') and context.group_node
        return get_active_ypaint_node()

    def invoke(self, context, event):
        self.invoke_operator(context)
        return self.running_fileselect_modal(context, event)

    def check(self, context):
        return self.check_operator(context)

    def draw(self, context):
        self.draw_operator(context)

    def execute(self, context):
        import_list, directory = self.generate_paths()
        if not self.open_images_to_single_layer(context, directory=directory, import_list=import_list):
            self.report({'ERROR'}, "Images should have channel name as suffix!")
            return {'CANCELLED'}
        
        return {'FINISHED'}

class YOpenImageAsLayer(bpy.types.Operator, ImportHelper, BaseOperator.OpenImage):
    """Open Image as Layer"""
    bl_idname = "wm.y_open_image_to_layer"
    bl_label = "Open Image as Layer"
    bl_options = {'REGISTER', 'UNDO'}

    interpolation : EnumProperty(
        name = 'Image Interpolation Type',
        description = 'Image interpolation type',
        items = interpolation_type_items,
        default = 'Linear'
    )

    texcoord_type : EnumProperty(
        name = 'Layer Coordinate Type',
        description = 'Layer Coordinate Type',
        items = texcoord_type_items,
        default = 'UV'
    )

    uv_map : StringProperty(
        name = 'UV Map',
        description = 'UV Map to use for layer coordinate',
        default = ''
    )

    channel_idx : EnumProperty(
        name = 'Channel',
        description = 'Channel of new layer, can be changed later',
        items = BaseOperator.channel_items,
        update = update_channel_idx_new_layer
    )

    blend_type : EnumProperty(
        name = 'Blend',
        items = blend_type_items,
    )

    height_blend_type : EnumProperty(
        name = 'Height Blend Type',
        description = 'Height blend type',
        items = height_blend_type_items,
    )

    normal_blend_type : EnumProperty(
        name = 'Normal Blend Type',
        description = 'Normal blend type',
        items = normal_blend_type_items,
        default = 'MIX'
    )

    normal_map_type : EnumProperty(
        name = 'Normal Map Type',
        description = 'Normal map type of this layer',
        items = layer_common.get_normal_map_type_items
    )

    normal_space : EnumProperty(
        name = 'Normal Space',
        items = normal_space_items,
        default = 'TANGENT'
    )

    use_udim_detecting : BoolProperty(
        name = 'Detect UDIMs',
        description = 'Detect selected UDIM files and load all matching tiles.',
        default = True
    )

    read_layers : BoolProperty(
        name = 'Read Layers',
        description = 'Read layers from image and put them into separate layers',
        default = False
    )

    convert_image_to_solid_color : BoolProperty(
        name = 'Convert Flat Layer to Solid Color',
        description = 'Convert flat image layer to solid color',
        default = True
    )

    extra_desc = '\nCurrently only works with opened non-UDIM images.' if is_udim_supported() else ''

    use_image_atlas : BoolProperty(
        name = 'Use Image Atlas',
        description = 'Use shared image for multiple layers/masks, can save image slots for Blender with OpenGL'+extra_desc,
        default = False
    )

    uv_map_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    file_browser_filepath : StringProperty(default='')

    @classmethod
    def poll(cls, context):
        #return hasattr(context, 'group_node') and context.group_node
        return get_active_ypaint_node()

    @classmethod
    def description(self, context, properties):
        return get_operator_description(self)

    def invoke(self, context, event):
        obj = context.object
        node = get_active_ypaint_node()
        yp = node.node_tree.yp

        if not is_object_work_with_uv(obj):
            self.texcoord_type = 'Generated'

        # Use active uv layer name by default
        if obj.type == 'MESH':
            self.uv_map = get_default_uv_name(obj, yp)

            # UV Map collections update
            self.uv_map_coll.clear()
            for uv in obj.data.uv_layers:
                if not uv.name.startswith(TEMP_UV):
                    self.uv_map_coll.add().name = uv.name

        # Normal map is the default
        #self.normal_map_type = 'NORMAL_MAP'

        if self.file_browser_filepath != '':
            if get_user_preferences().skip_property_popups and not event.shift:
                return self.execute(context)
            return context.window_manager.invoke_props_dialog(self)
        
        return self.running_fileselect_modal(context, event)

    def draw(self, context):
        node = get_active_ypaint_node()
        yp = node.node_tree.yp
        obj = context.object
        params = context.space_data.params

        channel = yp.channels[BaseOperator.get_self_channel_idx(self)] if BaseOperator.get_self_channel_idx(self) != -1 else None

        layout = self.layout
        split_val = 0.3
        
        if self.file_browser_filepath != '':
            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Image:')
            row.label(text=os.path.basename(self.file_browser_filepath), icon='IMAGE_DATA')

        row = split_layout(layout, split_val)
        right_aligned_label(row, 'Interpolation:')
        row.prop(self, 'interpolation', text='')

        row = split_layout(layout, split_val)
        right_aligned_label(row, 'Mapping:')
        crow = row.row(align=True)
        crow.prop(self, 'texcoord_type', text='')
        if obj.type == 'MESH' and self.texcoord_type == 'UV':
            crow.prop_search(self, "uv_map", self, "uv_map_coll", text='', icon='GROUP_UVS')

        row = split_layout(layout, split_val)
        right_aligned_label(row, 'Channel:')
        rrow = row.row(align=True)
        BaseOperator.draw_self_channel_idx(self, rrow, yp)
        if channel:
            if channel.special_type == 'NORMAL':
                rrow.prop(self, 'normal_blend_type', text='')
            elif channel.special_type == 'HEIGHT':
                rrow.prop(self, 'height_blend_type', text='')
            else: 
                rrow.prop(self, 'blend_type', text='')

            if channel.special_type == 'NORMAL':
                row = split_layout(layout, split_val)
                right_aligned_label(row, 'Space:')
                row.prop(self, 'normal_space', text='')

        # Toggles column
        if self.file_browser_filepath != '':
            row = split_layout(layout, split_val)
            layout = row.column()
            layout = row.column()

        layout.prop(self, 'use_image_atlas')

        # Detect for udim image
        match = re.match(r'.+\.\d{4}\..+', params.filename)
        udim_image_found = True if match else False

        rrow = layout.row(align=True)
        if self.use_image_atlas and (not is_udim_supported() or not udim_image_found):
            rrow.active = False
        rrow.prop(self, 'relative')

        if is_udim_supported():
            layout.prop(self, 'use_udim_detecting')

        # Detect for layered images
        layered_image_found = False
        ext = ''
        if get_lowercase_extension(params.filename) == 'psd':
            layered_image_found = True
            ext = 'psd'

        if not layered_image_found and hasattr(context, 'selected_files') and context.selected_files:
            for f in context.selected_files:
                ext = get_lowercase_extension(f.name)
                if ext == 'psd':
                    layered_image_found = True
                    break
        
        if layered_image_found and is_bl_newer_than(2, 80):
            psd_io = get_package_module('.psd_io')
            if ext == 'psd':
                layout.prop(self, 'read_layers', text='Read Photoshop Layers')
                if self.read_layers:
                    layout.prop(self, 'convert_image_to_solid_color')
                    if psd_io:
                        psd_io.draw_no_psd_tools_warning(layout)
                    else: 
                        layout.alert = True
                        layout.label(text='Reading PSD layers currently only', icon='ERROR')
                        layout.label(text='available in Ucupaint Plus!', icon='BLANK1')
                        layout.alert = False
            elif ext == 'kra':
                layout.prop(self, 'read_layers', text='Read Krita Layers')
            elif ext == 'xcf':
                layout.prop(self, 'read_layers', text='Read GIMP Layers')

    def execute(self, context):
        T = time.time()

        psd_io = get_package_module('.psd_io')
        wm = context.window_manager
        node = get_active_ypaint_node()
        yp = node.node_tree.yp
        obj = context.object

        if self.file_browser_filepath == '':
            import_list, directory = self.generate_paths()
        else:
            if not os.path.isfile(self.file_browser_filepath):
                self.report({'ERROR'}, "There's no image with address '" + self.file_browser_filepath + "'!")
                return {'CANCELLED'}
            import_list = [os.path.basename(self.file_browser_filepath)]
            directory = os.path.dirname(self.file_browser_filepath)

        if not is_udim_supported():
            images = tuple(load_image(path, directory) for path in import_list)
        else:
            ori_ui_type = bpy.context.area.type
            ori_tree_type = bpy.context.area.spaces[0].tree_type if ori_ui_type == 'NODE_EDITOR' else None
            bpy.context.area.type = 'IMAGE_EDITOR'
            images = []
            for path in import_list:
                bpy.ops.image.open(
                    filepath=directory + os.sep + path, directory=directory, 
                    relative_path=self.relative, use_udim_detecting=self.use_udim_detecting
                )
                image = bpy.context.space_data.image
                if image not in images:
                    images.append(image)
            bpy.context.area.type = ori_ui_type
            if ori_tree_type != None:
                bpy.context.area.spaces[0].tree_type = ori_tree_type

        yp.halt_update = True

        # Put images into layer descriptors
        lds = []
        for image in images:
            ld = create_layer_descriptor()
            ld.type = 'IMAGE'
            ld.blend_type = self.blend_type
            ld.opacity = 1.0
            ld.image = image
            ld.name = image.name
            lds.append(ld)

        # Get layers from layered image
        any_psd_layers = False
        if self.read_layers:
            updated_lds = []
            updated_images = []
            for image in images:
                psd_found = get_lowercase_extension(image.filepath) == 'psd'
                if psd_found: any_psd_layers = True
                if psd_found and psd_io and psd_io.is_psd_io_supported() and psd_io.ensure_psd_tools():
                    extra_lds = psd_io.read_psd_image_layers(image, 
                        convert_image_to_solid_color=self.convert_image_to_solid_color
                    )
                    if any(extra_lds):
                        for ld in extra_lds:
                            if ld.image: updated_images.append(ld.image)
                            # Make sure parent index point to correct index
                            if ld.parent_idx != -1:
                                ld.parent_idx += len(updated_lds)
                        updated_lds.extend(extra_lds)
                else:
                    ld = [d for d in lds if d.image == image][0]
                    updated_lds.append(ld)
                    if ld.image: updated_images.append(ld.image)

            if any(updated_lds):
                # Remove unused images
                for image in images:
                    if image not in updated_images:
                        remove_datablock(bpy.data.images, image)

                # Point to updated images
                lds = updated_lds

        try: active_layer = yp.layers[yp.active_layer_index]
        except: active_layer = None

        # Get designated index that the layer will be
        designated_index = 0
        designated_parent_idx = -1
        if active_layer:
            designated_index = get_layer_index(active_layer)
            if active_layer.type == 'GROUP':
                designated_parent_idx = designated_index
                designated_index += 1
            elif active_layer.parent_idx != -1:
                designated_parent_idx = active_layer.parent_idx

        # Convert standalone images to atlas segments if needed
        temp_images = []
        if self.use_image_atlas:
            transp_atlas = None
            white_atlas = None
            black_atlas = None

            for ld in lds:
                # TODO: UDIM atlas
                if ld.image and ld.type == 'IMAGE' and ld.image.source != 'TILED':
                    segment = ImageAtlas.get_set_image_atlas_segment(
                        ld.image.size[0], ld.image.size[1],
                        'TRANSPARENT', ld.image.is_float, yp=yp,
                        predefined_atlas=transp_atlas
                    )
                    atlas = segment.id_data
                    transp_atlas = atlas
                    copy_image_pixels(ld.image, atlas, segment=segment)
                    temp_images.append(ld.image)
                    ld.image = atlas
                    ld.segment = segment

                if ld.mask_image:
                    if is_image_bright(ld.mask_image):
                        base_color = 'WHITE'
                        predefined_atlas = white_atlas
                    else:
                        base_color = 'BLACK'
                        predefined_atlas = black_atlas

                    base_color = 'WHITE' if is_image_bright(ld.mask_image) else 'BLACK'
                    mask_seg = ImageAtlas.get_set_image_atlas_segment(
                        ld.mask_image.size[0], ld.mask_image.size[1],
                        base_color, ld.mask_image.is_float, yp=yp,
                        predefined_atlas=predefined_atlas

                    )
                    mask_atlas = mask_seg.id_data
                    if base_color == 'WHITE': white_atlas = mask_atlas
                    else: black_atlas = mask_atlas
                    copy_image_pixels(ld.mask_image, mask_atlas, segment=mask_seg)
                    temp_images.append(ld.mask_image)
                    ld.mask_image = mask_atlas
                    ld.mask_segment = mask_seg

        for ld in lds:

            if ld.image and ld.image.filepath != '' and self.relative and bpy.data.filepath != '':
                try: image.filepath = bpy.path.relpath(image.filepath)
                except: pass

            layer = layer_common.add_new_layer(
                group_tree=node.node_tree, layer_name=ld.name,
                layer_type=ld.type, channel_idx=BaseOperator.get_self_channel_idx(self),
                blend_type=ld.blend_type, normal_blend_type=self.normal_blend_type,
                normal_map_type=self.normal_map_type, texcoord_type=self.texcoord_type,
                uv_name = self.uv_map, image=ld.image, vcol=None, segment=ld.segment,
                interpolation=self.interpolation, normal_space=self.normal_space,
                height_blend_type=self.height_blend_type,
                solid_color = ld.color,
                add_mask = ld.mask_image != None,
                mask_uv_name=self.uv_map, mask_image=ld.mask_image, mask_segment=ld.mask_segment,
                enable = ld.enable,
                use_designated_idx = True,
                designated_index = designated_index,
                designated_parent_idx = designated_parent_idx
            )

            if ld.segment:
                ImageAtlas.set_segment_mapping(layer, ld.segment, ld.image)
                refresh_temp_uv(obj, layer)

            # Repoint to correct name
            ld.name = layer.name

            if ld.opacity != 1.0:
                set_entity_prop_value(layer, 'intensity_value', ld.opacity)

        # Check if there's added group layers
        need_root_io_check_again = False
        for ld in lds:
            layer = yp.layers.get(ld.name)
            if not layer: continue
            if ld.parent_idx != -1:
                try: parent_ld = lds[ld.parent_idx]
                except: continue
                parent_layer = yp.layers.get(parent_ld.name)
                parent_layer.expand_subitems = True
                if parent_layer:
                    layer.parent_idx = get_layer_index(parent_layer)

                # Check layer IO
                check_all_layer_channel_io_and_nodes(layer)

                # Rearrange node inside layers
                reconnect_layer_nodes(layer)
                rearrange_layer_nodes(layer)

                need_root_io_check_again = True

        if need_root_io_check_again:
            check_start_end_root_ch_nodes(node.node_tree)

        yp.halt_update = False

        # Reconnect and rearrange nodes
        reconnect_yp_nodes(node.node_tree)
        rearrange_yp_nodes(node.node_tree)

        # Remove unused images
        for temp_image in temp_images:
            remove_datablock(bpy.data.images, temp_image)

        # Update UI
        wm.ypui.need_update = True
        if self.texcoord_type == 'Decal':
            wm.ypui.layer_ui.expand_content = True
            wm.ypui.layer_ui.expand_vector = True

        if any_psd_layers and psd_io and not psd_io.is_psd_tools_found():
            self.report({'WARNING'}, 'Trying to read PSD image as layers but no PSD-Tools module installed, so image read as merged!')

        print('INFO: Image(s) opened in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YOpenExistingDataToOverrideChannel(bpy.types.Operator):
    """Open Existing Data to Override Channel Layer"""
    bl_idname = "wm.y_open_existing_data_to_override_channel"
    bl_label = "Open Existing Data to Override Channel Layer"
    bl_options = {'REGISTER', 'UNDO'}

    type : EnumProperty(
        name = 'Layer Type',
        items = (
            ('IMAGE', 'Image', ''),
            ('VCOL', get_vertex_color_label(), '')
        ),
        default = 'IMAGE'
    )

    image_name : StringProperty(name="Image")
    image_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    vcol_name : StringProperty(name=get_vertex_color_label())
    vcol_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    @classmethod
    def poll(cls, context):
        #return hasattr(context, 'group_node') and context.group_node
        return get_active_ypaint_node()

    def invoke(self, context, event):
        self.ch = context.parent
        obj = context.object
        node = get_active_ypaint_node()
        yp = node.node_tree.yp

        if self.type == 'IMAGE':
            # Update image names
            self.image_coll.clear()
            imgs = bpy.data.images
            baked_channel_images = get_all_baked_channel_images(node.node_tree)
            for img in imgs:
                if is_image_available_to_open(img) and img not in baked_channel_images:
                    self.image_coll.add().name = img.name
        elif self.type == 'VCOL':
            self.vcol_coll.clear()
            for vcol_name in get_vertex_color_names(obj):
                if vcol_name != COLOR_ID_VCOL_NAME:
                    self.vcol_coll.add().name = vcol_name

        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        node = get_active_ypaint_node()
        yp = node.node_tree.yp
        obj = context.object

        row = split_layout(self.layout, 0.3, align=True)

        if self.type == 'IMAGE':
            row.label(text='Image:')
            row.prop_search(self, "image_name", self, "image_coll", text='', icon='IMAGE_DATA')
        elif self.type == 'VCOL':
            row.label(text=get_vertex_color_label()+':')
            row.prop_search(self, "vcol_name", self, "vcol_coll", text='', icon='GROUP_VCOL')

    def execute(self, context):
        T = time.time()
        wm = context.window_manager

        obj = context.object
        mat = obj.active_material

        ch = self.ch
        yp = ch.id_data.yp
        m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', ch.path_from_id())
        if not m: return []
        layer = yp.layers[int(m.group(1))]
        root_ch = yp.channels[int(m.group(2))]
        tree = get_tree(layer)

        # Make sure channel is on
        if not ch.enable:
            ch.enable = True

        if self.type == 'IMAGE':
            if self.image_name == '':
                self.report({'ERROR'}, "Image name cannot be empty!")
                return {'CANCELLED'}
            image = bpy.data.images.get(self.image_name)

            if not image:
                self.report({'ERROR'}, "Image named " + self.image_name + " is not found!")
                return {'CANCELLED'}

            # Make sure override is on
            if not ch.override:
                ch.override = True

            # Update image cache
            if ch.override_type == 'IMAGE':
                source_tree = get_channel_source_tree(ch, layer)
                source_label = root_ch.name + ' Override : ' + ch.override_type
                image_node, dirty = check_new_node(source_tree, ch, 'source', 'ShaderNodeTexImage', source_label, True)
            else: image_node, dirty = check_new_node(tree, ch, 'cache_image', 'ShaderNodeTexImage', '', True)

            image_node.image = image
            if root_ch.special_type == 'HEIGHT': image_node.interpolation = 'Cubic'
            #if image.colorspace_settings.name != get_noncolor_name():
            #    image.colorspace_settings.name = get_noncolor_name()

        elif self.type == 'VCOL':

            if self.vcol_name == '':
                self.report({'ERROR'}, get_vertex_color_label()+" name cannot be empty!")
                return {'CANCELLED'}

            if self.vcol_name not in get_vertex_color_names(obj):
                self.report({'ERROR'}, get_vertex_color_label()+" named " + self.vcol_name + " is not found!")
                return {'CANCELLED'}

            vcols = get_vertex_colors(obj)
            if self.vcol_name in vcols:
                vcol = vcols.get(self.vcol_name)

            # Make sure override is on
            if not ch.override:
                ch.override = True

            objs = [obj] if obj.type == 'MESH' else []
            if mat.users > 1:
                for o in get_scene_objects():
                    if o.type != 'MESH': continue
                    if mat.name in o.data.materials and o not in objs:
                        objs.append(o)

            for o in objs:
                if self.vcol_name not in get_vertex_colors(o):
                    if not is_bl_newer_than(3, 3) and len(get_vertex_colors(o)) >= 8: continue
                    data_type, domain = get_vcol_data_type_and_domain_by_name(o, self.vcol_name, objs)
                    other_v = new_vertex_color(o, self.vcol_name, data_type, domain, color_fill=(0.0, 0.0, 0.0, 1.0))
                    set_active_vertex_color(o, other_v)

            # Update vcol cache
            if ch.override_type == 'VCOL':
                source_label = root_ch.name + ' Override : ' + ch.override_type
                vcol_node, dirty = check_new_node(tree, ch, 'source', get_vcol_bl_idname(), source_label, True)
            else: vcol_node, dirty = check_new_node(tree, ch, 'cache_vcol', get_vcol_bl_idname(), '', True)

            set_source_vcol_name(vcol_node, self.vcol_name)

            # Set vcol name attribute
            yp.halt_update = True
            ch.override_vcol_name = self.vcol_name
            yp.halt_update = False

        ch.override_type = self.type
        ch.active_edit = self.type in {'IMAGE', 'VCOL'}

        # Update list items
        ListItem.refresh_list_items(yp)

        # Update UI
        wm.ypui.need_update = True
        print('INFO: Data is opened in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YOpenExistingDataToLayer(bpy.types.Operator):
    """Open Existing Data as Layer"""
    bl_idname = "wm.y_open_existing_data_to_layer"
    bl_label = "Open Existing Data as Layer"
    bl_options = {'REGISTER', 'UNDO'}

    type : EnumProperty(
        name = 'Layer Type',
        items = (
            ('IMAGE', 'Image', ''),
            ('VCOL', get_vertex_color_label(), '')
        ),
        default = 'IMAGE'
    )

    interpolation : EnumProperty(
        name = 'Image Interpolation Type',
        description = 'Image interpolation type',
        items = interpolation_type_items,
        default = 'Linear'
    )

    texcoord_type : EnumProperty(
        name = 'Layer Coordinate Type',
        description = 'Layer Coordinate Type',
        items = texcoord_type_items,
        default = 'UV'
    )

    uv_map : StringProperty(
        name = 'UV Map',
        description = 'UV Map to use for layer coordinate',
        default = ''
    )

    channel_idx : EnumProperty(
        name = 'Channel',
        description = 'Channel of new layer, can be changed later',
        items = BaseOperator.channel_items,
        update = update_channel_idx_new_layer
    )

    blend_type : EnumProperty(
        name = 'Blend',
        items = blend_type_items,
    )

    height_blend_type : EnumProperty(
        name = 'Height Blend Type',
        description = 'Height blend type',
        items = height_blend_type_items,
    )

    normal_blend_type : EnumProperty(
        name = 'Normal Blend Type',
        description = 'Normal blend type',
        items = normal_blend_type_items,
        default = 'MIX'
    )

    normal_map_type : EnumProperty(
        name = 'Normal Map Type',
        description = 'Normal map type of this layer',
        items = layer_common.get_normal_map_type_items
    )
    
    normal_space : EnumProperty(
        name = 'Normal Space',
        items = normal_space_items,
        default = 'TANGENT'
    )

    image_name : StringProperty(name="Image")
    image_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    vcol_name : StringProperty(name=get_vertex_color_label())
    vcol_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    uv_map_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    @classmethod
    def poll(cls, context):
        #return hasattr(context, 'group_node') and context.group_node
        return get_active_ypaint_node()

    def invoke(self, context, event):
        obj = context.object
        node = get_active_ypaint_node()
        yp = node.node_tree.yp

        if not is_object_work_with_uv(obj):
            self.texcoord_type = 'Generated'

        # Use active uv layer name by default
        if obj.type == 'MESH':
            self.uv_map = get_default_uv_name(obj, yp)

            # UV Map collections update
            self.uv_map_coll.clear()
            for uv in obj.data.uv_layers:
                if not uv.name.startswith(TEMP_UV):
                    self.uv_map_coll.add().name = uv.name

        if self.type == 'IMAGE':
            # Update image names
            self.image_coll.clear()
            imgs = bpy.data.images
            baked_channel_images = get_all_baked_channel_images(node.node_tree)
            for img in imgs:
                if is_image_available_to_open(img) and img not in baked_channel_images:
                    self.image_coll.add().name = img.name
        elif self.type == 'VCOL':
            self.vcol_coll.clear()
            for vcol_name in get_vertex_color_names(obj):
                if vcol_name != COLOR_ID_VCOL_NAME:
                    self.vcol_coll.add().name = vcol_name

        return context.window_manager.invoke_props_dialog(self)

    def check(self, context):
        return True

    def draw(self, context):
        node = get_active_ypaint_node()
        yp = node.node_tree.yp
        obj = context.object

        channel = yp.channels[BaseOperator.get_self_channel_idx(self)] if BaseOperator.get_self_channel_idx(self) != -1 else None

        split_val = 0.4

        if self.type == 'IMAGE':
            row = split_layout(self.layout, split_val)
            right_aligned_label(row, 'Image:')
            row.prop_search(self, "image_name", self, "image_coll", text='', icon='IMAGE_DATA')

            row = split_layout(self.layout, split_val)
            right_aligned_label(row, 'Interpolation:')
            row.prop(self, 'interpolation', text='')

            row = split_layout(self.layout, split_val)
            right_aligned_label(row, 'Mapping:')
            crow = row.row(align=True)
            crow.prop(self, 'texcoord_type', text='')
            if obj.type == 'MESH' and self.texcoord_type == 'UV':
                #crow.prop_search(self, "uv_map", obj.data, "uv_layers", text='', icon='GROUP_UVS')
                crow.prop_search(self, "uv_map", self, "uv_map_coll", text='', icon='GROUP_UVS')

        elif self.type == 'VCOL':
            row = split_layout(self.layout, split_val)
            right_aligned_label(row, get_vertex_color_label()+':')
            row.prop_search(self, "vcol_name", self, "vcol_coll", text='', icon='GROUP_VCOL')

        row = split_layout(self.layout, split_val)
        right_aligned_label(row, 'Channel:')
        rrow = row.row(align=True)
        BaseOperator.draw_self_channel_idx(self, rrow, yp)
        if channel and channel.special_type == 'NORMAL':
            rrow.prop(self, 'normal_blend_type', text='')
            row = split_layout(self.layout, split_val)
            right_aligned_label(row, 'Space:')
            row.prop(self, 'normal_space', text='')
        elif channel and channel.special_type == 'HEIGHT':
            rrow.prop(self, 'height_blend_type', text='')
        elif channel:
            rrow.prop(self, 'blend_type', text='')

    def execute(self, context):
        T = time.time()

        obj = context.object
        mat = obj.active_material
        wm = context.window_manager
        node = get_active_ypaint_node()

        if self.type == 'IMAGE' and self.image_name == '':
            self.report({'ERROR'}, "No image selected!")
            return {'CANCELLED'}
        elif self.type == 'VCOL' and self.vcol_name == '':
            self.report({'ERROR'}, "No "+get_vertex_color_label(00)+" selected!")
            return {'CANCELLED'}

        node.node_tree.yp.halt_update = True

        image = None
        vcol = None
        if self.type == 'IMAGE':
            image = bpy.data.images.get(self.image_name)
            name = image.name
        elif self.type == 'VCOL':
            name = self.vcol_name
            vcols = get_vertex_colors(obj)
            if self.vcol_name in vcols:
                vcol = vcols.get(self.vcol_name)

            objs = [obj] if obj.type == 'MESH' else []
            if mat.users > 1:
                for o in get_scene_objects():
                    if o.type != 'MESH': continue
                    if mat.name in o.data.materials and o not in objs:
                        objs.append(o)

            for o in objs:
                if self.vcol_name not in get_vertex_colors(o):
                    if not is_bl_newer_than(3, 3) and len(get_vertex_colors(o)) >= 8: continue
                    data_type, domain = get_vcol_data_type_and_domain_by_name(o, self.vcol_name, objs)

                    color = (0.0, 0.0, 0.0, 0.0)
                    if not is_bl_newer_than(2, 92):
                        color = (0.0, 0.0, 0.0, 1.0)
                    other_v = new_vertex_color(o, self.vcol_name, data_type, domain, color_fill=color)

                    set_active_vertex_color(o, other_v)

        layer_common.add_new_layer(
            group_tree=node.node_tree, layer_name=name,
            layer_type=self.type, channel_idx=BaseOperator.get_self_channel_idx(self),
            blend_type=self.blend_type, normal_blend_type=self.normal_blend_type,
            normal_map_type=self.normal_map_type, texcoord_type=self.texcoord_type,
            uv_name=self.uv_map, image=image, vcol=vcol, segment=None,
            interpolation=self.interpolation, normal_space=self.normal_space,
            height_blend_type=self.height_blend_type
        )

        node.node_tree.yp.halt_update = False

        # Reconnect and rearrange nodes
        reconnect_yp_nodes(node.node_tree)
        rearrange_yp_nodes(node.node_tree)

        # Update UI
        wm.ypui.need_update = True
        if self.texcoord_type == 'Decal':
            wm.ypui.layer_ui.expand_content = True
            wm.ypui.layer_ui.expand_vector = True

        print('INFO: Image', self.image_name, 'is opened in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YMoveInOutLayerGroup(bpy.types.Operator):
    bl_idname = "wm.y_move_in_out_layer_group"
    bl_label = "Move In/Out Layer Group"
    bl_description = "Move in or out layer group"
    bl_options = {'REGISTER', 'UNDO'}

    direction : EnumProperty(
        name = 'Direction',
        items = (
            ('UP', 'Up', ''),
            ('DOWN', 'Down', '')
        ),
        default = 'UP'
    )

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return group_node and len(group_node.node_tree.yp.layers) > 0

    def execute(self, context):
        T = time.time()

        wm = context.window_manager
        node = get_active_ypaint_node()
        yp = node.node_tree.yp

        num_layers = len(yp.layers)
        layer_idx = yp.active_layer_index
        layer = yp.layers[layer_idx]

        # Remember parent and indices
        parent_dict = get_parent_dict(yp)
        index_dict = get_index_dict(yp)
        
        # Move image slot
        if self.direction == 'UP':
            neighbor_idx, neighbor_layer = get_upper_neighbor(layer)
        elif self.direction == 'DOWN' and layer_idx < num_layers-1:
            neighbor_idx, neighbor_layer = get_lower_neighbor(layer)
        else:
            neighbor_idx = -1
            neighbor_layer = None

        #move_outside_up = False
        #move_outside_down = False
        original_parent_idx = -1

        # Move outside up
        if is_top_member(layer) and self.direction == 'UP':
            #print('Case 1')

            parent_dict = set_parent_dict_val(yp, parent_dict, layer.name, neighbor_layer.parent_idx)

            last_member_idx = get_last_child_idx(layer)
            yp.layers.move(neighbor_idx, last_member_idx)

            yp.active_layer_index = neighbor_idx

            original_parent_idx = last_member_idx

        # Move outside down
        elif is_bottom_member(layer) and self.direction == 'DOWN':
            #print('Case 2')

            parent_dict = set_parent_dict_val(yp, parent_dict, layer.name, yp.layers[layer.parent_idx].parent_idx)

            original_parent_idx = layer.parent_idx

        elif neighbor_layer and neighbor_layer.type == 'GROUP':

            # Move inside up
            if self.direction == 'UP':
                #print('Case 3')

                parent_dict = set_parent_dict_val(yp, parent_dict, layer.name, neighbor_idx)

            # Move inside down
            elif self.direction == 'DOWN':
                #print('Case 4')

                parent_dict = set_parent_dict_val(yp, parent_dict, layer.name, neighbor_idx)

                yp.layers.move(neighbor_idx, layer_idx)
                yp.active_layer_index = layer_idx+1

        # Remap parents
        for lay in yp.layers:
            lay.parent_idx = get_layer_index_by_name(yp, parent_dict[lay.name])

        # Remap fcurves
        remap_layer_fcurves(yp, index_dict)

        layer = yp.layers[yp.active_layer_index]
        #has_parent = layer.parent_idx != -1

        # Check uv maps
        check_uv_nodes(yp)

        #if layer.type == 'GROUP' or has_parent:
        check_all_layer_channel_io_and_nodes(layer) #, has_parent=has_parent)
        reconnect_layer_nodes(layer)
        rearrange_layer_nodes(layer)

        # Also check original parent io and nodes
        if original_parent_idx != -1:
            original_parent = yp.layers[original_parent_idx]
            check_all_layer_channel_io_and_nodes(original_parent) #, has_parent=has_parent)
            reconnect_layer_nodes(original_parent)
            rearrange_layer_nodes(original_parent)

        # Background layers should update its ios
        recheck_background_layers_ios(yp, index_dict)

        # Refresh layer channel blend nodes
        reconnect_yp_nodes(node.node_tree)
        rearrange_yp_nodes(node.node_tree)

        # Make sure new parent subitems is expanded
        if layer.parent_idx != -1:
            parent = yp.layers[layer.parent_idx]
            if not parent.expand_subitems:
                parent.expand_subitems = True

        # Update list items
        ListItem.refresh_list_items(yp, repoint_active=True)

        # Update UI
        wm.ypui.need_update = True
        print('INFO: Layer', layer.name, 'is moved in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YMoveLayer(bpy.types.Operator):
    bl_idname = "wm.y_move_layer"
    bl_label = "Move Layer"
    bl_description = "Move layer"
    bl_options = {'REGISTER', 'UNDO'}

    direction : EnumProperty(
        name = 'Direction',
        items = (
            ('UP', 'Up', ''),
            ('DOWN', 'Down', '')
        ),
        default = 'UP'
    )

    @classmethod
    def poll(cls, context):
        return active_layer_op_poll(context)

    def execute(self, context):
        T = time.time()

        wm = context.window_manager
        node = get_active_ypaint_node()
        yp = node.node_tree.yp

        num_layers = len(yp.layers)
        layer_idx = yp.active_layer_index
        layer = yp.layers[layer_idx]

        # Get last member of group if selected layer is a group
        last_member_idx = get_last_child_idx(layer)
        
        # Get neighbor
        neighbor_idx = None
        neighbor_layer = None

        if self.direction == 'UP':
            neighbor_idx, neighbor_layer = get_upper_neighbor(layer)

        elif self.direction == 'DOWN':
            neighbor_idx, neighbor_layer = get_lower_neighbor(layer)

        if not neighbor_layer:
            return {'CANCELLED'}

        # Remember all parents and indices
        parent_dict = get_parent_dict(yp)
        index_dict = get_index_dict(yp)

        if layer.type == 'GROUP' and neighbor_layer.type != 'GROUP':

            # Group layer UP to standard layer
            if self.direction == 'UP':
                #print('Case A')

                # Swap layer
                yp.layers.move(neighbor_idx, last_member_idx)
                yp.active_layer_index = neighbor_idx

            # Group layer DOWN to standard layer
            elif self.direction == 'DOWN':
                #print('Case B')

                # Swap layer
                yp.layers.move(neighbor_idx, layer_idx)
                yp.active_layer_index = layer_idx + 1

        elif layer.type == 'GROUP' and neighbor_layer.type == 'GROUP':

            # Group layer UP to group layer
            if self.direction == 'UP':
                #print('Case C')

                # Swap all related layers
                for i in range(last_member_idx + 1 - layer_idx):
                    yp.layers.move(layer_idx + i, neighbor_idx + i)

                yp.active_layer_index = neighbor_idx

            # Group layer DOWN to group layer
            elif self.direction == 'DOWN':
                #print('Case D')

                last_neighbor_member_idx = get_last_child_idx(neighbor_layer)
                num_members = last_neighbor_member_idx + 1 - neighbor_idx

                # Swap all related layers
                for i in range(num_members):
                    yp.layers.move(neighbor_idx + i, layer_idx + i)

                yp.active_layer_index = layer_idx + num_members

        elif layer.type != 'GROUP' and neighbor_layer.type == 'GROUP':

            # Standard layer UP to Group Layer
            if self.direction == 'UP':
                #print('Case E')

                # Swap layer
                yp.layers.move(layer_idx, neighbor_idx)
                yp.active_layer_index = neighbor_idx

                start_remap = neighbor_idx + 2
                end_remap = layer_idx + 1

            # Standard layer DOWN to Group Layer
            elif self.direction == 'DOWN':
                #print('Case F')

                last_neighbor_member_idx = get_last_child_idx(neighbor_layer)

                # Swap layer
                yp.layers.move(layer_idx, last_neighbor_member_idx)
                yp.active_layer_index = last_neighbor_member_idx

                start_remap = layer_idx + 1
                end_remap = last_neighbor_member_idx

        # Standard layer to standard Layer
        else:
            #print('Case G')

            # Swap layer
            yp.layers.move(layer_idx, neighbor_idx)
            yp.active_layer_index = neighbor_idx

        # Remap parents
        for lay in yp.layers:
            lay.parent_idx = get_layer_index_by_name(yp, parent_dict[lay.name])

        # Remap fcurves
        remap_layer_fcurves(yp, index_dict)

        # Height calculation can be changed after moving layer
        height_root_ch = get_root_height_channel(yp)
        if height_root_ch: update_displacement_height_ratio(height_root_ch)

        # Background layers should update its ios
        recheck_background_layers_ios(yp, index_dict)

        # Refresh layer channel blend nodes
        reconnect_yp_nodes(node.node_tree)
        rearrange_yp_nodes(node.node_tree)

        # Update list items
        ListItem.refresh_list_items(yp, repoint_active=True)

        # Update UI
        wm.ypui.need_update = True

        print('INFO: Layer', layer.name, 'is moved in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

def draw_move_up_in_layer_group(self, context):
    col = self.layout.column()

    c = col.operator("wm.y_move_layer", text='Move Up (Skip Group)', icon='TRIA_UP')
    c.direction = 'UP'

    c = col.operator("wm.y_move_in_out_layer_group", text='Move Inside Group', icon='TRIA_UP')
    c.direction = 'UP'

def draw_move_down_in_layer_group(self, context):
    col = self.layout.column()

    c = col.operator("wm.y_move_layer", text='Move Down (Skip Group)', icon='TRIA_DOWN')
    c.direction = 'DOWN'

    c = col.operator("wm.y_move_in_out_layer_group", text='Move Inside Group', icon='TRIA_DOWN')
    c.direction = 'DOWN'

class YMoveInOutLayerGroupMenu(bpy.types.Operator):
    bl_idname = "wm.y_move_in_out_layer_group_menu"
    bl_label = "Move In/Out Layer Group"
    bl_description = "Move inside or outside layer group"
    bl_options = {'UNDO'}
    bl_options = {'UNDO'}

    direction : EnumProperty(
        name = 'Direction',
        items = (
            ('UP', 'Up', ''),
            ('DOWN', 'Down', '')
        ),
        default = 'UP'
    )

    move_out : BoolProperty(default=False)

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return group_node and len(group_node.node_tree.yp.layers) > 0

    def execute(self, context):
        wm = bpy.context.window_manager

        if self.move_out:
            bpy.ops.wm.y_move_in_out_layer_group(direction=self.direction)
        else:
            if self.direction == 'UP':
                wm.popup_menu(draw_move_up_in_layer_group, title="Options")
            elif self.direction == 'DOWN':
                wm.popup_menu(draw_move_down_in_layer_group, title="Options")
        return {'FINISHED'}

def draw_remove_group(self, context):
    col = self.layout.column()

    c = col.operator("wm.y_remove_layer", text='Remove parent only', icon='PANEL_CLOSE')
    c.remove_children = False
    c.remove_on_disk = False

    c = col.operator("wm.y_remove_layer", text='Remove parent with all of its children', icon='PANEL_CLOSE')
    c.remove_children = True
    c.remove_on_disk = False

    if hasattr(context, 'layer') and any_single_user_ondisk_image_inside_group(context.layer):
        col.separator()
        col.alert = True
        col.label(text='Danger Zone', icon='ERROR')
        c = col.operator("wm.y_remove_layer", text='Remove parent with all of its children and files on disk (WARNING: NO PROMPT & NO UNDO!)', icon='PANEL_CLOSE')
        c.remove_children = True
        c.remove_on_disk = True

class YRemoveLayerMenu(bpy.types.Operator):
    bl_idname = "wm.y_remove_layer_menu"
    bl_label = "Remove Layer Menu"
    bl_description = "Remove Layer Menu"
    #bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return context.object and group_node and len(group_node.node_tree.yp.layers) > 0

    def execute(self, context):
        wm = bpy.context.window_manager
        wm.popup_menu(draw_remove_group, title="Options")
        return {'FINISHED'}

class YRemoveLayer(bpy.types.Operator):
    bl_idname = "wm.y_remove_layer"
    bl_label = "Remove Layer"
    bl_description = "Remove Layer"
    bl_options = {'UNDO'}

    remove_children : BoolProperty(name='Remove Children', description='Remove layer children', default=False)
    remove_on_disk : BoolProperty(name='Delete Image from disk', description='Delete image file from disk', default=False)

    @classmethod
    def poll(cls, context):
        return active_layer_op_poll(context)

    @classmethod
    def description(self, context, properties):
        return get_operator_description(self)

    def invoke(self, context, event):

        node = get_active_ypaint_node()
        yp = node.node_tree.yp
        layer = ListItem.get_active_layer(yp)

        # Remove on disk is dangerous so it's always disabled by default
        self.remove_on_disk = False

        # Blender 2.7x has no global undo between modes
        self.legacy_on_non_object_mode = not is_bl_newer_than(2, 80) and context.object.mode != 'OBJECT'

        # Check if there's any dirty images
        self.any_dirty_images = any_dirty_images_inside_layer(layer)

        # Removing UDIM atlas segment can't be undone
        self.any_udim_atlas = any(get_layer_images(layer, udim_atlas_only=True))

        # Only allow to remove files on disk with a confirmation popup
        if get_user_preferences().skip_property_popups and not event.shift and not self.any_dirty_images and not self.legacy_on_non_object_mode and not self.any_udim_atlas:
            return self.execute(context)

        # Check if there's ondisk image
        self.any_images_on_disk = any_single_user_ondisk_image_inside_layer(layer)

        if self.any_images_on_disk or self.legacy_on_non_object_mode or self.any_dirty_images or self.any_udim_atlas:
            return context.window_manager.invoke_props_dialog(self, width=300)
        return self.execute(context)

    def draw(self, context):

        col = self.layout.column(align=True)

        if self.legacy_on_non_object_mode:
            col.label(text='You cannot UNDO this operation in this mode.', icon='ERROR')
            col.label(text="Are you sure you want to continue?", icon='BLANK1')
        elif self.any_dirty_images:
            col.label(text="Unsaved data will be LOST if you UNDO this operation.", icon='ERROR')
            col.label(text="Are you sure you want to continue?", icon='BLANK1')
        elif self.any_udim_atlas:
            col.label(text='This layer is using UDIM atlas image segment', icon='ERROR')
            col.label(text='You cannot UNDO after removal', icon='BLANK1')
            col.label(text='Are you sure you want to continue?', icon='BLANK1')

        if self.any_images_on_disk:
            col.prop(self, 'remove_on_disk')

            if self.remove_on_disk:
                col.alert = True
                col.label(text="WARNING!", icon='ERROR')
                col.label(text="You cannot UNDO and the file will be gone forever!", icon='BLANK1')
                col.alert = False

    def check(self, context):
        return True

    def execute(self, context):
        T = time.time()

        obj = context.object
        wm = context.window_manager
        node = get_active_ypaint_node()
        group_tree = node.node_tree
        yp = group_tree.yp
        layer = ListItem.get_active_layer(yp)
        layer_name = layer.name
        layer_idx = get_layer_index(layer)

        # Remember parents
        parent_dict = get_parent_dict(yp)
        index_dict = get_index_dict(yp)

        # Remove layer fcurves first
        remove_entity_fcurves(layer)

        if self.remove_children:

            last_idx = get_last_child_idx(layer)
            for i in reversed(range(layer_idx, last_idx+1)):
                layer_common.remove_layer(yp, i, remove_on_disk=self.remove_on_disk)
                
            # The children are all gone
            child_ids = []

        else:
            # Get children and repoint child parents
            child_ids = get_list_of_direct_child_ids(layer)
            for i in child_ids:
                parent_dict[yp.layers[i].name] = parent_dict[layer.name]

            # Remove layer
            layer_common.remove_layer(yp, layer_idx, remove_on_disk=self.remove_on_disk)

        # Remove temp uv layer
        uv_layers = get_uv_layers(obj)
        for uv in uv_layers:
            if uv.name == TEMP_UV:
                uv_layers.remove(uv)

        # Set new active index
        if (yp.active_layer_index == len(yp.layers) and
            yp.active_layer_index > 0
            ):
            yp.active_layer_index -= 1
        else:
            # Force update the index to refesh paint image
            yp.active_layer_index = yp.active_layer_index

        # Remap parents
        for lay in yp.layers:
            lay.parent_idx = get_layer_index_by_name(yp, parent_dict[lay.name])

        # Remap fcurves
        remap_layer_fcurves(yp, index_dict)

        # Check uv maps
        check_uv_nodes(yp)

        # Check children
        for i in child_ids:
            lay = yp.layers[i-1]
            check_all_layer_channel_io_and_nodes(lay)
            reconnect_layer_nodes(lay)
            rearrange_layer_nodes(lay)

        # Update max height
        height_ch = get_root_height_channel(yp)
        if height_ch: update_displacement_height_ratio(height_ch)

        # Background layers should update its ios
        recheck_background_layers_ios(yp, index_dict)

        # Refresh layer channel blend nodes
        check_start_end_root_ch_nodes(group_tree)
        reconnect_yp_nodes(group_tree)
        rearrange_yp_nodes(group_tree)

        # Update UI
        wm.ypui.need_update = True

        # Refresh normal map
        yp.refresh_tree = True

        # Update list items
        ListItem.refresh_list_items(yp, repoint_active=True)

        print('INFO: Layer', layer_name, 'is deleted in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YReplaceLayerChannelOverride(bpy.types.Operator):
    bl_idname = "wm.y_replace_layer_channel_override"
    bl_label = "Replace Layer Channel Override"
    bl_description = "Replace Layer Channel Override"
    bl_options = {'REGISTER', 'UNDO'}

    type : EnumProperty(
        name = 'Layer Type',
        items = channel_override_type_items,
        default = 'IMAGE'
    )

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return context.object and group_node and len(group_node.node_tree.yp.layers) > 0

    def execute(self, context):
        ch = context.parent
        ch.override_type = self.type
        ch.override = True
        if not ch.enable: ch.enable = True

        # Update list items
        ListItem.refresh_list_items(ch.id_data.yp, repoint_active=True)

        return {'FINISHED'}

class YReplaceLayerChannelOverride1(bpy.types.Operator):
    bl_idname = "wm.y_replace_layer_channel_override_1"
    bl_label = "Replace Layer Channel Normal Override"
    bl_description = "Replace Layer Channel Normal Override"
    bl_options = {'REGISTER', 'UNDO'}

    type : EnumProperty(
        name = 'Layer Type',
        items = channel_override_1_type_items,
        default = 'IMAGE'
    )

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return context.object and group_node and len(group_node.node_tree.yp.layers) > 0

    def execute(self, context):
        ch = context.parent
        ch.override_1_type = self.type
        ch.override_1 = True
        if not ch.enable: ch.enable = True

        # Update list items
        ListItem.refresh_list_items(ch.id_data.yp, repoint_active=True)

        return {'FINISHED'}

class YRemoveLayerChannelOverrideSource(bpy.types.Operator):
    bl_idname = "wm.y_remove_channel_override_source"
    bl_label = "Replace Layer Channel Override Source"
    bl_description = "Replace Layer Channel Override Source"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return hasattr(context, 'channel') and hasattr(context, 'layer')

    def execute(self, context):
        layer = context.layer
        ch = context.channel
        tree = get_tree(layer)
        if ch.override:
            remove_node(tree, ch, 'source')
        else: remove_node(tree, ch, 'cache_image')
        ch.override_type = 'DEFAULT'
        return {'FINISHED'}

class YSetLayerChannelNormalBlendType(bpy.types.Operator):
    bl_idname = "wm.y_set_layer_channel_normal_blend_type"
    bl_label = "Set Layer Channel Normal Blend Type"
    bl_description = "Set layer channel normal blend type"
    bl_options = {'UNDO'}

    normal_blend_type : EnumProperty(
        name = 'Normal Blend Type',
        description = 'Normal blend type',
        items = normal_blend_type_items,
        default = 'MIX'
    )

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return context.object and group_node and len(group_node.node_tree.yp.layers) > 0

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        ch = context.channel
        ch.normal_blend_type = self.normal_blend_type
        return {'FINISHED'}

class YSetLayerChannelBlendType(bpy.types.Operator):
    bl_idname = "wm.y_set_layer_channel_blend_type"
    bl_label = "Set Layer Channel Blend Type"
    bl_description = "Set layer channel blend type"
    bl_options = {'UNDO'}

    blend_type : EnumProperty(
        name = 'Blend Type',
        items = blend_type_items,
        )

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return context.object and group_node and len(group_node.node_tree.yp.layers) > 0

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        ch = context.channel
        ch.blend_type = self.blend_type
        return {'FINISHED'}

class YSetLayerChannelInput(bpy.types.Operator):
    bl_idname = "wm.y_set_layer_channel_input"
    bl_label = "Set Layer Channel Source"
    bl_description = "Set layer channel source"
    bl_options = {'UNDO'}

    socket_name : StringProperty(default='')
    set_normal_input : BoolProperty(default=False)

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return context.object and group_node and len(group_node.node_tree.yp.layers) > 0

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        ch = context.channel
        layer = context.layer

        if self.socket_name == '':
            if self.set_normal_input:
                ch.override_1 = True
                ch.override_1_type = 'DEFAULT'
            else:
                ch.override = True
                ch.override_type = 'DEFAULT'
            if not ch.enable: ch.enable = True
        else:
            if self.set_normal_input:
                ch.override_1 = False
                ch.socket_input_1_name = self.socket_name
            else:
                ch.override = False
                ch.socket_input_name = self.socket_name

        # Update list items
        ListItem.refresh_list_items(ch.id_data.yp, repoint_active=True)

        return {'FINISHED'}

class YOpenImageToReplaceLayer(bpy.types.Operator, ImportHelper, BaseOperator.OpenImage):
    """Open Image to Replace Layer"""
    bl_idname = "wm.y_open_image_to_replace_layer"
    bl_label = "Open Image to Replace Layer"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return context.object and group_node and len(group_node.node_tree.yp.layers) > 0

    def invoke(self, context, event):
        self.layer = context.layer
        return self.running_fileselect_modal(context, event)

    def execute(self, context):
        T = time.time()

        wm = context.window_manager
        layer = self.layer
        yp = layer.id_data.yp

        loaded_images = self.get_loaded_images()

        if len(loaded_images) == 0 or loaded_images[0] == None:
            self.report({'ERROR'}, "No image is selected!")
            return {'CANCELLED'}

        image = loaded_images[0]

        layer_common.replace_layer_type(layer, 'IMAGE', image.name)

        print('INFO: Layer', layer.name, 'is updated in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YReplaceLayerType(bpy.types.Operator):
    bl_idname = "wm.y_replace_layer_type"
    bl_label = "Replace Layer Type"
    bl_description = "Replace Layer Type"
    bl_options = {'REGISTER', 'UNDO'}

    type : EnumProperty(
        name = 'Layer Type',
        items = layer_type_items,
        default = 'IMAGE'
    )

    item_name : StringProperty(name="Item")
    item_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    load_item : BoolProperty(default=False)

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return context.object and group_node and len(group_node.node_tree.yp.layers) > 0

    def invoke(self, context, event):
        obj = context.object
        self.layer = context.layer
        if self.load_item and self.type in {'IMAGE', 'VCOL'}:

            self.item_coll.clear()
            self.item_name = ''

            # Update image names
            if self.type == 'IMAGE':
                baked_channel_images = get_all_baked_channel_images(self.layer.id_data)
                for img in bpy.data.images:
                    if not img.yia.is_image_atlas and not img.yua.is_udim_atlas and img not in baked_channel_images:
                        self.item_coll.add().name = img.name
            else:
                for vcol_name in get_vertex_color_names(obj):
                    if vcol_name not in {COLOR_ID_VCOL_NAME}:
                        self.item_coll.add().name = vcol_name

            return context.window_manager.invoke_props_dialog(self)#, width=400)

        return self.execute(context)

    def draw(self, context):
        layout = self.layout

        split = split_layout(layout, 0.35, align=True)

        #row = self.layout.row()
        if self.type == 'IMAGE':
            split.label(text='Image:')
            split.prop_search(self, "item_name", self, "item_coll", text='', icon='IMAGE_DATA')
        else:
            split.label(text=get_vertex_color_label()+':')
            split.prop_search(self, "item_name", self, "item_coll", text='', icon='GROUP_VCOL')

    def execute(self, context):

        T = time.time()

        wm = context.window_manager
        layer = self.layer
        yp = layer.id_data.yp

        if self.type == layer.type and self.type not in {'IMAGE', 'VCOL'}: return {'CANCELLED'}
        #if layer.type == 'GROUP':
        #    self.report({'ERROR'}, "You can't change type of group layer!")
        #    return {'CANCELLED'}

        if self.load_item and self.type in {'VCOL', 'IMAGE'} and self.item_name == '':
            self.report({'ERROR'}, "Form is cannot be empty!")
            return {'CANCELLED'}

        layer_common.replace_layer_type(self.layer, self.type, self.item_name)

        print('INFO: Layer', layer.name, 'is updated in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YDuplicateLayer(bpy.types.Operator):
    bl_idname = "wm.y_duplicate_layer"
    bl_label = "Duplicate layer"
    bl_description = "Duplicate Layer"
    bl_options = {'UNDO'}

    packed_duplicate : BoolProperty(
        name = 'Duplicate Packed Images',
        description = 'Duplicate packed images',
        default = True
    )

    duplicate_blank : BoolProperty(
        name = 'Make Duplicated Images blank',
        description = 'Make duplicated images blank',
        default = False
    )

    ondisk_duplicate : BoolProperty(
        name = 'Duplicate Images on disk',
        description = 'Duplicate images on disk, this will create copies of images sourced from external files',
        default = False
    )
    
    set_new_decal_position : BoolProperty(
        name = 'Set New Decal Position to Cursor',
        description = 'Position decals at 3D Cursor when duplicating',
        default = False
    )

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return context.object and group_node and len(group_node.node_tree.yp.layers) > 0

    @classmethod
    def description(self, context, properties):
        return get_operator_description(self)

    def invoke(self, context, event):
        node = get_active_ypaint_node()
        yp = node.node_tree.yp
        #layer = yp.layers[yp.active_layer_index]
        layer = ListItem.get_active_layer(yp)

        if not layer:
            return self.execute(context)

        self.any_packed_image = False
        self.any_ondisk_image = False
        self.any_decal = False

        if not self.duplicate_blank:
            self.any_packed_image = any(get_layer_images(layer, packed_only=True))
            self.any_ondisk_image = any(get_layer_images(layer, ondisk_only=True))
            self.any_decal = Decal.any_decal_inside_layer(layer)

            if get_user_preferences().skip_property_popups and not event.shift:
                return self.execute(context)

            if self.any_packed_image or self.any_ondisk_image or self.any_decal:
                return context.window_manager.invoke_props_dialog(self, width=200)

        return self.execute(context)

    def draw(self, context):
        if self.any_packed_image:
            self.layout.prop(self, 'packed_duplicate')

        if self.any_ondisk_image:
            self.layout.prop(self, 'ondisk_duplicate')
        
        if self.any_decal:
            self.layout.prop(self, 'set_new_decal_position')

    def execute(self, context):
        T = time.time()

        wm = context.window_manager
        node = get_active_ypaint_node()
        tree = node.node_tree
        yp = tree.yp

        # Get parent and index dict
        parent_dict = get_parent_dict(yp)
        index_dict = get_index_dict(yp)

        # Get active layer
        layer_idx = yp.active_layer_index
        #layer = yp.layers[layer_idx]
        layer = ListItem.get_active_layer(yp)
        if not layer:
            self.report({'ERROR'}, "Cannot duplicate a base layer!")
            return {'CANCELLED'}
        source_layer_name = layer.name

        # Get all children
        children, child_ids = get_list_of_all_children_and_child_ids(layer)

        # Collect relevant ids to duplicate
        relevant_layer_names = [layer.name]
        relevant_ids = [layer_idx]
        for child in children:
            relevant_layer_names.append(child.name)
        relevant_ids.extend(child_ids)

        # Halt update to prevent needless reconnection
        yp.halt_update = True

        # List of newly created ids
        created_ids = []
        created_layer_names = []

        # Duplicate all relevant layers
        for i, lname in enumerate(relevant_layer_names):

            # Create new layer
            new_layer = yp.layers.add()
            new_layer.name = get_unique_name(lname, yp.layers)

            # Get original layer
            l = yp.layers.get(lname)
            group_node = tree.nodes.get(l.group_node)

            # Copy layer props
            copy_id_props(l, new_layer, ['name'])

            # Duplicate groups
            new_group_node = new_node(tree, new_layer, 'group_node', 'ShaderNodeGroup', group_node.label)
            new_group_node.node_tree = group_node.node_tree

            # Duplicate group inputs
            source_node = tree.nodes.get(l.group_node)
            for inp in new_group_node.inputs:
                source_inp = source_node.inputs.get(inp.name)
                if source_inp: inp.default_value = source_inp.default_value

            # Rename masks
            mask_names = [m.name for m in l.masks]
            for mask in new_layer.masks:
                if mask.type in {'VCOL'}: continue
                m = re.match(r'^Mask\s.*\((.+)\)$', mask.name)
                if m:
                    old_layer_name = m.group(1)
                    if old_layer_name == lname:
                        mask.name = mask.name.replace(old_layer_name, new_layer.name)
                else:
                    # Rename mask name with different name than original layer mask since
                    # image atlas will show actual mask name rather than the image name itself
                    mask.name = get_unique_name(mask.name, mask_names)
                    mask_names.append(mask.name)

            created_layer_names.append(new_layer.name)
            created_ids.append(len(yp.layers)-1)

        # Duplicate data of newly created layers
        created_layers = [l for l in yp.layers if l.name in created_layer_names]
        layer_common.duplicate_layer_nodes_and_images(
            tree, created_layers, packed_duplicate = self.packed_duplicate or self.duplicate_blank,
            duplicate_blank = self.duplicate_blank,
            ondisk_duplicate = self.ondisk_duplicate or self.duplicate_blank,
            set_new_decal_position = self.set_new_decal_position
        )

        # Move duplicated layer to current index
        for i, idx in enumerate(created_ids):
            relevant_id = relevant_ids[i]
            yp.layers.move(idx, relevant_id)

        # Remap parent index
        for lay in yp.layers:
            if lay.name in parent_dict:
                lay.parent_idx = get_layer_index_by_name(yp, parent_dict[lay.name])

        # Remap fcurves
        remap_layer_fcurves(yp, index_dict)

        # Revert back halt update
        yp.halt_update = False

        # Rearrange and reconnect
        reconnect_yp_nodes(tree)
        rearrange_yp_nodes(tree)

        # Refresh active layer
        yp.active_layer_index = yp.active_layer_index

        # Update list items
        ListItem.refresh_list_items(yp)

        print('INFO: Layer', source_layer_name, 'is duplicated in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YCopyLayer(bpy.types.Operator):
    bl_idname = "wm.y_copy_layer"
    bl_label = "Copy Layer"
    bl_description = "Copy Layer"
    bl_options = {'REGISTER', 'UNDO'}

    all_layers : BoolProperty(
        name = 'Copy All Layers',
        description = 'Copy all layers instead of only the active one',
        default = False
    )

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return context.object and group_node and len(group_node.node_tree.yp.layers) > 0

    def execute(self, context):
        node = get_active_ypaint_node()
        yp = node.node_tree.yp
        wmp = context.window_manager.ypprops

        #layer = yp.layers[yp.active_layer_index]
        layer = ListItem.get_active_layer(yp)

        if not layer:
            self.report({'ERROR'}, "Cannot copy a base layer!")
            return {'CANCELLED'}

        wmp.clipboard_tree = node.node_tree.name
        wmp.clipboard_layer = layer.name if not self.all_layers else ''

        return {'FINISHED'}

def copy_layers(yp_source, yp_dest, layer_name='', packed_duplicate=True, paste_blank=False, ondisk_duplicate=False, set_new_decal_position=False, rebake_bakeds=True):
    message = ''

    yp = yp_dest
    tree = yp.id_data
    tree_source = yp_source.id_data

    # Check if the source yp has matching channel order
    matching = True
    if len(yp.channels) != len(yp_source.channels):
        matching = False
    else:
        for i, ch in enumerate(yp.channels):
            ch_source = yp_source.channels[i]
            if ch.name != ch_source.name or ch.type != ch_source.type:
                matching = False
                break

    # Empty layer name meant all layers will be copied
    if layer_name == '':
        # Get datas
        first_copied_index = 0
        layer_names = [l.name for l in yp_source.layers]

    else:

        # Source layer
        layer_source = yp_source.layers.get(layer_name)

        if not layer_source:
            #self.report({'ERROR'}, "Cannot find copied layer! Maybe it was deleted or renamed.")
            #return {'CANCELLED'}
            message = "Cannot find copied layer! Maybe it was deleted or renamed."
            return False, message

        # Check index of copied layer to know the offest
        first_copied_index = get_layer_index_by_name(yp_source, layer_source.name)

        # Get all children
        children, child_ids = get_list_of_all_children_and_child_ids(layer_source)

        # Collect relevant names
        layer_names = [layer_source.name]
        for child in children:
            layer_names.append(child.name)

    # Disable source layers if channel list is not matching 
    ori_layer_enables = {}
    if not matching:
        for lname in layer_names:
            l = yp_source.layers.get(lname)
            ori_layer_enables[lname] = l.enable
            l.enable = False

    # Get parent and index dict
    parent_dict = get_parent_dict(yp)
    index_dict = get_index_dict(yp)

    # Current index
    cur_idx = yp.active_layer_index
    if len(yp.layers) > 0:
        cur_layer = yp.layers[cur_idx]
        cur_parent_idx = cur_layer.parent_idx
    else:
        cur_parent_idx = -1

    # List of newly pasted datas
    pasted_layer_names = []

    # Halt update to prevent needless reconnection
    yp.halt_update = True

    for lname in layer_names:

        ls = yp_source.layers.get(lname)

        # Create new layer
        new_layer = yp.layers.add()
        new_layer.name = get_unique_name(ls.name, yp.layers)

        # Get original source layer again to avoid pointer error after adding new layer
        ls = yp_source.layers.get(lname)

        # Copy layer props
        copy_id_props(ls, new_layer, ['name'])

        if not matching:
            # Clear out layer channel props
            new_layer.channels.clear()
            for mask in new_layer.masks:
                mask.channels.clear()

            for root_ch in yp.channels:

                # New layer channel
                new_ch = new_layer.channels.add()
                new_ch.enable = new_layer.type in {'GROUP', 'BACKGROUND'} # Layer channel default is disabled except for group and background

                # Get matching channel on source yp
                source_idx = -1
                if root_ch.name in yp_source.channels:
                    source_idx = get_channel_index(yp_source.channels.get(root_ch.name))

                # Copy layer channel props
                if source_idx != -1:
                    copy_id_props(ls.channels[source_idx], new_ch)

                for i, mask in enumerate(new_layer.masks):

                    # New mask channel
                    mch = mask.channels.add()
                    mch.enable = True # Mask channel default is enabled

                    # Copy mask channel props
                    if source_idx != -1:
                        copy_id_props(ls.masks[i].channels[source_idx], mch)

            # Reenable new layer
            if ls.name in ori_layer_enables:
                new_layer.enable = ori_layer_enables[ls.name]

        # Duplicate groups
        new_group_node = new_node(tree, new_layer, 'group_node', 'ShaderNodeGroup', new_layer.name)
        new_group_node.node_tree = get_tree(ls)

        # Duplicate group input values
        source_node = tree_source.nodes.get(ls.group_node)
        for inp in new_group_node.inputs:
            source_inp = source_node.inputs.get(inp.name)
            if source_inp: inp.default_value = source_inp.default_value

        pasted_layer_names.append(new_layer.name)

    # Duplicate data of pasted layers
    pasted_layers = [l for l in yp.layers if l.name in pasted_layer_names]
    layer_common.duplicate_layer_nodes_and_images(
        tree, pasted_layers, packed_duplicate = packed_duplicate,
        duplicate_blank = paste_blank,
        ondisk_duplicate = ondisk_duplicate,
        set_new_decal_position = set_new_decal_position
    )

    # Move pasted layer to current index
    for i, lname in enumerate(pasted_layer_names):
        nl = yp.layers.get(lname)
        idx = get_layer_index_by_name(yp, lname)
        yp.layers.move(idx, cur_idx+i)

    for i, lname in enumerate(pasted_layer_names):
        nl = yp.layers.get(lname)

        # Remap parent index
        if i == 0:
            # Set upmost pasted layer to current parent index
            nl.parent_idx = cur_parent_idx
        else:
            if nl.parent_idx != -1:
                nl.parent_idx += cur_idx - first_copied_index
            else:
                nl.parent_idx = cur_parent_idx

        # Refresh io and nodes
        check_all_layer_channel_io_and_nodes(nl)

        reconnect_layer_nodes(nl)
        rearrange_layer_nodes(nl)

    # Remap parents for non pasted layers
    for lay in yp.layers:
        if lay.name in pasted_layer_names: continue
        lay.parent_idx = get_layer_index_by_name(yp, parent_dict[lay.name])

    # Remap fcurves
    remap_layer_fcurves(yp, index_dict)

    # Check uv maps
    check_uv_nodes(yp)

    # Revert back halt update
    yp.halt_update = False

    # Rearrange and reconnect
    check_start_end_root_ch_nodes(tree)
    reconnect_yp_nodes(tree)
    rearrange_yp_nodes(tree)

    # Revert original layer channel enables
    for lname, lenable in ori_layer_enables.items():
        l = yp_source.layers.get(lname)
        if l: l.enable = lenable

    # Rebake baked images
    # NOTE: Blender versions lower than 2.80 don't copy image's bake info, making rebake process useless
    if rebake_bakeds and is_bl_newer_than(2, 80):
        T = time.time()

        # NOTE: Calling rebake function directly is not possible yet due to cyclic file imports
        #pasted_layer = [l for l in yp.layers if l.name in pasted_layer_names]
        #bake_common.rebake_baked_images(yp, specific_layers=pasted_layers)

        pasted_layer_ids = [i for i, l in enumerate(yp.layers) if l.name in pasted_layer_names]
        bpy.ops.wm.y_rebake_specific_layers(layer_ids=str(pasted_layer_ids))

        #self.report({'INFO'}, 'Rebaking pasted layers is done in '+'{:0.2f}'.format(time.time() - T)+' seconds!')
        message = 'Rebaking pasted layers is done in '+'{:0.2f}'.format(time.time() - T)+' seconds!'

        # TODO: Refactor common functions for adding new data (add_new_layer, add_new_mask, etc) to avoid cyclic imports

    # Refresh active layer
    yp.active_layer_index = yp.active_layer_index

    # Update list items
    ListItem.refresh_list_items(yp)

    return True, message

def remove_temporary_trees():
    for ng in bpy.data.node_groups:
        if ng.name.startswith(TEMP_TREE_PREFIX):
            remove_all_nodes_from_tree(ng)
            remove_datablock(bpy.data.node_groups, ng)

class YPasteLayer(bpy.types.Operator):
    bl_idname = "wm.y_paste_layer"
    bl_label = "Paste Layer"
    bl_description = "Paste Layer"
    bl_options = {'UNDO'}

    packed_duplicate : BoolProperty(
        name = 'Duplicate Packed Images',
        description = 'Duplicate packed images',
        default = True
    )

    ondisk_duplicate : BoolProperty(
        name = 'Duplicate Images on disk',
        description = 'Duplicate images on disk, this will create copies of images sourced from external files',
        default = False
    )
    
    set_new_decal_position : BoolProperty(
        name = 'Set New Decal Position to Cursor',
        description = 'Position decals at 3D Cursor when duplicating',
        default = False
    )

    rebake_bakeds : BoolProperty(
        name = 'Rebake Baked Images',
        description = 'Rebake baked images',
        default = True
    )

    paste_blank : BoolProperty(
        name = 'Make Pasted Images blank',
        description = 'Make pasted images blank',
        default = False
    )

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return context.object and group_node

    @classmethod
    def description(self, context, properties):
        return get_operator_description(self)

    def invoke(self, context, event):
        group_node = get_active_ypaint_node()
        yp = group_node.node_tree.yp

        wm = context.window_manager
        wmp = wm.ypprops

        self.any_packed_image = False
        self.any_ondisk_image = False
        self.any_decal = False
        self.any_baked = False

        if not self.paste_blank:

            tree_source = bpy.data.node_groups.get(wmp.clipboard_tree)
            if tree_source:
                yp_source = tree_source.yp
                source_layers = []
                if wmp.clipboard_layer == '':
                    source_layers = yp_source.layers
                else:
                    layer = yp_source.layers.get(wmp.clipboard_layer)
                    source_layers.append(layer)

                for layer in source_layers:
                    if not self.any_packed_image: self.any_packed_image = any(get_layer_images(layer, packed_only=True))
                    if not self.any_ondisk_image: self.any_ondisk_image = any(get_layer_images(layer, ondisk_only=True))
                    if not self.any_decal: self.any_decal = Decal.any_decal_inside_layer(layer)

                    # Do not check baked if current yp == yp_source
                    if yp != yp_source:
                        if not self.any_baked: self.any_baked = any(get_layer_images(layer, baked_only=True))

            if self.any_packed_image or self.any_ondisk_image or self.any_decal or self.any_baked:
                if get_user_preferences().skip_property_popups and not event.shift:
                    return self.execute(context)

                return context.window_manager.invoke_props_dialog(self, width=200)

        return self.execute(context)

    def check(self, context):
        return True

    def draw(self, context):
        if self.any_packed_image:
            self.layout.prop(self, 'packed_duplicate')

        if self.any_ondisk_image:
            self.layout.prop(self, 'ondisk_duplicate')

        if self.any_decal:
            self.layout.prop(self, 'set_new_decal_position')

        if self.any_baked and is_bl_newer_than(2, 80):
            self.layout.prop(self, 'rebake_bakeds')

            if self.rebake_bakeds:
                self.layout.label(text='Rebaking can take a while', icon='ERROR')

    def cancel(self, context):
        # Remove temporary material if necessary
        remove_temporary_trees()

    def execute(self, context):
        T = time.time()

        wm = context.window_manager
        node = get_active_ypaint_node()
        tree = node.node_tree
        yp = tree.yp
        wmp = wm.ypprops

        tree_source = bpy.data.node_groups.get(wmp.clipboard_tree)
        if not tree_source:
            self.report({'ERROR'}, "Cannot paste as clipboard source isn't found!")
            return {'CANCELLED'}

        yp_source = tree_source.yp

        if not tree_source:
            self.report({'ERROR'}, "Cannot paste as clipboard source isn't found!")
            return {'CANCELLED'}
        
        status, message = copy_layers(
            yp_source, yp, wmp.clipboard_layer, 
            packed_duplicate = self.packed_duplicate, 
            paste_blank = self.paste_blank,
            ondisk_duplicate = self.ondisk_duplicate, 
            set_new_decal_position = self.set_new_decal_position, 
            rebake_bakeds = self.any_baked and self.rebake_bakeds
        )

        if message != '':
            if not status:
                self.report({'ERROR'}, message)
            else: self.report({'INFO'}, message)

        # Remove temporary material if necessary
        remove_temporary_trees()

        if not status:
            return {'CANCELLED'}

        print('INFO: Layer(s) pasted in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

def update_layer_channel_override_1(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    ch_index = int(m.group(2))
    layer = yp.layers[int(m.group(1))]
    root_ch = yp.channels[ch_index]
    ch = self

    check_override_1_layer_channel_nodes(root_ch, layer, ch)

    # Disable active edit if override is off
    if not ch.override_1:
        ch.halt_update = True
        ch.active_edit_1 = False
        ch.halt_update = False

    check_all_layer_channel_io_and_nodes(layer) #, has_parent=has_parent)
    check_uv_nodes(yp)
    reconnect_layer_nodes(layer)
    rearrange_layer_nodes(layer)

    reconnect_yp_nodes(self.id_data)
    rearrange_yp_nodes(self.id_data)

def update_layer_channel_override(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    ch_index = int(m.group(2))
    layer = yp.layers[int(m.group(1))]
    root_ch = yp.channels[ch_index]
    ch = self

    check_override_layer_channel_nodes(root_ch, layer, ch)

    # Disable active edit if override is off
    if not ch.override:
        ch.halt_update = True
        ch.active_edit = False
        ch.halt_update = False

    check_all_layer_channel_io_and_nodes(layer) #, has_parent=has_parent)
    check_uv_nodes(yp)

    reconnect_layer_nodes(layer)
    rearrange_layer_nodes(layer)

    reconnect_yp_nodes(self.id_data)
    rearrange_yp_nodes(self.id_data)

    ypui = context.window_manager.ypui
    if len(ypui.layer_ui.channels) > ch_index:
        ypui.layer_ui.channels[ch_index].expand_source = ch.override_type not in {'DEFAULT', 'IMAGE', 'VCOL'}

    # Reselect layer so vcol or image will be updated
    yp.active_layer_index = yp.active_layer_index

def update_channel_enable(self, context):
    T = time.time()
    yp = self.id_data.yp
    if yp.halt_update: return
    wm = context.window_manager

    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    ch_index = int(m.group(2))
    layer = yp.layers[int(m.group(1))]
    root_ch = yp.channels[ch_index]
    ch = self

    tree = get_tree(layer)

    # Check layer source just to make sure
    layer_common.check_layer_source(layer, tree)

    if root_ch.special_type == 'HEIGHT' and self.enable:
        update_layer_images_interpolation(layer, 'Cubic') #, from_interpolation='Linear')

    # Check uv maps
    check_uv_nodes(yp)

    # Update all layer channels if current channel is a height channel since it can affect normal channel
    normal_ch, height_ch = get_layer_normal_height_ch_pairs(layer)
    specific_ch = None if ch == height_ch else ch

    # Refresh layer IO
    check_all_layer_channel_io_and_nodes(layer, tree, specific_ch)

    # Check layer modifier trees
    modifier_common.check_layer_modifier_tree(layer)

    # Update alpha channel pair
    color_ch, alpha_ch = get_layer_color_alpha_ch_pairs(layer)
    if ch == color_ch:
        check_all_layer_channel_io_and_nodes(layer, tree, alpha_ch)
    elif ch == alpha_ch:
        check_all_layer_channel_io_and_nodes(layer, tree, color_ch)

    if yp.halt_reconnect: return

    if is_layer_preview_mode_enabled(yp):
        # Refresh preview mode, rearrange and reconnect already done in this event
        yp.preview_mode = yp.preview_mode
    else:

        reconnect_layer_nodes(layer)
        rearrange_layer_nodes(layer)

        check_start_end_root_ch_nodes(self.id_data)
        reconnect_yp_nodes(self.id_data)
        rearrange_yp_nodes(self.id_data)

    # Disable active edit on overrides
    if not ch.enable:
        ch.active_edit = False
        ch.active_edit_1 = False

    # Update list items
    ListItem.refresh_list_items(yp)

    print('INFO: Channel '+ root_ch.name + ' of ' + layer.name + 'is updated in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
    wm.yptimer.time = str(time.time())

def update_normal_map_type(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return
    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    layer = yp.layers[int(m.group(1))]
    root_ch = yp.channels[int(m.group(2))]
    tree = get_tree(layer)

    check_all_layer_channel_io_and_nodes(layer, tree, self)
    check_start_end_root_ch_nodes(self.id_data)
    check_uv_nodes(yp)

    check_layer_tree_ios(layer, tree)

    # Check layer modifiers since the group can change
    modifier_common.check_layer_modifier_tree(layer)

    if is_layer_preview_mode_enabled(yp):
        # Set correct active edit
        if self.normal_map_type == 'BUMP_MAP' and self.active_edit_1:
            self.active_edit = True
        elif self.normal_map_type == 'NORMAL_MAP' and self.active_edit:
            self.active_edit_1 = True
    else:
        #if not yp.halt_reconnect:
        reconnect_layer_nodes(layer)
        rearrange_layer_nodes(layer)

        reconnect_yp_nodes(self.id_data)
        rearrange_yp_nodes(self.id_data)

    # Update list items
    ListItem.refresh_list_items(yp)

def update_blend_type(self, context):
    T = time.time()

    wm = context.window_manager
    yp = self.id_data.yp
    if yp.halt_update: return
    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    layer = yp.layers[int(m.group(1))]
    tree = get_tree(layer)
    ch_index = int(m.group(2))
    root_ch = yp.channels[ch_index]

    check_all_layer_channel_io_and_nodes(layer, tree, self)
    check_uv_nodes(yp)

    # Reconnect all layer channels if normal channel is updated
    if root_ch.special_type == 'HEIGHT':
        reconnect_layer_nodes(layer) 
    else: reconnect_layer_nodes(layer, ch_index)

    rearrange_layer_nodes(layer)

    reconnect_yp_nodes(self.id_data)
    rearrange_yp_nodes(self.id_data)

    print('INFO: Layer', layer.name, ' blend type is changed in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
    wm.yptimer.time = str(time.time())

def update_normal_space(self, context):
    yp = self.id_data.yp
    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    layer = yp.layers[int(m.group(1))]
    tree = get_tree(layer)

    normal_proc = tree.nodes.get(self.normal_proc)
    if normal_proc and hasattr(normal_proc, 'space'):
        normal_proc.space = self.normal_space

def update_flip_backface_normal(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return
    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    layer = yp.layers[int(m.group(1))]
    tree = get_tree(layer)

    normal_flip = tree.nodes.get(self.normal_flip)
    if normal_flip: normal_flip.mute = self.invert_backface_normal

def update_write_height(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return
    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    layer = yp.layers[int(m.group(1))]
    ch_index = int(m.group(2))
    root_ch = yp.channels[ch_index]
    ch = self
    tree = get_tree(layer)

    check_all_layer_channel_io_and_nodes(layer, tree, self)
    update_displacement_height_ratio(root_ch)
    check_start_end_root_ch_nodes(self.id_data)
    check_uv_nodes(yp)

    reconnect_layer_nodes(layer) #, ch_index)
    rearrange_layer_nodes(layer)

    reconnect_yp_nodes(self.id_data)
    rearrange_yp_nodes(self.id_data)

def update_use_height_as_normal(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return
    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    layer = yp.layers[int(m.group(1))]
    ch_index = int(m.group(2))
    root_ch = yp.channels[ch_index]
    ch = self
    tree = get_tree(layer)

    check_all_layer_channel_io_and_nodes(layer, tree)
    #update_displacement_height_ratio(root_ch)
    check_start_end_root_ch_nodes(self.id_data)
    check_uv_nodes(yp)

    reconnect_layer_nodes(layer) #, ch_index)
    rearrange_layer_nodes(layer)

    reconnect_yp_nodes(self.id_data)
    rearrange_yp_nodes(self.id_data)

def update_voronoi_feature(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return
    layer = self

    if layer.type != 'VORONOI': return

    source = get_layer_source(layer)
    source.feature = layer.voronoi_feature

    reconnect_layer_nodes(layer)
    rearrange_layer_nodes(layer)

def update_layer_channel_voronoi_feature(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return
    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    layer = yp.layers[int(m.group(1))]
    ch = self

    source = None
    if ch.override_type == 'VORONOI':
        source = get_channel_source(ch)

    if not source:
        tree = get_tree(layer)
        source = tree.nodes.get(ch.cache_voronoi)

    if source:
        source.feature = ch.voronoi_feature

        reconnect_layer_nodes(layer)
        rearrange_layer_nodes(layer)

def update_layer_input(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    # Check layer modifier trees
    m = re.match(r'^yp\.layers\[(\d+)\]\.channels\[(\d+)\]$', self.path_from_id())
    if m: 
        layer = yp.layers[int(m.group(1))]
        modifier_common.check_layer_modifier_tree(layer)

    check_layer_channel_linear_node(self, reconnect=True)

def update_uv_name(self, context):
    obj = context.object
    mat = obj.active_material
    group_tree = self.id_data
    yp = group_tree.yp
    if yp.halt_update: return

    ypui = context.window_manager.ypui
    layer = self
    active_layer = yp.layers[yp.active_layer_index]
    tree = get_tree(layer)
    if not tree: return

    nodes = tree.nodes

    # Use first uv if temp uv or empty is selected
    if layer.uv_name in {TEMP_UV, ''}:
        if len(yp.uvs) > 0:
            for uv in yp.uvs:
                layer.uv_name = uv.name
                break

    # Update uv layer
    if obj.type == 'MESH' and not any([m for m in layer.masks if m.active_edit]) and layer == active_layer:

        if layer.segment_name != '':
            refresh_temp_uv(obj, layer)
        else:
            uv_layers = get_uv_layers(obj)
            uv_layers.active = uv_layers.get(layer.uv_name)

            if is_layer_vdm(layer):
                uv_layers.active.active_render = True

        # Check for other objects with same material
        check_uvmap_on_other_objects_with_same_mat(mat, layer.uv_name)

    # Update global uv
    check_uv_nodes(yp)

    # Update uv neighbor
    smooth_bump_ch = get_smooth_bump_channel(layer)
    if smooth_bump_ch and smooth_bump_ch.enable and (smooth_bump_ch.normal_map_type in {'BUMP_MAP', 'BUMP_NORMAL_MAP'} or smooth_bump_ch.enable_transition_bump):
        uv_neighbor = replace_new_node(
            tree, layer, 'uv_neighbor', 'ShaderNodeGroup', 'Neighbor UV', 
            lib.get_neighbor_uv_tree_name(layer.texcoord_type, entity=layer), 
            return_status=False, hard_replace=True
        )
        set_uv_neighbor_resolution(layer, uv_neighbor)
        if smooth_bump_ch.override and smooth_bump_ch.override_type != 'DEFAULT':
            uv_neighbor = replace_new_node(
                tree, smooth_bump_ch, 'uv_neighbor', 'ShaderNodeGroup', 'Neighbor UV', 
                lib.get_neighbor_uv_tree_name(layer.texcoord_type, entity=layer), 
                return_status=False, hard_replace=True
            )
            set_uv_neighbor_resolution(smooth_bump_ch, uv_neighbor)

        # Update neighbor uv if mask bump is active
        for i, mask in enumerate(layer.masks):
            check_mask_uv_neighbor(tree, layer, mask, i)

    # Update normal process uv
    normal_ch = get_height_channel(layer)
    if normal_ch:
        normal_proc = nodes.get(normal_ch.normal_proc)
        if hasattr(normal_proc, 'uv_map'):
            normal_proc.uv_map = layer.uv_name

    # Update layer tree inputs
    check_layer_tree_ios(layer, tree)

    #if yp_dirty or layer_dirty: #and not yp.halt_reconnect:
    reconnect_layer_nodes(layer)
    rearrange_layer_nodes(layer)

    # Update layer tree inputs
    #if yp_dirty:
    reconnect_yp_nodes(group_tree)
    rearrange_yp_nodes(group_tree)

def update_projection_blend(self, context):
    layer_common.check_layer_projection_blends(self)

def update_texcoord_type(self, context):
    yp = self.id_data.yp
    layer = self
    tree = get_tree(layer)

    if yp.halt_update: return

    # Update global uv
    check_uv_nodes(yp)

    # Update uv neighbor
    smooth_bump_ch = get_smooth_bump_channel(layer)
    if smooth_bump_ch and smooth_bump_ch.enable and (smooth_bump_ch.normal_map_type in {'BUMP_MAP', 'BUMP_NORMAL_MAP'} or smooth_bump_ch.enable_transition_bump):
        uv_neighbor = replace_new_node(
            tree, layer, 'uv_neighbor', 'ShaderNodeGroup', 'Neighbor UV', 
            lib.get_neighbor_uv_tree_name(layer.texcoord_type, entity=layer), hard_replace=True
        )
        set_uv_neighbor_resolution(layer, uv_neighbor)
        if smooth_bump_ch.override and smooth_bump_ch.override_type != 'DEFAULT':
            uv_neighbor = replace_new_node(
                tree, smooth_bump_ch, 'uv_neighbor', 'ShaderNodeGroup', 'Neighbor UV', 
                lib.get_neighbor_uv_tree_name(layer.texcoord_type, entity=layer), hard_replace=True
            )
            set_uv_neighbor_resolution(smooth_bump_ch, uv_neighbor)

    # Update layer tree inputs
    #check_layer_tree_ios(layer, tree)
    check_all_layer_channel_io_and_nodes(layer, tree)

    # Check layer projections
    layer_common.check_layer_projections(layer)

    #if not yp.halt_reconnect:
    reconnect_layer_nodes(layer)
    rearrange_layer_nodes(layer)

    # Update layer tree inputs
    #if yp_dirty:
    reconnect_yp_nodes(self.id_data)
    rearrange_yp_nodes(self.id_data)

def update_hemi_space(self, context):
    if self.type != 'HEMI': return

    source = get_layer_source(self)
    #if source and source.node_tree:
    trans = source.node_tree.nodes.get('Vector Transform')
    if trans: trans.convert_from = self.hemi_space

def update_hemi_camera_ray_mask(self, context):
    yp = self.id_data.yp

    tree = get_source_tree(self)
    source = get_layer_source(self)

    if source:

        # Check if source has the inputs, if not reload the node
        if 'Camera Ray Mask' not in source.inputs:
            source = replace_new_node(
                tree, self, 'source', 'ShaderNodeGroup', 'Source', 
                lib.HEMI, force_replace=True
            )
            duplicate_lib_node_tree(source)
            trans = source.node_tree.nodes.get('Vector Transform')
            if trans: trans.convert_from = self.hemi_space

            reconnect_layer_nodes(self)
            rearrange_layer_nodes(self)

        source.inputs['Camera Ray Mask'].default_value = 1.0 if self.hemi_camera_ray_mask else 0.0

def update_layer_edge_detect_method(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return
    layer = self
    tree = get_tree(layer)
    
    source = get_layer_source(layer)
    lib.setup_edge_detect_source(layer, source)

    reconnect_layer_nodes(layer)
    rearrange_layer_nodes(layer)

def update_hemi_use_prev_normal(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return
    layer = self
    tree = get_tree(layer)

    if layer.type == 'EDGE_DETECT':
        source = get_layer_source(layer)
        lib.setup_edge_detect_source(layer, source)

    check_layer_tree_ios(layer, tree)
    check_layer_bump_process(layer, tree)

    reconnect_layer_nodes(layer)
    rearrange_layer_nodes(layer)

    reconnect_yp_nodes(layer.id_data)

def group_trash_update(yp):
    tree = yp.id_data

    # Get trash node
    trash = tree.nodes.get(yp.trash)
    if not trash:
        trash = new_node(tree, yp, 'trash', 'ShaderNodeGroup', 'Trash')
        trash.node_tree = bpy.data.node_groups.new(tree.name + ' Trash', 'ShaderNodeTree')

    ttree = trash.node_tree

    for layer in yp.layers:

        is_hidden = not layer.enable or is_parent_hidden(layer)

        #if layer.enable and layer.trash_group_node != '':
        if not is_hidden and layer.trash_group_node != '':
            tnode = ttree.nodes.get(layer.trash_group_node)

            # Move node back to tree if found
            if tnode:
                node = tree.nodes.new('ShaderNodeGroup')
                node.node_tree = tnode.node_tree
                layer.group_node = node.name

                ttree.nodes.remove(tnode)
                layer.trash_group_node = ''

        #if not layer.enable and layer.trash_group_node == '':
        if is_hidden and layer.trash_group_node == '':

            node = tree.nodes.get(layer.group_node)

            # Move node to trash if found
            if node:
                tnode = ttree.nodes.new('ShaderNodeGroup')
                tnode.node_tree = node.node_tree
                layer.trash_group_node = tnode.name

                tree.nodes.remove(node)

def update_layer_enable(self, context):
    T = time.time()
    yp = self.id_data.yp
    if yp.halt_update: return
    layer = self
    tree = get_tree(layer)

    #group_trash_update(yp)

    height_root_ch = get_root_height_channel(yp)
    if height_root_ch:
        update_displacement_height_ratio(height_root_ch)

    layer_common.check_layer_source(layer, tree)
    check_uv_nodes(yp)
    check_all_layer_channel_io_and_nodes(layer, tree)
    check_start_end_root_ch_nodes(layer.id_data)

    reconnect_layer_nodes(layer)
    rearrange_layer_nodes(layer)

    if is_layer_preview_mode_enabled(yp):
        # Refresh preview mode, rearrange and reconnect already done in this event
        yp.preview_mode = yp.preview_mode
    else:
        #if yp.disable_quick_toggle:
        reconnect_yp_nodes(layer.id_data)
        rearrange_yp_nodes(layer.id_data)

    context.window_manager.yptimer.time = str(time.time())

    print('INFO: Layer', layer.name, 'is updated in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')

def update_layer_name(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return
    if self.type == 'IMAGE' and self.segment_name != '': return

    src = get_layer_source(self)
    change_layer_name(yp, context.object, src, self, yp.layers)

def update_layer_channel_override_vcol_name(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    obj = context.object
    mat = obj.active_material

    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    layer = yp.layers[int(m.group(1))]
    root_ch = yp.channels[int(m.group(2))]
    tree = get_tree(layer)

    source = tree.nodes.get(self.source)
    change_vcol_name(yp, obj, source, self.override_vcol_name)

def update_layer_channel_use_clamp(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    layer = yp.layers[int(m.group(1))]
    root_ch = yp.channels[int(m.group(2))]
    tree = get_tree(layer)

    if root_ch.special_type in {'NORMAL', 'HEIGHT', 'VDISP'}: return

    check_blend_type_nodes(root_ch, layer, self)

def update_divide_rgb_by_alpha(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    check_layer_divider_alpha(self)

    reconnect_layer_nodes(self)
    rearrange_layer_nodes(self)

def update_layer_channel_vdisp_flip_yz(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    m1 = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]$', self.path_from_id())

    if m1:
        layer = yp.layers[int(m1.group(1))]
        root_ch = yp.channels[int(m1.group(2))]
        tree = get_tree(layer)
    else:
        return

    #if self.normal_map_type == 'VECTOR_DISPLACEMENT_MAP' and self.vdisp_enable_flip_yz:
    if root_ch.special_type == 'VDISP' and self.vdisp_enable_flip_yz:
        vdisp_flip_yz = check_new_node(tree, self, 'vdisp_flip_yz', 'ShaderNodeGroup', 'Flip Y/Z')
        vdisp_flip_yz.node_tree = lib.get_node_tree_lib(lib.FLIP_YZ)
    else:
        remove_node(tree, self, 'vdisp_flip_yz')

    reconnect_layer_nodes(layer)
    rearrange_layer_nodes(layer)

def update_image_flip_y(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    layer = check_entity_image_flip_y(self)

    if layer:
        reconnect_layer_nodes(layer)
        rearrange_layer_nodes(layer)

def update_channel_active_edit(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    m = re.match(r'yp\.layers\[(\d+)\]\.channels\[(\d+)\]', self.path_from_id())
    layer_idx = int(m.group(1))
    layer = yp.layers[int(m.group(1))]
    root_ch = yp.channels[int(m.group(2))]
    ch = self
    tree = get_tree(layer)

    # Disable other active edits
    yp.halt_update = True
    if (
        (self.active_edit and self.override and self.override_type != 'DEFAULT') or
        (self.active_edit_1 and self.override_1 and self.override_1_type != 'DEFAULT')
        ):

        for c in layer.channels:
            if c == self: continue
            c.active_edit = False
            c.active_edit_1 = False
            c.prev_active_edit_idx = 0
        for m in layer.masks:
            m.active_edit = False

    else:
        self.active_edit = False

    # Check previous active edit index
    if ch.prev_active_edit_idx == 0 and ch.active_edit_1:
        ch.active_edit = False
        ch.prev_active_edit_idx = 1
    elif ch.prev_active_edit_idx == 1 and ch.active_edit:
        ch.active_edit_1 = False
        ch.prev_active_edit_idx = 0

    yp.halt_update = False

    # Refresh
    yp.active_layer_index = layer_idx

    # Set active entity item
    ListItem.set_active_entity_item(self)

class YLayerChannel(bpy.types.PropertyGroup):
    enable : BoolProperty(
        name = 'Enable Layer Channel',
        description = 'Enable layer channel',
        default = True,
        update = update_channel_enable
    )

    layer_input : EnumProperty(
        name = 'Layer Input',
        description = 'Input for layer channel',
        items = entity_input_items,
        #update = update_layer_input
    ) # Deprecated

    socket_input_name : StringProperty(
        name = 'Socket Input Name',
        description = 'Socket name for layer channel input',
        default = 'Color',
        update = update_layer_input
    )

    socket_input_1_name : StringProperty(
        name = 'Socket Normal Input Name',
        description = 'Socket name for layer normal channel input',
        default = 'Color',
        update = update_layer_input
    )

    swizzle_input_mode : EnumProperty(
        name = 'Swizzle Mode',
        description = 'Swizzle input mode',
        items = swizzle_items,
        default = 'RGB',
        update = update_layer_input
    )

    gamma_space : BoolProperty(
        name = 'Gamma Space',
        description = 'Make sure layer input is in linear space',
        default = False,
        update = update_layer_input
    )

    use_clamp : BoolProperty(
        name = 'Use Clamp',
        description = 'Clamp result to 0..1 range',
        default = False,
        update = update_layer_channel_use_clamp
    )

    normal_map_type : EnumProperty(
        name = 'Normal Map Type',
        items = layer_common.get_normal_map_type_items,
        #default = 'BUMP_MAP',
        update = update_normal_map_type
    )

    blend_type : EnumProperty(
        name = 'Blend',
        description = 'Blend type of layer channel',
        items = blend_type_items,
        update = update_blend_type
    )

    height_blend_type : EnumProperty(
        name = 'Height Blend Type',
        description = 'Blend type of layer height channel',
        items = height_blend_type_items,
        update = update_blend_type
    )

    normal_blend_type : EnumProperty(
        name = 'Normal Blend Type',
        description = 'Blend type of layer normal channel',
        items = normal_blend_type_items,
        default = 'MIX',
        update = update_blend_type
    )

    normal_space : EnumProperty(
        name = 'Normal Space',
        description = 'Space of the normal map',
        items = normal_space_items,
        default = 'TANGENT',
        update = update_normal_space
    )

    intensity_value : FloatProperty(
        name = 'Layer Channel Opacity', 
        description = 'Layer channel opacity',
        default=1.0, min=0.0, max=1.0, subtype='FACTOR', precision=3
    )

    unpair_alpha : BoolProperty(
        name = 'Unpair with Alpha',
        description = 'Unpair with alpha channel (useful for using Transition Ramp/AO with transparent holes)',
        default = False,
        update = update_channel_enable
    )
            
    # Modifiers
    modifiers : CollectionProperty(type=Modifier.YPaintModifier)
    modifiers_1 : CollectionProperty(type=NormalMapModifier.YNormalMapModifier)

    # Override source
    override : BoolProperty(
        name = 'Enable Override',
        description = 'Use override value rather than layer value for this channel',
        default = False,
        update = update_layer_channel_override
    )

    override_type : EnumProperty(
        items = channel_override_type_items,
        default = 'DEFAULT',
        update = update_layer_channel_override
    )

    override_color : FloatVectorProperty(
        name = 'Override Color',
        description = 'Override color value for this channel',
        subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.5, 0.5, 0.5)
    )

    override_value : FloatProperty(
        name = 'Override Value',
        description = 'Override value for this channel',
        min=0.0, max=1.0, subtype='FACTOR', default=1.0
	)

    override_vcol_name : StringProperty(
        name = get_vertex_color_label()+' Name',
        description = 'Channel override '+get_vertex_color_label(00)+' name',
        default = '',
        update = update_layer_channel_override_vcol_name
    )

    # Specific for voronoi
    voronoi_feature : EnumProperty(
        name = 'Voronoi Feature',
        description = 'The voronoi feature that will be used for compute',
        items = voronoi_feature_items,
        default = 'F1',
        update = update_layer_channel_voronoi_feature
    )

    # Extra override needed when bump and normal are used at the same time
    override_1 : BoolProperty(
        name = 'Enable Override (Normal Map Channel)',
        description = 'Use override value rather than layer value for normal map of this channel',
        default = False,
        update = update_layer_channel_override_1
    )

    override_1_type : EnumProperty(
        items = channel_override_1_type_items,
        default = 'DEFAULT',
        update = update_layer_channel_override_1
    )

    override_1_color : FloatVectorProperty(
        name = 'Override Color',
        description = 'Override color value for normal map of this channel',
        subtype = 'COLOR',
        size = 3,
        default=(0.5, 0.5, 1.0), min=0.0, max=1.0
    )

    # Sources
    source : StringProperty(default='')
    source_n : StringProperty(default='')
    source_s : StringProperty(default='')
    source_e : StringProperty(default='')
    source_w : StringProperty(default='')
    source_group : StringProperty(default='')

    # Other source needed when bump and normal are used at the same time
    source_1 : StringProperty(default='')
    #source_1_n : StringProperty(default='')
    #source_1_s : StringProperty(default='')
    #source_1_e : StringProperty(default='')
    #source_1_w : StringProperty(default='')
    #source_1_group : StringProperty(default='')

    # UV
    uv_neighbor : StringProperty(default='')
    #uv_neighbor_1 : StringProperty(default='')

    invert_backface_normal : BoolProperty(default=False, update=update_flip_backface_normal)

    # Node names
    linear : StringProperty(default='')
    linear_1 : StringProperty(default='')
    blend : StringProperty(default='')
    intensity : StringProperty(default='')
    layer_intensity : StringProperty(default='')
    extra_alpha : StringProperty(default='')
    decal_alpha : StringProperty(default='')
    decal_alpha_n : StringProperty(default='')
    decal_alpha_s : StringProperty(default='')
    decal_alpha_e : StringProperty(default='')
    decal_alpha_w : StringProperty(default='')

    # Flip y node
    flip_y : StringProperty(default='')
    vdisp_flip_yz : StringProperty(default='')

    # Swizzle node
    separate_color_channels : StringProperty(default='')

    # Alpha related
    group_alpha_multiply : StringProperty(default='')

    # Height related
    height_proc : StringProperty(default='')
    height_blend : StringProperty(default='')
    bump_distance_ignorer : StringProperty(default='')

    # Vector Displacement related
    vdisp_proc : StringProperty(default='')
    vdisp_blend : StringProperty(default='')
    vdisp_intensity : StringProperty(default='')

    # For pack/unpack height io
    height_group_unpack : StringProperty(default='')
    height_alpha_group_unpack : StringProperty(default='')

    # Normal related
    normal_proc : StringProperty(default='') # For converting bump to normal
    normal_map_proc : StringProperty(default='') # For processing normal map
    #normal_blend : StringProperty(default='')
    normal_flip : StringProperty(default='')
    normal_overlay : StringProperty(default='')

    bump_distance : FloatProperty(
        name = 'Bump Scale', 
        description = 'Amount of displacement.\n(White equals this value, black equals negative of this value)', 
        default=0.05, min=-1.0, max=1.0, precision=3
    )

    bump_midlevel : FloatProperty(
        name = 'Bump Midlevel', 
        description = 'Neutral bump value that causes no bump',
        default=0.5, min=0.0, max=1.0, precision=3
    )

    bump_smooth_multiplier : FloatProperty(
        name = 'Smooth Bump Step Multiplier',
        description = 'Multiply the smooth bump step.\n(The default step is based on image resolution or 1000 for generated blender texture)',
        default=1.0, min=0.1, max=10.0, precision=3
    )

    normal_bump_distance : FloatProperty(
        name = 'Bump Height Range for normal', 
        description = 'Bump height range for normal channel.\n(White equals this value, black equals negative of this value)', 
        default=0.00, min=-1.0, max=1.0, precision=3
    )

    write_height : BoolProperty(
        name = 'Write Height',
        description = 'Write height for this layer channel',
        default = True,
        update = update_write_height
    )

    use_height_as_normal : BoolProperty(
        name = 'Use Height as Normal',
        description = 'Use height as normal only. The height won\'t be used for displacement',
        default = False,
        update = update_use_height_as_normal
    )

    normal_write_height : BoolProperty(
        name = 'Write Normal Height',
        description = 'Write height for this normal layer channel',
        default = False,
        update = update_write_height
    )

    normal_strength : FloatProperty(
        name = 'Normal Strength',
        description = 'Normal strength',
        default=1.0, min=0.0, max=100.0, precision=3
    )

    vdisp_strength : FloatProperty(
        name = 'Vector Displacement Strength',
        description = 'Normal strength',
        default=1.0, min=-10.0, max=10.0, precision=3
    )

    vdisp_enable_flip_yz : BoolProperty(
        name = 'Vector Displacement Flip YZ Channel',
        description = 'Flip YZ channel value (Compatibility for blender vector displacement standard)',
        default = True,
        update = update_layer_channel_vdisp_flip_yz
    )

    image_flip_y : BoolProperty(
        name = 'Image Flip G',
        description = "Image Flip G (Use this if you're using normal map created for DirectX application)",
        default = False,
        update = update_image_flip_y
    )

    # For some occasion, modifiers are stored in a tree
    mod_group : StringProperty(default='')
    mod_n : StringProperty(default='')
    mod_s : StringProperty(default='')
    mod_e : StringProperty(default='')
    mod_w : StringProperty(default='')

    # Spread alpha hack nodes
    spread_alpha : StringProperty(default='')

    # Intensity Stuff
    intensity_multiplier : StringProperty(default='')

    # Transition bump related
    enable_transition_bump : BoolProperty(
        name = 'Enable Transition Bump',
        description = 'Enable transition bump',
        default = False,
        update = transition.update_enable_transition_bump
    )

    show_transition_bump : BoolProperty(
        name = 'Toggle Transition Bump',
        description = "Toggle transition Bump (This will affect other channels)", 
        default = False
    )

    transition_bump_value : FloatProperty(
        name = 'Transition Bump Value',
        description = 'Transition bump value',
        default=3.0, min=1.0, max=100.0, precision=3
    )

    transition_bump_second_edge_value : FloatProperty(
        name = 'Second Edge Intensity', 
        description = 'Second Edge intensity value',
        default=1.2, min=1.0, max=100.0, precision=3
    )

    transition_bump_distance : FloatProperty(
        #name='Transition Bump Distance', 
        #description= 'Distance of mask bump', 
        name = 'Transition Bump Height Range', 
        description = 'Transition bump height range.\n(White equals this value, black equals negative of this value)', 
        default=0.05, min=-1.0, max=1.0, precision=3
    )

    transition_bump_chain : IntProperty(
        name = 'Transition bump chain',
        description = 'Number of mask affected by transition bump',
        default=10, min=0, max=10,
        update = transition.update_transition_bump_chain
    )

    transition_bump_flip : BoolProperty(
        name = 'Transition Bump Flip',
        description = 'Transition bump flip',
        default = False,
        update = transition.update_enable_transition_bump
    )

    transition_bump_curved_offset : FloatProperty(
        name = 'Transition Bump Curved Offst',
        description = 'Transition bump curved offset',
        default=0.02, min=0.0, max=0.1,
        update = transition.update_transition_bump_curved_offset
    )

    transition_bump_crease : BoolProperty(
        name = 'Transition Bump Crease',
        description = 'Transition bump crease (only works if flip is inactive)',
        default = False,
        update = transition.update_enable_transition_bump
    )

    transition_bump_crease_factor : FloatProperty(
        name = 'Transition Bump Crease Factor',
        description = 'Transition bump crease factor',
        default=0.33, min=0.0, max=1.0, subtype='FACTOR', precision=3
    )

    transition_bump_crease_power : FloatProperty(
        name = 'Transition Bump Crease Power',
        description = 'Transition Bump Crease Power',
        default=5.0, min=1.0, max=100.0, precision=3
    )

    transition_bump_fac : FloatProperty(
        name = 'Transition Bump Factor',
        description = 'Transition bump factor',
        default=1.0, min=0.0, max=1.0, subtype='FACTOR', precision=3
    )

    transition_bump_second_fac : FloatProperty(
        name = 'Transition Bump Second Factor',
        description = 'Transition bump second factor',
        default=1.0, min=0.0, max=1.0, subtype='FACTOR', precision=3
    )

    transition_bump_falloff : BoolProperty(
        name = 'Transition Bump Falloff',
        default = False,
        update = transition.update_enable_transition_bump
    )

    transition_bump_falloff_type : EnumProperty(
        name = 'Transition Bump Falloff Type',
        items = (
            ('EMULATED_CURVE', 'Emulated Curve', ''),
            ('CURVE', 'Curve', ''),
        ),
        default = 'EMULATED_CURVE',
        update = transition.update_enable_transition_bump
    )

    transition_bump_falloff_emulated_curve_fac : FloatProperty(
        name = 'Transition Bump Falloff Emulated Curve Factor',
        description = 'Transition bump curve emulated curve factor',
        default=1.0, min=-1.0, max=1.0, subtype='FACTOR', precision=3
    )

    tb_bump : StringProperty(default='')
    tb_bump_flip : StringProperty(default='')
    tb_inverse : StringProperty(default='')
    tb_intensity_multiplier : StringProperty(default='')
    tb_distance_flipper : StringProperty(default='')
    tb_delta_calc : StringProperty(default='')
    max_height_calc : StringProperty(default='')

    tb_falloff : StringProperty(default='')
    #tb_falloff_n : StringProperty(default='')
    #tb_falloff_s : StringProperty(default='')
    #tb_falloff_e : StringProperty(default='')
    #tb_falloff_w : StringProperty(default='')

    # Transition ramp related
    enable_transition_ramp : BoolProperty(
        name = 'Enable Transition Ramp',
        description = 'Enable alpha transition ramp', 
        default = False,
        update = transition.update_enable_transition_ramp
    )

    show_transition_ramp : BoolProperty(
        name = 'Toggle Transition Ramp',
        description = "Toggle transition Ramp (Works best if there's transition bump enabled on other channel)", 
        default = False
    )

    transition_ramp_intensity_value : FloatProperty(
        name = 'Channel Intensity Factor', 
        description = 'Channel Intensity Factor',
        default=1.0, min=0.0, max=1.0, subtype='FACTOR', precision=3
    )

    transition_ramp_blend_type : EnumProperty(
        name = 'Transition Ramp Blend Type',
        items = blend_type_items,
        update = transition.update_enable_transition_ramp
    )

    transition_ramp_intensity_unlink : BoolProperty(
        name = 'Unlink Transition Ramp with Channel Intensity', 
        description = 'Unlink Transition Ramp with Channel Intensity', 
        default = False,
        update = transition.update_enable_transition_ramp
    )

    # Transition ramp nodes
    tr_ramp : StringProperty(default='')
    tr_ramp_blend : StringProperty(default='')

    # To save ramp and falloff
    cache_ramp : StringProperty(default='')
    cache_falloff_curve : StringProperty(default='')

    # Override type cache
    cache_brick : StringProperty(default='')
    cache_checker : StringProperty(default='')
    cache_gradient : StringProperty(default='')
    cache_magic : StringProperty(default='')
    cache_musgrave : StringProperty(default='')
    cache_noise : StringProperty(default='')
    cache_gabor : StringProperty(default='')
    cache_voronoi : StringProperty(default='')
    cache_wave : StringProperty(default='')

    cache_image : StringProperty(default='')
    cache_1_image : StringProperty(default='')
    cache_vcol : StringProperty(default='')
    cache_hemi : StringProperty(default='')

    # Transition AO related
    enable_transition_ao : BoolProperty(
        name = 'Enable Transition AO', 
        description = 'Enable alpha transition Ambient Occlusion (Need active transition bump)',
        default = False,
        update = transition.update_enable_transition_ao
    )

    show_transition_ao : BoolProperty(
        name = 'Toggle Transition AO',
        description = "Toggle transition AO (Only works if there's transition bump enabled on other channel)", 
        default = False
    )

    transition_ao_power : FloatProperty(
        name = 'Transition AO Power',
        description = 'Transition AO power',
        min=1.0, max=100.0, default=4.0, precision=3
    )

    transition_ao_intensity : FloatProperty(
        name = 'Transition AO Intensity',
        description = 'Transition AO intensity',
        subtype = 'FACTOR',
        min=0.0, max=1.0, default=0.5, precision=3
    )

    transition_ao_color : FloatVectorProperty(
        name = 'Transition AO Color',
        description = 'Transition AO Color', 
        subtype = 'COLOR',
        size = 3,
        min=0.0, max=1.0, default=(0.0, 0.0, 0.0)
    )

    transition_ao_inside_intensity : FloatProperty(
        name = 'Transition AO Inside Intensity', 
        description = 'Transition AO Inside Intensity',
        subtype = 'FACTOR',
        min=0.0, max=1.0, default=0.0, precision=3
    )

    transition_ao_blend_type : EnumProperty(
        name = 'Transition AO Blend Type',
        items = blend_type_items,
        update = transition.update_enable_transition_ao
    )

    transition_ao_intensity_unlink : BoolProperty(
        name = 'Unlink Transition AO with Channel Intensity', 
        description = 'Unlink Transition AO with Channel Intensity', 
        default = False,
        update = transition.update_transition_ao_intensity_link
    )

    tao : StringProperty(default='')

    active_edit : BoolProperty(
        name = 'Active Custom Data', 
        description = 'Active custom data for Blender\'s paint mode and edit mode, or '+get_addon_title()+'\'s Custom Data preview mode',
        default = False,
        update = update_channel_active_edit
    )

    active_edit_1 : BoolProperty(
        name = 'Active Custom Normal Data', 
        description = 'Active custom normal data for Blender\'s paint mode and edit mode, or '+get_addon_title()+'\'s Custom Data preview mode',
        default = False,
        update = update_channel_active_edit
    )

    prev_active_edit_idx : IntProperty(
        name = 'Previous Active Edit Index',
        description = 'To store previous active edit index',
        default = 0
    )

    # For UI
    expand_bump_settings : BoolProperty(default=False)
    expand_intensity_settings : BoolProperty(default=False)
    expand_content : BoolProperty(default=False)
    expand_transition_bump_settings : BoolProperty(default=False)
    expand_transition_ramp_settings : BoolProperty(default=False)
    expand_transition_ao_settings : BoolProperty(default=False)
    expand_input_settings : BoolProperty(default=False)
    expand_blend_settings : BoolProperty(default=False)
    expand_source : BoolProperty(default=False)
    expand_source_1 : BoolProperty(default=False)

def update_layer_color_chortcut(self, context):
    layer = self
    yp = layer.id_data.yp
    if yp.halt_update: return

    # If color shortcut is active, disable other shortcut
    if layer.type == 'COLOR' and layer.color_shortcut:

        for m in layer.modifiers:
            m.shortcut = False

        for ch in layer.channels:
            for m in ch.modifiers:
                m.shortcut = False

def update_layer_transform(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return
    update_mapping(self)

def update_layer_blur_vector(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    layer = self
    tree = get_tree(layer)

    if layer.enable_blur_vector:
        blur_vector = new_node(tree, layer, 'blur_vector', 'ShaderNodeGroup', 'Blur Vector')
        blur_vector.node_tree = get_node_tree_lib(lib.BLUR_VECTOR)
        blur_vector.inputs[0].default_value = layer.blur_vector_factor
    else:
        remove_node(tree, layer, 'blur_vector')

    check_layer_tree_ios(layer, tree)

    reconnect_layer_nodes(layer)
    rearrange_layer_nodes(layer)

def update_layer_blur_vector_factor(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    layer = self
    tree = get_tree(layer)

    blur_vector = tree.nodes.get(layer.blur_vector)

    if blur_vector:
        blur_vector.inputs[0].default_value = layer.blur_vector_factor

def update_layer_uniform_scale_enabled(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    layer = self
    update_entity_uniform_scale_enabled(layer)

    check_layer_tree_ios(layer)
    reconnect_layer_nodes(layer)
    rearrange_layer_nodes(layer)

def update_layer_edge_detect_radius(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return
    layer = self

    source = get_layer_source(layer)
    if source: source.inputs[0].default_value = self.edge_detect_radius

def update_layer_use_baked(self, context):
    yp = self.id_data.yp
    if yp.halt_update: return

    layer = self
    yp = self.id_data.yp
    tree = get_tree(layer)

    # Update global uv
    check_uv_nodes(yp)

    # Update layer tree inputs
    check_all_layer_channel_io_and_nodes(layer)
    check_start_end_root_ch_nodes(self.id_data)

    # Refresh active image by setting active layer
    if get_layer_index(layer) == yp.active_layer_index:
        yp.active_layer_index = yp.active_layer_index

    reconnect_layer_nodes(layer)
    rearrange_layer_nodes(layer)

    reconnect_yp_nodes(self.id_data)
    rearrange_yp_nodes(self.id_data)

class YLayer(bpy.types.PropertyGroup, Decal.BaseDecal):
    name : StringProperty(
        name = 'Layer Name',
        description = 'Layer name',
        default = '',
        update = update_layer_name
    )

    enable : BoolProperty(
        name = 'Enable Layer',
        description = 'Enable layer',
        default = True,
        update = update_layer_enable
    )

    channels : CollectionProperty(type=YLayerChannel)

    group_node : StringProperty(default='')
    trash_group_node : StringProperty(default='')
    depth_group_node : StringProperty(default='')

    type : EnumProperty(
        name = 'Layer Type',
        items = layer_type_items,
        default = 'IMAGE'
    )

    intensity_value : FloatProperty(
        name = 'Layer Opacity', 
        description = 'Layer opacity',
        default=1.0, min=0.0, max=1.0, subtype='FACTOR', precision=3
    )

    color_shortcut : BoolProperty(
        name = 'Color Shortcut on the list',
        description = 'Display color shortcut on the list',
        default = True,
        update = update_layer_color_chortcut
    )

    texcoord_type : EnumProperty(
        name = 'Layer Coordinate Type',
        description = 'Layer Coordinate Type',
        items = texcoord_type_items,
        default = 'UV',
        update = update_texcoord_type
    )

    projection_blend : FloatProperty(
        name = 'Box Projection Blend',
        description = 'Amount of blend to use between sides',
        default=0.0, min=0.0, max=1.0,
        subtype = 'FACTOR',
        update = update_projection_blend
    )

    # For edge detection
    edge_detect_radius : FloatProperty(
        name = 'Edge Detect Radius',
        description = 'Edge detect radius',
        default=0.05, min=0.0, max=10.0, precision=3,
        update = update_layer_edge_detect_radius
    )

    edge_detect_method : EnumProperty(
        name = 'Edge Detection Method',
        description = 'Edge detection method (Cycles Only)',
        items = (
            ('DOT', 'Dot Product', ''),
            ('CROSS', 'Cross Product', '')
        ),
        default='CROSS',
        update = update_layer_edge_detect_method
    )

    # For AO
    ao_distance : FloatProperty(
        name = 'Ambient Occlusion Distance',
        description = 'Ambient occlusion distance',
        default=1.0, min=0.0, max=10.0
    )

    # Specific for voronoi
    voronoi_feature : EnumProperty(
        name = 'Voronoi Feature',
        description = 'The voronoi feature that will be used for compute',
        items = voronoi_feature_items,
        default = 'F1',
        update = update_voronoi_feature
    )

    original_type : EnumProperty(
        name = 'Original Layer Type',
        items = layer_type_items,
        default = 'IMAGE'
    )

    image_flip_y : BoolProperty(
        name = 'Image Flip G',
        description = "Image Flip G (Use this if you're using normal map created for DirectX application) ",
        default = False,
        update = update_image_flip_y
    )

    divide_rgb_by_alpha : BoolProperty(
        name = 'Divide RGB by Alpha',
        description = "Dividing RGB value by its alpha\nThis can be useful remove dark outline on painted image/"+get_vertex_color_label(00)+"\nWARNING: This is a hack solution so the result might not looks right",
        default = False,
        update = update_divide_rgb_by_alpha
    )

    # Fake lighting related

    hemi_space : EnumProperty(
        name = 'Fake Lighting Space',
        description = 'Fake lighting space',
        items = hemi_space_items,
        default = 'OBJECT',
        update = update_hemi_space
    )

    hemi_vector : FloatVectorProperty(
        name = 'Cache Hemi vector',
        size = 3,
        precision = 3,
        default = (0.0, 0.0, 1.0)
    )

    hemi_camera_ray_mask : BoolProperty(
        name = 'Camera Ray Mask',
        description = "Use Camera Ray value so the back of the mesh won't be affected by fake lighting",
        default = False,
        update = update_hemi_camera_ray_mask
    )

    hemi_use_prev_normal : BoolProperty(
        name = 'Use previous Normal',
        description = 'Take account previous Normal',
        default = False,
        update = update_hemi_use_prev_normal
    )

    bump_process : StringProperty(default='')

    # To detect change of layer image
    image_name : StringProperty(default='')

    # To get segment if using image atlas
    segment_name : StringProperty(default='')
    baked_segment_name : StringProperty(default='')

    uv_name : StringProperty(
        name = 'UV Map',
        description = 'UV Map to use for layer coordinate',
        default = '',
        update = update_uv_name
    )

    baked_uv_name : StringProperty(
        name = 'Baked UV Map',
        description = 'UV Map to use for layer coordinate',
        default = ''
    )

    # Parent index
    parent_idx : IntProperty(default=-1)

    # Transform
    translation : FloatVectorProperty(
        name = 'Translation',
        size = 3,
        precision = 3, 
        default = (0.0, 0.0, 0.0),
        update = update_layer_transform
    )

    rotation : FloatVectorProperty(
        name = 'Rotation',
        subtype = 'AXISANGLE',
        size = 3,
        precision = 3,
        unit = 'ROTATION', 
        default = (0.0, 0.0, 0.0),
        update = update_layer_transform
    )

    scale : FloatVectorProperty(
        name = 'Scale',
        size = 3,
        precision = 3, 
        default = (1.0, 1.0, 1.0),
        update = update_layer_transform,
    )

    enable_blur_vector : BoolProperty(
        name = 'Enable Blur Vector',
        description = "Enable blur vector",
        default = False,
        update = update_layer_blur_vector
    )

    blur_vector_factor : FloatProperty(
        name = 'Blur Vector Factor', 
        description = 'Blur vector factor',
        default=1.0, min=0.0, max=100.0,
        update = update_layer_blur_vector_factor
    )

    use_baked : BoolProperty(
        name = 'Use Baked',
        description = 'Use baked layer image',
        default = False,
        update = update_layer_use_baked
    )

    # Sources
    source : StringProperty(default='')
    source_n : StringProperty(default='')
    source_s : StringProperty(default='')
    source_e : StringProperty(default='')
    source_w : StringProperty(default='')
    source_group : StringProperty(default='')
    baked_source : StringProperty(default='')

    source_temp : StringProperty(default='')

    # Linear node
    linear : StringProperty(default='')

    # Fix nodes
    flip_y : StringProperty(default='')
    divider_alpha : StringProperty(default='')

    # Layer type cache
    cache_brick : StringProperty(default='')
    cache_checker : StringProperty(default='')
    cache_gradient : StringProperty(default='')
    cache_magic : StringProperty(default='')
    cache_musgrave : StringProperty(default='')
    cache_noise : StringProperty(default='')
    cache_gabor : StringProperty(default='')
    cache_voronoi : StringProperty(default='')
    cache_wave : StringProperty(default='')
    cache_color : StringProperty(default='')

    cache_image : StringProperty(default='')
    cache_vcol : StringProperty(default='')
    cache_hemi : StringProperty(default='')

    # UV
    uv_neighbor : StringProperty(default='')
    uv_neighbor_1 : StringProperty(default='')
    uv_map : StringProperty(
        name = 'UV Map',
        description = 'UV Map to use for layer coordinate',
        default = ''
    )
    mapping : StringProperty(default='')
    baked_mapping : StringProperty(default='')
    texcoord : StringProperty(default='')
    blur_vector : StringProperty(default='')

    enable_uniform_scale : BoolProperty(
        name = 'Enable Uniform Scale', 
        description = 'Use the same value for all scale components',
        default = False,
        update = update_layer_uniform_scale_enabled
    )

    uniform_scale_value : FloatProperty(default=1)

    decal_process : StringProperty(default='')

    #need_temp_uv_refresh : BoolProperty(default=False)

    # Other Vectors
    tangent : StringProperty(default='')
    bitangent : StringProperty(default='')
    tangent_flip : StringProperty(default='')
    bitangent_flip : StringProperty(default='')

    # Modifiers
    modifiers : CollectionProperty(type=Modifier.YPaintModifier)
    mod_group : StringProperty(default='') # Deprecated
    mod_group_1 : StringProperty(default='') # Deprecated
    mod_groups : CollectionProperty(type=Modifier.YPaintModifierGroupNode)

    # Mask
    enable_masks : BoolProperty(
        name = 'Enable Layer Masks',
        description = 'Enable layer masks',
        default = True,
        update = Mask.update_enable_layer_masks
    )

    masks : CollectionProperty(type=Mask.YLayerMask)

    # UI related
    expand_content : BoolProperty(default=False)
    expand_vector : BoolProperty(default=False)
    expand_masks : BoolProperty(default=False)
    expand_channels : BoolProperty(default=True)
    expand_source : BoolProperty(default=False)

    expand_subitems : BoolProperty(
        name = 'Expand Subitems',
        description = 'Expand subitems',
        default = False,
        update = ListItem.update_expand_subitems
    )

classes = (
    YRefreshNeighborUV,
    YUseLinearColorSpace,
    YFixMissingSource,
    YNewLayer,
    YNewVDMLayer,
    YNewVcolToOverrideChannel,
    YOpenImageAsLayer,
    YOpenImagesToSingleLayer,
    YOpenImagesFromMaterialToLayer,
    YOpenLayersFromMaterial,
    YOpenImageToReplaceLayer,
    YOpenImageToOverrideChannel,
    YOpenExistingDataToLayer,
    YOpenExistingDataToOverrideChannel,
    YMoveLayer,
    YMoveInOutLayerGroup,
    YMoveInOutLayerGroupMenu,
    YRemoveLayer,
    YRemoveLayerMenu,
    YReplaceLayerType,
    YSetLayerChannelBlendType,
    YSetLayerChannelNormalBlendType,
    YSetLayerChannelInput,
    YReplaceLayerChannelOverride,
    YReplaceLayerChannelOverride1,
    YRemoveLayerChannelOverrideSource,
    YDuplicateLayer,
    YCopyLayer,
    YPasteLayer,
    YLayerChannel,
    YLayer,
)

def register():
    for cls in classes: bpy.utils.register_class(cls)

def unregister():
    for cls in classes: bpy.utils.unregister_class(cls)
