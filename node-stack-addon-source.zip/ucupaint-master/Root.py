import bpy, time, re, bmesh
from bpy.props import *
from bpy.app.handlers import persistent
from .common import *
from .subtree import *
from .node_arrangements import *
from .node_connections import *
from . import channel_common, lib, Modifier, Layer, layer_common, Mask, transition, Bake, BakeTarget, ListItem, BaseOperator, preview_mode, modifier_common
from .input_outputs import *

YP_GROUP_SUFFIX = ' ' + get_addon_title()
YP_GROUP_PREFIX = get_addon_title() + ' '

channel_socket_types = {
    'RGB' : 'RGBA',
    'VALUE' : 'VALUE',
    #'NORMAL' : 'VECTOR', # Deprecated
    'VECTOR' : 'VECTOR',
}

channel_socket_custom_icon_names = {
    'RGB' : 'rgb_channel',
    'VALUE' : 'value_channel',
    #'NORMAL' : 'vector_channel', # Deprecated
    'VECTOR' : 'vector_channel',
}

colorspace_items = (
    ('LINEAR', 'Non-Color Data', ''),
    ('SRGB', 'Color Data', '')
)

def create_new_group_tree(mat, name=None):

    #ypup = bpy.context.user_preferences.addons[__name__].preferences

    # Group name is based on material unless specified
    group_name = name or YP_GROUP_PREFIX + mat.name

    # Create new group tree
    group_tree = bpy.data.node_groups.new(group_name, 'ShaderNodeTree')
    group_tree.yp.is_ypaint_node = True
    group_tree.yp.version = get_current_version_str()
    group_tree.yp.blender_version = get_current_blender_version_str()
    group_tree.yp.enable_baked_outside = get_user_preferences().enable_baked_outside_by_default

    # Create IO nodes
    create_essential_nodes(group_tree, True, True, True)

    # Create info nodes
    create_info_nodes(group_tree)

    return group_tree

class YSelectMaterialPolygons(bpy.types.Operator):
    bl_idname = "wm.y_select_all_material_polygons"
    bl_label = "Select All Material Polygons"
    bl_description = "Select all polygons using this material"
    bl_options = {'REGISTER', 'UNDO'}

    new_uv : BoolProperty(
        name = 'Create New UV',
        description = 'Create new UV rather than using available one',
        default = False
    )

    new_uv_name : StringProperty(
        name = 'New UV Name', 
        description = 'Name of the new UV',
        default = 'UVMap'
    )

    uv_map : StringProperty(
        name = 'Active UV Map', 
        description = "It will create one if other objects don't have it.\nIf empty, it will use the current active uv map for each object",
        default = ''
    )

    set_canvas_to_empty : BoolProperty(
        name = 'Set Image Editor to empty',
        description = "Set image editor & canvas image to empty, so it's easier to see",
        default = True
    )

    uv_map_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    @classmethod
    def poll(cls, context):
        return context.object and context.object.type == 'MESH'

    @classmethod
    def description(self, context, properties):
        return get_operator_description(self)

    def invoke(self, context, event):
        obj = context.object

        # Always set new uv to false to avoid unwanted new uv
        self.new_uv = False
        self.new_uv_name = get_unique_name('UVMap', get_uv_layers(obj))

        node = get_active_ypaint_node()
        if node: yp = node.node_tree.yp
        else: yp = None

        # UV Map collections update
        self.uv_map = get_default_uv_name(obj, yp)

        self.uv_map_coll.clear()
        for uv in get_uv_layers(obj):
            if not uv.name.startswith(TEMP_UV):
                self.uv_map_coll.add().name = uv.name
        
        return context.window_manager.invoke_props_dialog(self, width=400)

    def check(self, context):
        return True

    def draw(self, context):
        self.layout.prop(self, "new_uv")
        if self.new_uv:
            self.layout.prop(self, "new_uv_name")
        else:
            self.layout.prop_search(self, "uv_map", self, "uv_map_coll", icon='GROUP_UVS')
        self.layout.prop(self, "set_canvas_to_empty")

    def execute(self, context):
        if (self.new_uv and self.new_uv_name == '') or (not self.new_uv and self.uv_map == ''):
            self.report({'ERROR'}, "UV name cannot be empty!")
            return {'CANCELLED'}

        obj = context.object
        mat = obj.active_material
        uv_name = self.uv_map if not self.new_uv else get_unique_name(self.new_uv_name, get_uv_layers(obj))

        if is_bl_newer_than(2, 80):
            objs = []
            for o in get_scene_objects():
                if o.type != 'MESH': continue
                if is_layer_collection_hidden(o): continue
                if mat.name in o.data.materials:
                    set_object_hide(o, False)
                    o.select_set(True)
                    objs.append(o)
                else: o.select_set(False)
        else:
            objs = [obj]

        # Go to object mode
        if obj.mode != 'OBJECT': bpy.ops.object.mode_set(mode='OBJECT')

        # Select the UV
        for o in objs:
            # Get uv layer
            uv_layers = get_uv_layers(o)
            uvl = uv_layers.get(uv_name)

            # Create one if it didn't exist
            if not uvl:
                uvl = uv_layers.new(name=uv_name)
            uv_layers.active = uvl

        # Go to edit mode
        bpy.ops.object.mode_set(mode='EDIT')

        # Select polygon select mode
        bpy.context.tool_settings.mesh_select_mode = (False, False, True)

        # Unhide all polygons
        bpy.ops.mesh.reveal()

        for o in objs:
            # Find the material index
            mat_index = [i for i, m in enumerate(o.data.materials) if m == mat]
            if mat_index: mat_index = mat_index[0]
            else: continue

            # Select the faces
            me = o.data
            bm = bmesh.from_edit_mesh(me)
            for face in bm.faces:
                if face.material_index == mat_index:
                    face.select = True
                else: face.select = False

            # Required: Flush selection to update verts/edges and notify Blender of changes
            bm.select_flush(True)
            bmesh.update_edit_mesh(me)

        if self.set_canvas_to_empty:
            # Set image editor image to empty
            update_image_editor_image(context, None)
            set_image_paint_canvas(None)

        return {'FINISHED'}

class YRenameUVMaterial(bpy.types.Operator):
    bl_idname = "wm.y_rename_uv_using_the_same_material"
    bl_label = "Rename UV that using same Material"
    bl_description = "Rename UV on objects that used the same material"
    bl_options = {'REGISTER', 'UNDO'}

    uv_map : StringProperty(
        name = 'Target UV Map', 
        description = "Target UV Map that will be renamed", 
        default = ''
    )

    uv_map_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    new_uv_name : StringProperty(
        name = 'New UV Name', 
        description = 'New name for the UV',
        default = 'UVMap'
    )

    @classmethod
    def poll(cls, context):
        return context.object

    def invoke(self, context, event):
        obj = context.object

        # Always set new uv to false to avoid unwanted new uv
        self.new_uv_name = get_unique_name(self.new_uv_name, get_uv_layers(obj))

        node = get_active_ypaint_node()
        if node: yp = node.node_tree.yp
        else: yp = None

        # UV Map collections update
        self.uv_map = get_default_uv_name(obj, yp)

        self.uv_map_coll.clear()
        for uv in get_uv_layers(obj):
            if not uv.name.startswith(TEMP_UV):
                self.uv_map_coll.add().name = uv.name

        return context.window_manager.invoke_props_dialog(self, width=400)

    def check(self, context):
        return True

    def draw(self, context):
        self.layout.prop_search(self, "uv_map", self, "uv_map_coll", icon='GROUP_UVS')
        self.layout.prop(self, "new_uv_name")

    def execute(self, context):
        if self.new_uv_name == '' or self.uv_map == '':
            self.report({'ERROR'}, "Name cannot be empty!")
            return {'CANCELLED'}

        obj = context.object
        mat = get_active_material()

        # Check all uv names available on all objects
        #uvls = []
        #for obj in bpy.data.objects:
        #    if obj.type == 'MESH' and any([m for m in obj.data.materials if mat == m]):
        #        for uvl in get_uv_layers(obj):
        #            if uvl not in uvls:
        #                uvls.append(uvl)

        #new_uv_name = get_unique_name(self.new_uv_name, uvls)

        new_uv_name = self.new_uv_name

        for obj in bpy.data.objects:
            if obj.type == 'MESH' and any([m for m in obj.data.materials if mat == m]):
                uv_layers = get_uv_layers(obj)
                new_uvl = uv_layers.get(new_uv_name)
                if not new_uvl:
                    uvl = uv_layers.get(self.uv_map)
                    if not uvl:
                        uvl = uv_layers.new(name=new_uv_name)
                    else:
                        uvl.name = new_uv_name

        # Dealing with yp
        node = get_active_ypaint_node()
        if node: yp = node.node_tree.yp
        else: yp = None

        if yp:
            # Check baked images uv
            if yp.baked_uv_name == self.uv_map:
                yp.baked_uv_name = new_uv_name

            # Check baked normal channel
            for ch in yp.channels:
                baked_normal = node.node_tree.nodes.get(ch.baked_normal)
                if baked_normal and baked_normal.uv_map == self.uv_map:
                    baked_normal.uv_map = new_uv_name

            # Check layer and masks uv
            for layer in yp.layers:
                if layer.uv_name == self.uv_map:
                    layer.uv_name = new_uv_name

                for mask in layer.masks:
                    if mask.uv_name == self.uv_map:
                        mask.uv_name = new_uv_name

            # Check height channel uv
            height_ch = get_root_height_channel(yp)
            if height_ch and height_ch.main_uv == self.uv_map:
                height_ch.main_uv = new_uv_name

        return {'FINISHED'}

class YQuickYPaintNodeSetup(bpy.types.Operator, BaseOperator.BlendMethodOptions):
    bl_idname = "wm.y_quick_ypaint_node_setup"
    bl_label = "Quick " + get_addon_title() + " Node Setup"
    bl_description = "Quick " + get_addon_title() + " Node Setup"
    bl_options = {'REGISTER', 'UNDO'}

    tree_name : StringProperty(
        name = 'Tree Name'
    )

    set_material_name_from_tree_name : BoolProperty(
        name = 'Also Set Material Name',
        description = 'Also set material name from tree name',
        default = False
    )

    type : EnumProperty(
        name = 'Type',
        items = (
            ('BSDF_PRINCIPLED', 'Principled', ''),
            ('BSDF_DIFFUSE', 'Diffuse', ''),
            ('EMISSION', 'Emission', ''),
        ),
        default = 'BSDF_PRINCIPLED'
    )

    enable_color : BoolProperty(name='Color', default=True)
    enable_alpha : BoolProperty(name='Alpha', default=False)
    enable_ao : BoolProperty(name='Ambient Occlusion', default=False)
    enable_metallic : BoolProperty(name='Metallic', default=True)
    enable_roughness : BoolProperty(name='Roughness', default=True)
    enable_emission : BoolProperty(name='Emission', default=False)
    enable_height : BoolProperty(name='Height', default=True)
    enable_normal : BoolProperty(name='Normal', default=True)
    enable_vector_displacement : BoolProperty(name='Vector Displacement', default=False)

    use_linear_blending : BoolProperty(
        name = 'Use Linear Color Blending',
        description = 'Use more accurate linear color blending (it will behave differently than Photoshop)',
        default = True
    )

    switch_to_material_view : BoolProperty(
        name = 'Switch to Material View',
        description = 'Switch to material view so the node setup is automatically visible',
        default = True
    )

    use_orm_bake_target : BoolProperty(
        name = 'Use ORM Bake Target',
        description = 'Use ORM format as bake target for Ambient Occlusion, Roughness, and Metallic channels',
        default = False
    )

    target_bsdf_name : StringProperty(default='')
    not_on_material_view : BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        return context.object

    @classmethod
    def description(self, context, properties):
        return get_operator_description(self)

    def invoke(self, context, event):
        obj = context.object
        mat = get_active_material()

        valid_bsdf_types = ['BSDF_PRINCIPLED', 'BSDF_DIFFUSE', 'EMISSION']

        # Set the tree name
        mat = get_active_material()
        self.tree_name = YP_GROUP_PREFIX + (mat.name if mat else obj.name)

        # Get target bsdf
        self.target_bsdf_name = ''
        output = get_material_output(mat)
        if output:
            bsdf_node = get_closest_bsdf_backward(output, valid_bsdf_types)
            if bsdf_node:
                self.type = bsdf_node.type
                self.target_bsdf_name = bsdf_node.name

        self.not_on_material_view = is_not_in_material_view()

        if get_user_preferences().skip_property_popups and not event.shift:
            return self.execute(context)

        return context.window_manager.invoke_props_dialog(self)

    def check(self, context):
        return True

    def draw(self, context):
        layout = self.layout.column()
        split_val = 0.35

        row = split_layout(layout, split_val)
        right_aligned_label(row, 'Tree Name:')
        rrow = row.row(align=True)
        rrow.prop(self, 'tree_name', text='')
        rrow.prop(self, 'set_material_name_from_tree_name', text='', icon='MATERIAL_DATA')

        layout.separator()

        row = split_layout(layout, split_val)
        right_aligned_label(row, 'Type:')
        row.prop(self, 'type', text='')

        if self.type != 'EMISSION':
            layout.separator()

            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Channels:')

            rcol = row.column(align=True)
            rcol.prop(self, 'enable_color', toggle=True)

            if self.enable_color:
                rcol.prop(self, 'enable_alpha', toggle=True)

            rcol.prop(self, 'enable_ao', toggle=True)

            rcol.separator()

            if self.type == 'BSDF_PRINCIPLED' and is_bl_newer_than(2, 80):
                rcol.prop(self, 'enable_emission', toggle=True)

            if self.type == 'BSDF_PRINCIPLED':
                rcol.prop(self, 'enable_metallic', toggle=True)

            rcol.prop(self, 'enable_roughness', toggle=True)

            rcol.separator()

            rcol.prop(self, 'enable_height', toggle=True)
            rcol.prop(self, 'enable_normal', toggle=True)
            if is_bl_newer_than(2, 80):
                rcol.prop(self, 'enable_vector_displacement', toggle=True)

            layout.separator()

        else:
            row = split_layout(layout, split_val)
            row.label(text='')
            row.prop(self, 'enable_alpha', text='Enable Alpha')

        if (self.enable_color or self.type == 'EMISSION') and self.enable_alpha:
            if is_bl_newer_than(2, 80) and not is_bl_newer_than(4, 2):
                row = split_layout(layout, split_val)
                right_aligned_label(row, 'Blend Method:')
                row.prop(self, 'blend_method', text='')

                row = split_layout(layout, split_val)
                right_aligned_label(row, 'Shadow Method:')
                row.prop(self, 'shadow_method', text='')

        row = split_layout(layout, split_val)
        row.label(text='')
        row.prop(self, 'use_linear_blending')

        if self.type == 'BSDF_PRINCIPLED' and (self.enable_roughness or self.enable_metallic or self.enable_ao):
            row = split_layout(layout, split_val)
            row.label(text='')
            row.prop(self, 'use_orm_bake_target')

        if self.not_on_material_view:
            row = split_layout(layout, split_val)
            row.label(text='')
            row.prop(self, 'switch_to_material_view')

    def execute(self, context):

        obj = context.object

        if not obj.data or not hasattr(obj.data, 'materials'):
            self.report({'ERROR'}, "Cannot use " + get_addon_title() + " with object '" + obj.name + "'!")
            return {'CANCELLED'}

        mat = get_active_material()

        if not mat:
            material_name = self.tree_name if self.set_material_name_from_tree_name else obj.name
            mat = bpy.data.materials.new(material_name)
            if hasattr(mat, 'use_nodes'): mat.use_nodes = True

            if len(obj.material_slots) > 0:
                matslot = obj.material_slots[obj.active_material_index]
                matslot.material = mat
            else:
                obj.data.materials.append(mat)

            # Remove default nodes
            for n in mat.node_tree.nodes:
                mat.node_tree.nodes.remove(n)
        elif self.set_material_name_from_tree_name:
            mat.name = self.tree_name

        if not mat.node_tree:
            if hasattr(mat, 'use_nodes'): mat.use_nodes = True

            # Remove default nodes
            for n in mat.node_tree.nodes:
                mat.node_tree.nodes.remove(n)

        nodes = mat.node_tree.nodes
        links = mat.node_tree.links

        ao_needed = self.enable_ao and self.type != 'EMISSION'

        main_bsdf = None
        outsoc = None
        ao_mul = None

        # If target bsdf is used as main bsdf
        target_bsdf = nodes.get(self.target_bsdf_name)
        if target_bsdf and target_bsdf.type == self.type:
            main_bsdf = target_bsdf
            for l in main_bsdf.outputs[0].links:
                outsoc = l.to_socket

        # Get active material output
        output = get_material_output(mat)

        loc = Vector((0, 0))

        # Create new group node
        group_tree = create_new_group_tree(mat, self.tree_name)
        node = nodes.new(type='ShaderNodeGroup')
        node.node_tree = group_tree
        node.select = True
        nodes.active = node
        mat.yp.active_ypaint_node = node.name

        # Set bake target default settings
        ypup = get_user_preferences()
        uv_name = get_default_uv_name()
        group_tree.yp.bake_target_global_settings.uv_map = uv_name
        if ypup.default_bake_device != 'DEFAULT':
            group_tree.yp.bake_target_global_settings.bake_device = ypup.default_bake_device

        # BSDF node
        if not main_bsdf:
            if self.type == 'BSDF_PRINCIPLED':
                if not is_bl_newer_than(2, 79):
                    main_bsdf = nodes.new('ShaderNodeGroup')
                    main_bsdf.node_tree = get_node_tree_lib(lib.BL278_BSDF)
                else:
                    main_bsdf = nodes.new('ShaderNodeBsdfPrincipled')
                    if 'Subsurface Radius' in main_bsdf.inputs:
                        main_bsdf.inputs['Subsurface Radius'].default_value = (1.0, 0.2, 0.1) # Use eevee default value
                    if 'Subsurface Color' in main_bsdf.inputs:
                        main_bsdf.inputs['Subsurface Color'].default_value = (0.8, 0.8, 0.8, 1.0) # Use eevee default value
            elif self.type == 'BSDF_DIFFUSE':
                main_bsdf = nodes.new('ShaderNodeBsdfDiffuse')
            elif self.type == 'EMISSION':
                main_bsdf = nodes.new('ShaderNodeEmission')

            if output: 
                loc = output.location.copy()
                loc.x += 200

            node.location = loc.copy()
            loc.x += 200
        else:
            loc = main_bsdf.location.copy()

            # Move away already existing nodes
            for n in mat.node_tree.nodes:

                # Skip nodes with parents
                if n.parent: continue

                if n.location.x < loc.x:
                    if ao_needed: n.location.x -= 400
                    else: n.location.x -= 200

            if ao_needed: loc.x -= 200
            loc.x -= 200

            node.location = loc.copy()
            loc.x += 200

        if ao_needed:
            ao_mul = channel_common.create_ao_node(mat, node)
            loc.x += 200

        main_bsdf.location = loc.copy()
        if main_bsdf.type == 'BSDF_PRINCIPLED' and is_bl_newer_than(2, 80):
            loc.x += 270
        else: loc.x += 200

        if not outsoc:
            # Blender 3.1 has bug which prevent material output changes
            if output and bpy.data.version >= (3, 1, 0) and bpy.data.version < (3, 2, 0):
                outsoc = output.inputs[0]
                output.location = loc.copy()
                loc.x += 200
            else:
                mat_out = nodes.new(type='ShaderNodeOutputMaterial')
                mat_out.is_active_output = True
                outsoc = mat_out.inputs[0]

                mat_out.location = loc.copy()
                loc.x += 200
                
                if output: 
                    output.is_active_output = False

        links.new(main_bsdf.outputs[0], outsoc)

        # Add new channels
        ch_color = None
        ch_alpha = None
        ch_ao = None
        ch_metallic = None
        ch_roughness = None
        ch_emission = None
        ch_height = None
        ch_normal = None
        ch_vdisp = None

        if self.enable_color or self.type == 'EMISSION':
            ch_color = channel_common.create_new_yp_channel(group_tree, 'Color', 'RGB', non_color=False)

        if ch_color and self.enable_alpha:
            ch_alpha = channel_common.create_new_yp_channel(group_tree, 'Alpha', 'VALUE', non_color=True, special_type='ALPHA')
            group_tree.yp.halt_update = True
            ch_alpha.alpha_pair_name = ch_color.name
            group_tree.yp.halt_update = False

        if self.type != 'EMISSION':

            # ORM bake target will be added later
            add_bake_target = not self.use_orm_bake_target or self.type != 'BSDF_PRINCIPLED'

            if self.enable_ao:
                ch_ao = channel_common.create_new_yp_channel(group_tree, 'Ambient Occlusion', 'RGB', non_color=True, add_bake_target=add_bake_target)

            if self.type == 'BSDF_PRINCIPLED' and self.enable_emission:
                ch_emission = channel_common.create_new_yp_channel(group_tree, 'Emission', 'RGB', non_color=False, add_bake_target=add_bake_target)

            if self.type == 'BSDF_PRINCIPLED' and self.enable_metallic:
                ch_metallic = channel_common.create_new_yp_channel(group_tree, 'Metallic', 'VALUE', non_color=True, add_bake_target=add_bake_target)

            if self.enable_roughness:
                ch_roughness = channel_common.create_new_yp_channel(group_tree, 'Roughness', 'VALUE', non_color=True, add_bake_target=add_bake_target)

            if self.enable_height:
                ch_height = channel_common.create_new_yp_channel(group_tree, 'Height', 'VALUE', non_color=True, special_type='HEIGHT')
                channel_common.set_default_height_channel_prop(ch_height)

            if self.enable_normal:
                ch_normal = channel_common.create_new_yp_channel(group_tree, 'Normal', 'VECTOR', special_type='NORMAL')

            if self.enable_vector_displacement:
                ch_vdisp = channel_common.create_new_yp_channel(group_tree, 'Vector Displacement', 'RGB', non_color=True, special_type='VDISP')

        # Update io
        check_all_channel_ios(group_tree.yp, yp_node=node)

        # Update linear blending
        if self.use_linear_blending:
            group_tree.yp.use_linear_blending = self.use_linear_blending

        # HACK: Remap channel pointers, because sometimes pointers are lost at this time
        ch_color = group_tree.yp.channels.get('Color')
        ch_alpha = group_tree.yp.channels.get('Alpha')
        ch_ao = group_tree.yp.channels.get('Ambient Occlusion')
        ch_metallic = group_tree.yp.channels.get('Metallic')
        ch_roughness = group_tree.yp.channels.get('Roughness')
        ch_emission = group_tree.yp.channels.get('Emission')
        ch_height = group_tree.yp.channels.get('Height')
        ch_normal = group_tree.yp.channels.get('Normal')
        ch_vdisp = group_tree.yp.channels.get('Vector Displacement')

        # Add ORM bake target
        if self.use_orm_bake_target and self.type == 'BSDF_PRINCIPLED' and (self.enable_ao or self.enable_roughness or self.enable_metallic):
            bt = group_tree.yp.bake_targets.add()
            bt.name = get_unique_name(group_tree.name.replace(get_addon_title()+' ', '') + ' ORM', bpy.data.images)

            bt.a.default_value = 1.0

            if ch_ao: 
                bt.r.channel_name = ch_ao.name
                bt.r.subchannel_index = '3'
                ch_ao.bake_target_name = bt.name

            if ch_roughness: 
                bt.g.channel_name = ch_roughness.name
                ch_roughness.bake_target_name = bt.name

            if ch_metallic: 
                bt.b.channel_name = ch_metallic.name
                ch_metallic.bake_target_name = bt.name

            if hasattr(context, 'object'):
                bt.uv_map = get_default_uv_name(context.object, group_tree.yp)

            # Set default values
            bt.denoise = False
            bt.fxaa = False

        if ch_color:
            inp = main_bsdf.inputs[0]

            # Check original link
            for l in inp.links:
                links.new(l.from_socket, node.inputs[ch_color.name])

            channel_common.set_input_default_value(node, ch_color, inp.default_value)
            if ch_ao and ao_mul:
                ao_mixcol0, ao_mixcol1, ao_mixout = get_mix_color_indices(ao_mul)
                links.new(node.outputs[ch_color.name], ao_mul.inputs[ao_mixcol0])
                links.new(node.outputs[ch_ao.name], ao_mul.inputs[ao_mixcol1])
                links.new(ao_mul.outputs[ao_mixout], inp)
            else:
                links.new(node.outputs[ch_color.name], inp)

        if ch_alpha:
            default_value = channel_common.do_alpha_setup(mat, node, ch_alpha)
            channel_common.set_material_methods(mat, self.blend_method, self.shadow_method)
            channel_common.set_input_default_value(node, ch_alpha, default_value)

        if ch_ao:
            channel_common.set_input_default_value(node, ch_ao, (1, 1, 1))

        if ch_metallic:
            inp = main_bsdf.inputs['Metallic']

            # Check original link
            for l in inp.links:
                links.new(l.from_socket, node.inputs[ch_metallic.name])

            channel_common.set_input_default_value(node, ch_metallic, inp.default_value)
            links.new(node.outputs[ch_metallic.name], inp)

        if ch_roughness:
            inp = main_bsdf.inputs['Roughness']

            # Check original link
            for l in inp.links:
                links.new(l.from_socket, node.inputs[ch_roughness.name])

            channel_common.set_input_default_value(node, ch_roughness, inp.default_value)
            links.new(node.outputs[ch_roughness.name], inp)

        if ch_emission:
            if is_bl_newer_than(4):
                inp = main_bsdf.inputs['Emission Color']

                # Set strength to one
                sinp = main_bsdf.inputs['Emission Strength']
                sinp.default_value = 1.0
            else: inp = main_bsdf.inputs['Emission']

            # Check original link
            for l in inp.links:
                links.new(l.from_socket, node.inputs[ch_emission.name])

            #channel_common.set_input_default_value(node, ch_emission, inp.default_value)
            channel_common.set_input_default_value(node, ch_emission, (0.0, 0.0, 0.0))
            links.new(node.outputs[ch_emission.name], inp)

        if ch_height:
            if not ch_height.use_height_as_bump or not ch_normal:
                channel_common.do_displacement_node_setup(mat, node, ch_height, is_vector_disp=False)

        if ch_normal:
            inp = main_bsdf.inputs['Normal']

            # Check original link
            for l in inp.links:
                links.new(l.from_socket, node.inputs[ch_normal.name])

            channel_common.set_input_default_value(node, ch_normal)
            links.new(node.outputs[ch_normal.name], inp)

        if ch_vdisp:
            channel_common.do_displacement_node_setup(mat, node, ch_vdisp, is_vector_disp=True)

        # Disable overlay in Blender 2.8
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                if self.not_on_material_view and self.switch_to_material_view:
                    if not is_bl_newer_than(2, 80):
                        area.spaces[0].viewport_shade = 'MATERIAL'
                    else: area.spaces[0].shading.type = 'MATERIAL'

        # Expand channels now is enabled by default if it's the only yp node
        if len([ng for ng in bpy.data.node_groups if hasattr(ng, 'yp') and ng.yp.is_ypaint_node]) == 1:
            context.window_manager.ypui.expand_channels = True

        # Update list items
        ListItem.refresh_list_items(group_tree.yp, repoint_active=True)

        # Update UI
        context.window_manager.ypui.need_update = True

        return {'FINISHED'}

class YNewYPaintNode(bpy.types.Operator):
    bl_idname = "wm.y_add_new_ypaint_node"
    bl_label = "Add new " + get_addon_title() + " Node"
    bl_description = "Add new " + get_addon_title() + " node"
    bl_options = {'REGISTER', 'UNDO'}

    @staticmethod
    def store_mouse_cursor(context, event):
        space = context.space_data
        tree = space.edit_tree

        # convert mouse position to the View2D for later node placement
        if context.region.type == 'WINDOW':
            # convert mouse position to the View2D for later node placement
            space.cursor_location_from_region(event.mouse_region_x, event.mouse_region_y)
        else:
            space.cursor_location = tree.view_center

    @classmethod
    def poll(cls, context):
        space = context.space_data
        # needs active node editor and a tree to add nodes to
        return (
            space.type == 'NODE_EDITOR' and
            space.edit_tree and
            not space.edit_tree.library
        )

    def execute(self, context):
        space = context.space_data
        tree = space.edit_tree
        mat = space.id
        ypui = context.window_manager.ypui

        # select only the new node
        for n in tree.nodes:
            n.select = False

        # Create new group tree
        group_tree = create_new_group_tree(mat)
        yp = group_tree.yp

        # Add new channel
        channel = channel_common.create_new_yp_channel(group_tree, 'Color', 'RGB', non_color=False)

        # Check channel io
        check_all_channel_ios(yp)

        # Create new group node
        node = tree.nodes.new(type='ShaderNodeGroup')
        node.node_tree = group_tree

        # Select new node
        node.select = True
        tree.nodes.active = node

        # Set default input value
        channel_common.set_input_default_value(node, channel)

        # Linear blending is on by default
        yp.use_linear_blending = True

        # Set the location of new node
        node.location = space.cursor_location

        # Set bake target default UV
        uv_name = get_default_uv_name()
        yp.bake_target_global_settings.uv_map = uv_name

        # Expand channels now is enabled by default if it's the only yp node
        if len([ng for ng in bpy.data.node_groups if hasattr(ng, 'yp') and ng.yp.is_ypaint_node]) == 1:
            context.window_manager.ypui.expand_channels = True

        # Update list items
        ListItem.refresh_list_items(yp, repoint_active=True)

        # Update UI
        context.window_manager.ypui.need_update = True

        return {'FINISHED'}

    # Default invoke stores the mouse position to place the node correctly
    # and optionally invokes the transform operator
    def invoke(self, context, event):
        self.store_mouse_cursor(context, event)
        result = self.execute(context)

        if 'FINISHED' in result:
            # Removes the node again if transform is canceled
            bpy.ops.node.translate_attach_remove_on_cancel('INVOKE_DEFAULT')

        return result

def new_channel_items(self, context):
    items = [
        ('VALUE', 'Value', '', lib.get_icon(lib.channel_custom_icon_dict['VALUE']), 0),
        ('RGB', 'RGB', '', lib.get_icon(lib.channel_custom_icon_dict['RGB']), 1),
        ('VECTOR', 'Vector', '', lib.get_icon(lib.channel_custom_icon_dict['VECTOR']), 2)
    ]

    return items

class YPaintNodeInputCollItem(bpy.types.PropertyGroup):
    name : StringProperty(default='')
    node_name : StringProperty(default='')
    input_name : StringProperty(default='')
    input_index : IntProperty(default=0)
    input_type : StringProperty(default='')

def update_new_channel_type(self, context):
    if self.type == 'RGB':
        self.colorspace = 'SRGB'
    else: self.colorspace = 'LINEAR'

def update_connect_to(self, context):
    yp = get_active_ypaint_node().node_tree.yp
    item = self.input_coll.get(self.connect_to)
    if item:
        self.name = get_unique_name(item.input_name, yp.channels)

        if item.input_type == 'RGBA':
            self.type = 'RGB'
        elif item.input_type == 'VALUE':
            self.type = 'VALUE'
        elif item.input_type == 'VECTOR':
            self.type = 'VECTOR'

    # Emission will not use clamp by default
    self.use_clamp = 'Emission' not in self.name

    # Channel called 'Alpha' will enable the alpha flag
    self.use_as_alpha = self.name == 'Alpha' and self.type == 'VALUE'

def refresh_input_coll(self, context, ch_type):
    # Refresh input names
    self.input_coll.clear()
    mat = get_active_material()
    nodes = mat.node_tree.nodes
    yp_node = get_active_ypaint_node()

    for node in nodes:
        if node == yp_node: continue
        for i, inp in enumerate(node.inputs):
            if inp.type not in {'RGBA', 'VALUE', 'VECTOR'}: continue
            if len(inp.links) > 0 : continue
            label = inp.name + ' (' + node.name +')'
            item = self.input_coll.add()
            item.name = label
            item.node_name = node.name
            item.input_name = inp.name
            item.input_index = i
            item.input_type = inp.type

def update_channel_use_height_as_bump(self, context):
    yp = self.id_data.yp
    if yp.halt_reconnect or yp.halt_update:
        return

    node = get_active_ypaint_node()
    mat = get_active_material()

    # Remember the connections
    outp = node.outputs.get(self.name)
    if outp:
        for l in outp.links:
            con = self.ori_to.add()
            con.node = l.to_node.name
            con.socket = l.to_socket.name
            con.socket_index = get_node_input_index(l.to_node, l.to_socket)

    midlevel_outp = node.outputs.get(self.name + io_suffix['MIDLEVEL'])
    if midlevel_outp:
        for l in midlevel_outp.links:
            con = self.ori_midlevel_to.add()
            con.node = l.to_node.name
            con.socket = l.to_socket.name
            con.socket_index = get_node_input_index(l.to_node, l.to_socket)

    max_height_outp = node.outputs.get(self.name + io_suffix['SCALE'])
    if max_height_outp:
        for l in max_height_outp.links:
            con = self.ori_scale_to.add()
            con.node = l.to_node.name
            con.socket = l.to_socket.name
            con.socket_index = get_node_input_index(l.to_node, l.to_socket)

    # Update input and outputs
    check_all_channel_ios(yp, reconnect=True)

    # Reconnect the original connections
    outp = node.outputs.get(self.name)
    if outp:
        for con in self.ori_to:
            to_node = mat.node_tree.nodes.get(con.node)
            if to_node and con.socket in to_node.inputs:
                inp = to_node.inputs[con.socket]
                if len(inp.links) == 0:
                    mat.node_tree.links.new(outp, inp)
        self.ori_to.clear()

    midlevel_outp = node.outputs.get(self.name + io_suffix['MIDLEVEL'])
    if midlevel_outp:
        for con in self.ori_midlevel_to:
            to_node = mat.node_tree.nodes.get(con.node)
            if to_node and con.socket in to_node.inputs:
                inp = to_node.inputs[con.socket]
                if len(inp.links) == 0:
                    mat.node_tree.links.new(midlevel_outp, inp)
        self.ori_midlevel_to.clear()

    max_height_outp = node.outputs.get(self.name + io_suffix['SCALE'])
    if max_height_outp:
        for con in self.ori_scale_to:
            to_node = mat.node_tree.nodes.get(con.node)
            if to_node and con.socket in to_node.inputs:
                inp = to_node.inputs[con.socket]
                if len(inp.links) == 0:
                    mat.node_tree.links.new(max_height_outp, inp)
        self.ori_scale_to.clear()

    # Do displacement setup when use_height_as_bump is disabled since it will create a height socket
    if not self.use_height_as_bump:
        channel_common.do_displacement_node_setup(mat, node, self, is_vector_disp=False)

def update_channel_use_height_normalize(self, context):
    yp = self.id_data.yp
    if yp.halt_reconnect or yp.halt_update:
        return

    node = get_active_ypaint_node()

    # Remember input default values
    midlevel_inp = node.inputs.get(self.name + io_suffix['MIDLEVEL'])
    if midlevel_inp: self.ori_midlevel_value = midlevel_inp.default_value

    max_height_inp = node.inputs.get(self.name + io_suffix['SCALE'])
    if max_height_inp: self.ori_max_height_value = max_height_inp.default_value

    # Update input and outputs
    check_all_channel_ios(yp, reconnect=True)

    # Reconnect outside nodes
    connect_outside_displacement_node(yp, self, node)

class YConnectYPaintChannelAlpha(bpy.types.Operator):
    bl_idname = "wm.y_connect_ypaint_channel_alpha"
    bl_label = "Connect " + get_addon_title() + " Channel Alpha"
    bl_description = "Connect " + get_addon_title() + " channel alpha to other nodes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        channel_common.do_alpha_setup(get_active_material(), get_active_ypaint_node(), context.channel)
        return {'FINISHED'}

class YConnectYPaintChannel(bpy.types.Operator):
    bl_idname = "wm.y_connect_ypaint_channel"
    bl_label = "Connect " + get_addon_title() + " Channel"
    bl_description = "Connect " + get_addon_title() + " channel to other nodes"
    bl_options = {'REGISTER', 'UNDO'}

    disable_unconnected_warning : BoolProperty(
        name = 'Ignore Unconnected Warning',
        description = 'Disable warning popup if this channel is not connected to the main node', 
        default = False
    )

    connect_to : StringProperty(name='Connect To', default='') #, update=update_connect_to)
    input_coll : CollectionProperty(type=YPaintNodeInputCollItem)

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def invoke(self, context, event):
        self.channel = context.channel
        refresh_input_coll(self, context, self.channel.type)
        self.connect_to = ''

        return context.window_manager.invoke_props_dialog(self)

    def check(self, context):
        return True

    def draw(self, context):
        row = split_layout(self.layout, 0.3)

        col = row.column(align=False)
        col.label(text='')
        if not self.disable_unconnected_warning:
            col.label(text='Connect To:')

        col = row.column(align=False)
        col.prop(self, 'disable_unconnected_warning')
        if not self.disable_unconnected_warning:
            col.prop_search(self, "connect_to", self, "input_coll", icon = 'NODETREE', text='')

    def execute(self, context):

        channel = self.channel

        if self.disable_unconnected_warning:
            channel.disable_unconnected_warning = True
            return {'FINISHED'}

        if self.connect_to == '':
            self.report({'ERROR'}, "'Connect To' is cannot be empty!")
            return {'CANCELLED'}

        mat = get_active_material()
        node = get_active_ypaint_node()

        # Connect to socket
        item = self.input_coll.get(self.connect_to)
        inp = None
        if item:
            target_node = mat.node_tree.nodes.get(item.node_name)
            inp = target_node.inputs[item.input_index]
            mat.node_tree.links.new(node.outputs[channel.name], inp)

            if channel.enable_alpha:
                channel_common.do_alpha_setup(mat, node, channel)

        # Set input default value
        if inp and self.channel.type != 'VECTOR': 
            channel_common.set_input_default_value(node, channel, inp.default_value)
        else: channel_common.set_input_default_value(node, channel)

        return {'FINISHED'}

class YAutoSetupNewYPaintChannel(bpy.types.Operator, BaseOperator.BlendMethodOptions):
    bl_idname = "wm.y_auto_setup_new_ypaint_channel"
    bl_label = "Auto setup new " + get_addon_title() + " Channel"
    bl_description = "Auto setup new " + get_addon_title() + " channel"
    bl_options = {'REGISTER', 'UNDO'}

    mode : EnumProperty(
        name = 'Auto Node Setup', 
        description = 'Auto node setup for new channel',
        items = (
            ('ALPHA', 'Alpha', ''),
            ('AO', 'Ambient Occlusion', ''),
            ('EMISSION', 'Emission', ''),
            ('HEIGHT', 'Height', ''),
            ('NORMAL', 'Normal', ''),
            ('VDISP', 'Vector Displacement', ''),
        ),
        default = 'ALPHA'
    )

    channel_pair_name : StringProperty(
        name = 'Channel Pair',
        description = 'Channel pair for the newly created channel',
        default = '',
    )

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def invoke(self, context, event):

        # Check for existing pair
        if self.mode == 'ALPHA':
            node = get_active_ypaint_node()
            yp = node.node_tree.yp

            # Default channel pair
            self.channel_pair_name = ''
            for ch in yp.channels:
                if self.mode == 'ALPHA' and ch.type == 'RGB':
                    self.channel_pair_name = ch.name
                    break

            return context.window_manager.invoke_props_dialog(self)

        return self.execute(context)

    def draw(self, context):
        node = get_active_ypaint_node()
        yp = node.node_tree.yp

        split_val = 0.4
        layout = self.layout.column()

        if self.mode == 'ALPHA' and not is_bl_newer_than(4, 2):
            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Blend Method:')
            row.prop(self, 'blend_method', text='')

            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Shadow Method:')
            row.prop(self, 'shadow_method', text='')

        row = split_layout(layout, split_val)
        right_aligned_label(row, 'Channel Pair:')
        row.prop_search(self, "channel_pair_name", yp, "channels", text='')

    def execute(self, context):

        message = channel_common.auto_setup_active_yp_new_channel(self.mode, self.channel_pair_name, self.blend_method, self.shadow_method)
        if message != '':
            self.report({'ERROR'}, message)
            return {'CANCELLED'}

        return {'FINISHED'}

class YSetChannelSpecialType(bpy.types.Operator, BaseOperator.BlendMethodOptions):
    bl_idname = "wm.y_set_channel_special_type"
    bl_label = "Set "+get_addon_title()+" Channel special type"
    bl_description = "Set "+get_addon_title()+" channel special type"
    bl_options = {'REGISTER', 'UNDO'}

    type : EnumProperty(
        name = 'Type',
        items = (
            ('NONE', 'None', 'Not a special channel'),
            ('ALPHA', 'Alpha', 'Alpha channel (can be paired with color channel)'),
            ('NORMAL', 'Normal', 'Normal channel'),
            ('HEIGHT', 'Height', 'Height channel for bump or displacement (can be paired with normal channel)'),
            ('VDISP', 'Vector Displacement', 'Vector Displacement channel (can be paired with normal channel')
        ),
        default = 'NONE'
    )

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def execute(self, context):
        channel = context.channel
        yp = channel.id_data.yp

        if self.type == channel.special_type:
            return {'CANCELLED'}

        rna_property = channel.bl_rna.properties['special_type']
        enum_item = rna_property.enum_items[self.type]
        ch_label = enum_item.name

        # Check if there's other alpha channel
        existing_special_ch_name = ''
        if self.type != 'NONE':
            for ch in yp.channels:
                if ch == channel: continue
                if ch.special_type == self.type:
                    existing_special_ch_name = ch.name

        if existing_special_ch_name != '':
            self.report({'ERROR'}, ch_label+" channel is already enabled in '"+existing_special_ch_name+"'!")
            return {'CANCELLED'}

        # Disable smooth bump by default
        if self.type == 'HEIGHT' and channel.special_type != 'HEIGHT':
            channel_common.set_default_height_channel_prop(channel)

        channel.special_type = self.type

        check_all_channel_ios(yp)

        return {'FINISHED'}

class YNewYPaintChannel(bpy.types.Operator, BaseOperator.BlendMethodOptions):
    bl_idname = "wm.y_add_new_ypaint_channel"
    bl_label = "Add new " + get_addon_title() + " Channel"
    bl_description = "Add new " + get_addon_title() + " channel"
    bl_options = {'REGISTER', 'UNDO'}

    name : StringProperty(
        name = 'Channel Name', 
        description = 'Name of the channel',
        default = 'Channel'
    )

    type : EnumProperty(
        name = 'Channel Type',
        items = new_channel_items,
        update = update_new_channel_type
    )

    connect_to : StringProperty(name='Connect To', default='', update=update_connect_to)
    input_coll : CollectionProperty(type=YPaintNodeInputCollItem)

    colorspace : EnumProperty(
        name = 'Color Space',
        description = "Non-color won't be converted to linear first before blending",
        items = colorspace_items,
        default = 'LINEAR'
    )

    use_clamp : BoolProperty(
        name = 'Use Clamp', 
        description = 'Use clamp of newly the channel',
        default = True
    )

    set_strength_to_one : BoolProperty(
        name = 'Set Strength to One', 
        description = 'Set socket strength to one',
        default = True
    )

    use_as_alpha : BoolProperty(
        name = 'Use as Alpha Channel',
        description = 'Use new channel as alpha channel',
        default = False
    )

    alpha_pair_name : StringProperty(
        name = 'Alpha Channel Pair',
        description = 'Color channel pair for alpha channel',
        default='',
    )

    disable_unconnected_warning : BoolProperty(
        name = 'Ignore Unconnected Warning',
        description = 'Disable warning popup if this channel is not connected to the main node', 
        default = False
    )

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def invoke(self, context, event):
        group_node = get_active_ypaint_node()
        channels = group_node.node_tree.yp.channels

        # Check if name already available on the list
        self.name = get_unique_name(self.name, channels)

        refresh_input_coll(self, context, self.type)
        self.connect_to = ''

        # Default alpha pair channel
        for ch in channels:
            if ch.type == 'RGB':
                self.alpha_pair_name = ch.name
                break

        return context.window_manager.invoke_props_dialog(self)

    def check(self, context):
        return True

    def draw(self, context):

        mat = get_active_material()
        item = self.input_coll.get(self.connect_to)
        target_node = mat.node_tree.nodes.get(item.node_name) if item else None

        show_alpha_option = False
        show_blend_method_option = False
        show_strength_option = False

        if item and target_node and target_node.type == 'BSDF_PRINCIPLED':

            # Detect principled alpha
            if item.input_name == 'Alpha':
                show_alpha_option = True
                if is_bl_newer_than(2, 80) and not is_bl_newer_than(4, 2):
                    show_blend_method_option = True

            # Blender 4.0 and above has some default weight and strength set to 0.0
            if is_bl_newer_than(4):
                if item.input_name in {'Emission Color', 'Subsurface Scale'}:
                    show_strength_option = True

        split_val = 0.3
        layout = self.layout.column()

        row = split_layout(layout, split_val)
        right_aligned_label(row, 'Name:')
        row.prop(self, 'name', text='')

        row = split_layout(layout, split_val)
        right_aligned_label(row, 'Connect To:')
        row.prop_search(self, "connect_to", self, "input_coll", icon='NODETREE', text='')

        row = split_layout(layout, split_val)
        right_aligned_label(row, 'Type:')
        rrow = row.row(align=True)
        rrow.prop(self, 'type', expand=True)

        if self.type != 'VECTOR':
            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Color Space:')
            row.prop(self, "colorspace", text='')

        if show_blend_method_option:
            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Blend Method:')
            row.prop(self, 'blend_method', text='')

            row = split_layout(layout, split_val)
            right_aligned_label(row, 'Shadow Method:')
            row.prop(self, 'shadow_method', text='')

        if self.type != 'VECTOR':
            row = split_layout(layout, split_val)
            row.label(text='')
            row.prop(self, 'use_clamp')

        if self.connect_to == '':
            row = split_layout(layout, split_val)
            row.label(text='')
            row.prop(self, 'disable_unconnected_warning')

        if show_strength_option:
            row = split_layout(layout, split_val)
            row.label(text='')
            row.prop(self, "set_strength_to_one")

        if show_alpha_option:
            node = get_active_ypaint_node()
            yp = node.node_tree.yp

            row = split_layout(layout, split_val)
            row.label(text='')
            row.prop(self, "use_as_alpha")

            if self.use_as_alpha:
                row = split_layout(layout, split_val)
                right_aligned_label(row, 'Channel Pair:')
                row.prop_search(self, "alpha_pair_name", yp, "channels", text='')

    def execute(self, context):

        T = time.time()

        wm = context.window_manager
        mat = get_active_material()
        node = get_active_ypaint_node()
        group_tree = node.node_tree
        yp = group_tree.yp
        channels = yp.channels

        if len(yp.channels) > 19:
            self.report({'ERROR'}, "Maximum channel possible is 20")
            return {'CANCELLED'}

        # Check if channel with same name is already available
        same_channel = [c for c in channels if c.name == self.name]
        if same_channel:
            self.report({'ERROR'}, "Channel named '" + self.name +"' is already available!")
            return {'CANCELLED'}

        # Create new yp channel
        channel = channel_common.create_new_yp_channel(
            group_tree, self.name, self.type, 
            non_color = self.colorspace == 'LINEAR'
        )

        # Update io
        check_all_channel_ios(yp, yp_node=node)

        # Connect to other inputs
        item = self.input_coll.get(self.connect_to)
        inp = None
        strength_inp = None
        input_name = ''
        set_blend_method = False
        if item:
            target_node = mat.node_tree.nodes.get(item.node_name)
            input_name = item.input_name
            inp = target_node.inputs[item.input_index]
            mat.node_tree.links.new(node.outputs[channel.name], inp)

            # Blender 4.0 and above has some default weight and strength set to 0.0
            if is_bl_newer_than(4) and target_node.type == 'BSDF_PRINCIPLED':
                if item.input_name == 'Emission Color':
                    strength_inp = target_node.inputs.get('Emission Strength')
                elif item.input_name == 'Subsurface Scale':
                    strength_inp = target_node.inputs.get('Subsurface Weight')

            if (is_bl_newer_than(2, 80) and not is_bl_newer_than(4, 2) and
                target_node.type == 'BSDF_PRINCIPLED' and item.input_name == 'Alpha'
                ):
                set_blend_method = True

        # Set input default value
        if inp and self.type != 'VECTOR': 
            channel_common.set_input_default_value(node, channel, inp.default_value)
        else: channel_common.set_input_default_value(node, channel)

        # Set strength input default value
        if strength_inp and self.set_strength_to_one:
            strength_inp.default_value = 1.0
            # Emission will default to use black color
            if input_name == 'Emission Color':
                inp.default_value = (0.0, 0.0, 0.0, 1.0)
                channel_common.set_input_default_value(node, channel, (0.0, 0.0, 0.0, 1.0))

        # Set use clamp
        if channel.use_clamp != self.use_clamp:
            channel.use_clamp = self.use_clamp

        # Set use as alpha
        if self.use_as_alpha and self.type == 'VALUE':
            channel_common.make_channel_as_alpha(mat, node, channel, ch_pair_name=self.alpha_pair_name)

        # Set blend method
        if set_blend_method:
            mat.blend_method = self.blend_method

        # Set warning ignore state
        if self.connect_to == '' and self.disable_unconnected_warning:
            channel.disable_unconnected_warning = True

        # Change active channel
        last_index = len(yp.channels)-1
        group_tree.yp.active_channel_index = last_index

        # Automatically enable new layer channel for group and background layers
        for layer in yp.layers:
            if layer.type in {'GROUP', 'BACKGROUND'}:
                layer.channels[last_index].enable = True

        # Update UI
        wm.ypui.need_update = True
        print('INFO: Channel', channel.name, 'is created in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YMoveYPaintChannel(bpy.types.Operator):
    bl_idname = "wm.y_move_ypaint_channel"
    bl_label = "Move " + get_addon_title() + " Channel"
    bl_description = "Move " + get_addon_title() + " channel"
    bl_options = {'REGISTER', 'UNDO'}

    direction : EnumProperty(
        name = 'Direction',
        items = (
            ('UP', 'Up', ''),
            ('DOWN', 'Down', '')
        ),
        default = 'UP'
    )

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return group_node and len(group_node.node_tree.yp.channels) > 0

    def execute(self, context):
        T = time.time()

        wm = context.window_manager
        group_node = get_active_ypaint_node()
        group_tree = group_node.node_tree
        yp = group_tree.yp
        ypui = context.window_manager.ypui
        #ypup = context.user_preferences.addons[__name__].preferences

        # Get active channel
        index = yp.active_channel_index
        channel = yp.channels[index]
        num_chs = len(yp.channels)

        # Get new index
        if self.direction == 'UP' and index > 0:
            new_index = index-1
        elif self.direction == 'DOWN' and index < num_chs-1:
            new_index = index+1
        else:
            return {'CANCELLED'}

        # Swap collapse UI
        #temp_0 = getattr(ypui, 'show_channel_modifiers_' + str(index))
        #temp_1 = getattr(ypui, 'show_channel_modifiers_' + str(new_index))
        #setattr(ypui, 'show_channel_modifiers_' + str(index), temp_1)
        #setattr(ypui, 'show_channel_modifiers_' + str(new_index), temp_0)

        channel_common.set_channel_index(channel, new_index)

        # Set active index
        yp.active_channel_index = new_index

        # Repoint channel index
        #repoint_channel_index(yp)

        # Update UI
        wm.ypui.need_update = True
        print('INFO: Channel', channel.name, 'is moved in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YRemoveYPaintChannel(bpy.types.Operator):
    bl_idname = "wm.y_remove_ypaint_channel"
    bl_label = "Remove " + get_addon_title() + " Channel"
    bl_description = "Remove " + get_addon_title() + " channel"
    bl_options = {'REGISTER', 'UNDO'}

    also_del_vcol : BoolProperty(
        name = 'Also remove baked '+get_vertex_color_label(00),
        description = 'Also remove baked '+get_vertex_color_label(00),
        default = False
    )

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        return group_node and len(group_node.node_tree.yp.channels) > 0

    def invoke(self, context, event):
        group_node = get_active_ypaint_node()
        group_tree = group_node.node_tree
        yp = group_tree.yp
        # Get active channel
        channel_idx = yp.active_channel_index
        self.channel = yp.channels[channel_idx]
        baked_vcol_node = group_tree.nodes.get(self.channel.baked_vcol)
        self.baked_vcol_name = baked_vcol_node.attribute_name if baked_vcol_node else ''
        if self.baked_vcol_name != '':
            return context.window_manager.invoke_props_dialog(self, width=320)

        self.also_del_vcol = False
        return self.execute(context)

    def draw(self, context):
        if self.baked_vcol_name != '':
            title="Also remove baked "+get_vertex_color_label(00)+" (" + self.baked_vcol_name + ')'
            self.layout.prop(self, 'also_del_vcol', text=title)

    def execute(self, context):
        T = time.time()

        wm = context.window_manager
        mat = get_active_material()
        group_node = get_active_ypaint_node()
        group_tree = group_node.node_tree
        yp = group_tree.yp
        ypui = context.window_manager.ypui
        #ypup = context.user_preferences.addons[__name__].preferences
        nodes = group_tree.nodes
        inputs = get_tree_inputs(group_tree)
        outputs = get_tree_outputs(group_tree)

        # Disable preview mode to avoid error
        ori_preview_mode = yp.preview_mode
        if yp.preview_mode:
            yp.preview_mode = False

        # Get active channel
        channel_idx = yp.active_channel_index
        channel = yp.channels[channel_idx]
        channel_name = channel.name

        # Remove channel fcurves first
        remove_channel_fcurves(channel)
        shift_channel_fcurves(yp, channel_idx, 'UP')
        
        # Delete objects vertex color
        if self.also_del_vcol:
            # Get all objects using material
            objs = []
            for ob in get_scene_objects():
                if ob.type != 'MESH': continue
                if len(ob.data.polygons) == 0: continue
                for i, m in enumerate(ob.data.materials):
                    if m == mat:
                        ob.active_material_index = i
                        if ob not in objs:
                            objs.append(ob)
            for ob in objs:
                vcols = get_vertex_colors(ob)
                if len(vcols) == 0: continue
                vcol = vcols.get(self.baked_vcol_name)
                if vcol:
                    vcols.remove(vcol)
                    
        # Remove props first
        check_all_channel_ios(yp, reconnect=False, remove_props=True)

        # Collapse the UI
        #setattr(ypui, 'show_channel_modifiers_' + str(channel_idx), False)

        # Delete special multiply node for Ambient Occlusion channel
        if channel.name == 'Ambient Occlusion':
            ao_node = mat.node_tree.nodes.get(channel_common.AO_MULTIPLY)
            ao_mixcol0, ao_mixcol1, ao_mixout = get_mix_color_indices(ao_node)
            if ao_node: 
                #ao_node.mute = True
                socket_ins = [l.from_socket for l in ao_node.inputs[ao_mixcol0].links]
                socket_outs = [l.to_socket for l in ao_node.outputs[ao_mixout].links]

                for si in socket_ins:
                    for so in socket_outs:
                        mat.node_tree.links.new(si, so)

                mat.node_tree.nodes.remove(ao_node)

        # Do displacement setup if there's a height channel
        normal_ch, height_ch = get_normal_height_ch_pairs(yp)
        need_displacement_setup = channel == normal_ch

        # Remove channel nodes from layers
        for layer in yp.layers:
            ch = layer.channels[channel_idx]
            ttree = get_tree(layer)

            remove_node(ttree, ch, 'source')
            remove_node(ttree, ch, 'blend')
            remove_node(ttree, ch, 'intensity')
            remove_node(ttree, ch, 'extra_alpha')

            remove_node(ttree, ch, 'disp_blend')

            remove_node(ttree, ch, 'source')
            remove_node(ttree, ch, 'linear')
            remove_node(ttree, ch, 'source_1')
            remove_node(ttree, ch, 'linear_1')
            remove_node(ttree, ch, 'flip_y')
            remove_node(ttree, ch, 'separate_color_channels')

            remove_node(ttree, ch, 'group_alpha_multiply')

            remove_node(ttree, ch, 'normal_process')
            remove_node(ttree, ch, 'normal_flip')
            remove_node(ttree, ch, 'mod_n')
            remove_node(ttree, ch, 'mod_s')
            remove_node(ttree, ch, 'mod_e')
            remove_node(ttree, ch, 'mod_w')
            remove_node(ttree, ch, 'spread_alpha')
            #remove_node(ttree, ch, 'spread_alpha_n')
            #remove_node(ttree, ch, 'spread_alpha_s')
            #remove_node(ttree, ch, 'spread_alpha_e')
            #remove_node(ttree, ch, 'spread_alpha_w')

            remove_node(ttree, ch, 'height_proc')
            remove_node(ttree, ch, 'height_blend')
            remove_node(ttree, ch, 'normal_proc')

            remove_node(ttree, ch, 'height_group_unpack')
            remove_node(ttree, ch, 'height_alpha_group_unpack')

            remove_node(ttree, ch, 'cache_ramp')
            remove_node(ttree, ch, 'cache_falloff_curve')

            remove_node(ttree, ch, 'cache_brick')
            remove_node(ttree, ch, 'cache_checker')
            remove_node(ttree, ch, 'cache_gradient')
            remove_node(ttree, ch, 'cache_magic')
            remove_node(ttree, ch, 'cache_musgrave')
            remove_node(ttree, ch, 'cache_noise')
            remove_node(ttree, ch, 'cache_voronoi')
            remove_node(ttree, ch, 'cache_wave')

            remove_node(ttree, ch, 'cache_image')
            remove_node(ttree, ch, 'cache_1_image')
            remove_node(ttree, ch, 'cache_vcol')
            remove_node(ttree, ch, 'cache_hemi')

            # Remove modifiers
            #if ch.mod_tree:
            if ch.mod_group != '':
                mod_group = ttree.nodes.get(ch.mod_group)
                remove_datablock(bpy.data.node_groups, mod_group.node_tree, user=mod_group, user_prop='node_tree')
                ttree.nodes.remove(mod_group)
            else:
                for mod in ch.modifiers:
                    modifier_common.delete_modifier_nodes(ttree, mod)

            # Remove transition bump and ramp
            if channel.special_type == 'HEIGHT' and ch.enable_transition_bump:
                transition.remove_transition_bump_nodes(layer, ttree, ch, channel_idx)
            elif channel.type in {'RGB', 'VALUE'} and ch.enable_transition_ramp:
                transition.remove_transition_ramp_nodes(ttree, ch)

            # Remove mask channel
            Mask.remove_mask_channel(ttree, layer, channel_idx)

            # Remove layer channel
            layer.channels.remove(channel_idx)

        remove_node(group_tree, channel, 'start_linear')
        remove_node(group_tree, channel, 'end_linear')
        remove_node(group_tree, channel, 'end_start_bump_overlay')
        remove_node(group_tree, channel, 'end_normal_engine_filter')
        remove_node(group_tree, channel, 'end_backface')
        remove_node(group_tree, channel, 'end_max_height')
        remove_node(group_tree, channel, 'end_max_height_tweak')
        remove_node(group_tree, channel, 'end_height_normalize')
        remove_node(group_tree, channel, 'end_bump_process')
        remove_node(group_tree, channel, 'start_normal_filter')
        remove_node(group_tree, channel, 'start_bump_process')
        remove_node(group_tree, channel, 'start_height_process')
        remove_node(group_tree, channel, 'baked')
        remove_node(group_tree, channel, 'baked_vcol')
        remove_node(group_tree, channel, 'baked_normal')
        remove_node(group_tree, channel, 'baked_normal_flip')
        remove_node(group_tree, channel, 'baked_normal_prep')
        remove_node(group_tree, channel, 'baked_disp')
        remove_node(group_tree, channel, 'baked_normal_overlay')
        remove_node(group_tree, channel, 'baked_normal_no_disp')
        remove_node(group_tree, channel, 'baked_combine_xyz')

        for mod in channel.modifiers:
            modifier_common.delete_modifier_nodes(group_tree, mod)

        # Remove channel
        yp.channels.remove(channel_idx)

        # Check consistency of mask multiply nodes
        for t in yp.layers:
            check_mask_mix_nodes(t)

        # Validate bake targets
        BakeTarget.check_channel_bake_target_nodes(yp)

        # Rearrange and reconnect nodes
        check_all_channel_ios(yp)
        #for t in yp.layers:
        #    reconnect_layer_nodes(t)
        #    rearrange_layer_nodes(t)
        #rearrange_yp_nodes(group_tree)

        if need_displacement_setup:
            height_ch = get_root_height_channel(yp)
            if height_ch:
                channel_common.do_displacement_node_setup(mat, group_node, height_ch, is_vector_disp=False)

        # Set new active index
        if (yp.active_channel_index == len(yp.channels) and
            yp.active_channel_index > 0
            ): yp.active_channel_index -= 1

        if ori_preview_mode:
            yp.preview_mode = True

        # Repoint channel index
        #repoint_channel_index(yp)

        # Delete bake target channels
        bt_names = [bt.name for bt in yp.bake_targets]
        for bt_name in bt_names:
            bt = yp.bake_targets.get(bt_name)
            if not bt: continue
            bt_index = [i for i, b in enumerate(yp.bake_targets) if b == bt][0]

            # Delete channel names from bake targets
            something_deleted = False
            for letter in rgba_letters:
                btc = getattr(bt, letter)
                if btc and btc.channel_name == channel_name:
                    btc.channel_name = ''
                    something_deleted = True

            # Check if the entire bake target channels already empty
            if something_deleted:
                theres_something = False
                for letter in rgba_letters:
                    btc = getattr(bt, letter)
                    if btc and btc.channel_name != '':
                        theres_something = True
                        break

                # Delete bake target if its entirely empty
                if not theres_something:
                    yp.bake_targets.remove(bt_index)
                    if len(yp.bake_targets) > 0:
                        yp.active_bake_target_index -= 1

        # Update UI
        wm.ypui.need_update = True
        print('INFO: Channel', channel_name, 'is moved in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
        wm.yptimer.time = str(time.time())

        return {'FINISHED'}

class YAddSimpleUVs(bpy.types.Operator):
    bl_idname = "wm.y_add_simple_uvs"
    bl_label = "Add simple UVs"
    bl_description = "Add Simple UVs"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        obj = context.object
        mesh = obj.data

        # Add simple uvs
        old_mode = obj.mode
        bpy.ops.object.mode_set(mode='TEXTURE_PAINT')
        bpy.ops.paint.add_simple_uvs()
        bpy.ops.object.mode_set(mode=old_mode)

        return {'FINISHED'}

class YSwitchToMaterialView(bpy.types.Operator):
    bl_idname = "wm.y_switch_to_material_view"
    bl_label = "Switch to Material View"
    bl_description = "Switch to use material view to see all the layer effects"
    #bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        space = bpy.context.space_data
        return get_active_ypaint_node() and space.type == 'VIEW_3D'

    def execute(self, context):
        space = bpy.context.space_data

        if not is_bl_newer_than(2, 80):
            space.viewport_shade = 'MATERIAL'
        else: space.shading.type = 'MATERIAL'

        return {'FINISHED'}

class YFixChannelMissmatch(bpy.types.Operator):
    bl_idname = "wm.y_fix_channel_missmatch"
    bl_label = "Fix Channels Mistmatch"
    bl_description = "Fix channels missmatch because of error"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def execute(self, context):
        node = get_active_ypaint_node()
        yp = node.node_tree.yp

        # Make sure halt_update and halt_reconnect off
        if yp.halt_update: yp.halt_update = False
        if yp.halt_reconnect: yp.halt_reconnect = False

        # Reconstruct channels
        channel_common.check_yp_channel_nodes(yp, reconnect=True)

        return {'FINISHED'}

class YFixMissingUV(bpy.types.Operator):
    bl_idname = "wm.y_fix_missing_uv"
    bl_label = "Fix missing UV"
    bl_description = "Fix missing UV"
    bl_options = {'REGISTER', 'UNDO'}

    source_uv_name : StringProperty(name='Missing UV Name', description='Missing UV Name', default='')
    target_uv_name : StringProperty(name='Target UV Name', description='Target UV Name', default='')

    uv_map_coll : CollectionProperty(type=BaseOperator.YPropertyGroup)

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and obj.type == 'MESH'

    def invoke(self, context, event):
        mat = get_active_material()
        obj = context.object
        objs = get_all_objects_with_same_materials(mat)

        # Remapping will proceed if this flag is true
        self.need_remap = True

        # No need to remap if other objects has the uv
        for o in objs:
            uvls = get_uv_layers(o)
            if self.source_uv_name in uvls:
                self.need_remap = False
                return self.execute(context)

        self.target_uv_name = ''

        uv_layers = get_uv_layers(obj)

        # UV Map collections update
        self.uv_map_coll.clear()
        for uv in uv_layers:
            if not uv.name.startswith(TEMP_UV):
                self.uv_map_coll.add().name = uv.name

        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):

        row = split_layout(self.layout, 0.5)

        row.label(text='Remap ' + self.source_uv_name + ' to:')
        row.prop_search(self, "target_uv_name", self, "uv_map_coll", text='', icon='GROUP_UVS')

    def execute(self, context):
        mat = get_active_material()
        #obj = context.object
        objs = get_all_objects_with_same_materials(mat)
        node = get_active_ypaint_node()
        group_tree = node.node_tree
        yp = group_tree.yp

        if self.target_uv_name == '' and self.need_remap:
            self.report({'ERROR'}, "Target UV name is cannot be empty!")
            return {'CANCELLED'}

        target_uv_name = self.target_uv_name if self.need_remap else self.source_uv_name
        
        for o in objs:
            if o.type != 'MESH': continue

            uv_layers = get_uv_layers(o)

            # Get uv layer
            uv_layers = get_uv_layers(o)
            uvl = uv_layers.get(target_uv_name)

            # Create one if it didn't exist
            if not uvl:
                uvl = uv_layers.new(name=target_uv_name)
            uv_layers.active = uvl

        if self.need_remap:
            # Check height channel uv
            height_ch = get_root_height_channel(yp)
            if height_ch and height_ch.main_uv == self.source_uv_name:
                height_ch.main_uv = target_uv_name
                #height_ch.enable_smooth_bump = height_ch.enable_smooth_bump

            # Check baked images uv
            if yp.baked_uv_name == self.source_uv_name:
                yp.baked_uv_name = target_uv_name

            # Check bake target global settings
            if yp.bake_target_global_settings.uv_map == self.source_uv_name:
                yp.bake_target_global_settings = target_uv_name

            # Check baked normal channel
            for ch in yp.channels:
                baked_normal = group_tree.nodes.get(ch.baked_normal)
                if baked_normal and baked_normal.uv_map == self.source_uv_name:
                    baked_normal.uv_map = target_uv_name

            # Check layer and masks uv
            for layer in yp.layers:
                if layer.uv_name == self.source_uv_name:
                    layer.uv_name = target_uv_name

                for mask in layer.masks:
                    if mask.uv_name == self.source_uv_name:
                        mask.uv_name = target_uv_name

        return {'FINISHED'}

def rename_bake_target_tree_names(yp, old_name, new_name, duplicate_data=False):
    tree = yp.id_data
    for bt in yp.bake_targets:
        baked_node = tree.nodes.get(bt.baked_node)
        image = None
        actual_new_name = ''

        # Ignore addon title
        old_name = old_name.replace(get_addon_title()+' ', '')
        new_name = new_name.replace(get_addon_title()+' ', '')

        if bt.data_type == 'IMAGE' and baked_node:
            image = baked_node.image
            if image:
                actual_new_name = image.name.replace(old_name, new_name)
                if actual_new_name != image.name:
                    actual_new_name = get_unique_name(actual_new_name, bpy.data.images)
        # TODO: Dealing with vertex color bake target
        elif not baked_node:
            actual_new_name = bt.name.replace(old_name, new_name)
            if actual_new_name != bt.name:
                actual_new_name = get_unique_name(actual_new_name, yp.bake_targets)
        
        if actual_new_name != '':
            bt.name = actual_new_name
            if image: 
                if duplicate_data:
                    baked_node.image = image.copy()
                    image = baked_node.image
                image.name = actual_new_name

class YRenameYPaintTree(bpy.types.Operator):
    bl_idname = "wm.y_rename_ypaint_tree"
    bl_label = "Rename " + get_addon_title() + " Tree"
    bl_description = "Rename " + get_addon_title() + " Tree"
    bl_options = {'REGISTER', 'UNDO'}
    bl_property = 'name'

    name : StringProperty(name='New Name', description='New Name', default='')
    rename_active_material : BoolProperty(name='Also Rename Active Material', description='Also rename active material', default=False)

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def invoke(self, context, event):
        node = get_active_ypaint_node()
        tree = node.node_tree

        self.name = tree.name
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        row = self.layout.row(align=True)
        row.prop(self, 'name')
        row.prop(self, 'rename_active_material', text='', icon='MATERIAL')

    def execute(self, context):
        node = get_active_ypaint_node()
        tree = node.node_tree
        yp = tree.yp
        old_name = tree.name
        tree.name = self.name
        if self.rename_active_material:
            mat = get_active_material()
            mat.name = self.name

        # Rename bake targets
        rename_bake_target_tree_names(yp, old_name, self.name)
        
        return {'FINISHED'}

class YChangeActiveYPaintNode(bpy.types.Operator):
    bl_idname = "wm.y_change_active_ypaint_node"
    bl_label = "Change Active " + get_addon_title() + " Node"
    bl_description = "Change Active " + get_addon_title() + " Node"
    bl_options = {'REGISTER', 'UNDO'}

    name : StringProperty(name='Node Name', description=get_addon_title() + ' Node Name', default='')

    @classmethod
    def poll(cls, context):
        mat = get_active_material()
        return mat and mat.node_tree

    def execute(self, context):
        mat = get_active_material()

        found_it = False

        for node in mat.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree and node.node_tree.yp.is_ypaint_node and node.name == self.name:
                mat.node_tree.nodes.active = node
                found_it = True
                break

        if not found_it:
            self.report({'ERROR'}, "Node named " + self.name + " is not found!")
            return {'CANCELLED'}

        return {'FINISHED'}

def duplicate_mat(mat, new_name=None):
    # HACK: mat.copy() on Blender 3.0 and newer will make the yp tree used by 3 users (it should be 2 users)
    # To get around this issue, use a temporary tree that will replace the yp trees before doing mat.copy()
    if is_bl_newer_than(3):

        yp_trees = {}
        temp_trees = []

        # Create temporary trees that will replace the yp tree
        for node in mat.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree and node.node_tree.yp.is_ypaint_node:
                yp_trees[node.name] = node.node_tree

                temp_tree = node.node_tree.copy()
                temp_trees.append(temp_tree)

                node.node_tree = temp_tree

        # Duplicate material
        new_mat = mat.copy()

        # Set back yp tree to original nodes
        for node_name, tree in yp_trees.items():
            node = mat.node_tree.nodes.get(node_name)
            node.node_tree = tree

            node = new_mat.node_tree.nodes.get(node_name)
            node.node_tree = tree

        # Remove temporary trees
        for temp_tree in reversed(temp_trees):
            remove_datablock(bpy.data.node_groups, temp_tree)
    else:
        new_mat = mat.copy()

    if new_name:
        new_mat.name = new_name

    return new_mat

class YDuplicateYPNodes(bpy.types.Operator):
    bl_idname = "wm.y_duplicate_yp_nodes"
    bl_label = "Duplicate " + get_addon_title() + " Nodes"
    bl_description = get_addon_title() + " doesn't work with more than one user! Duplicate to make it single user"
    bl_options = {'REGISTER', 'UNDO'}

    new_name : StringProperty(
        name = 'New Name',
        description = 'New name for duplicated tree',
    )

    set_material_name_from_tree_name : BoolProperty(
        name = 'Also Set Material Name',
        description = 'Also set duplicated material name from duplicated tree name',
        default = False
    )

    duplicate_node : BoolProperty(
        name = 'Duplicate this Node',
        description = 'Duplicate this node',
        default = False
    )

    duplicate_material : BoolProperty(
        name = 'Also Duplicate Material',
        description = 'Also Duplicate this node parent materials',
        default = False
    )

    only_active : BoolProperty(
        name = 'Only Duplicate on active object',
        description = 'Only duplicate on active object, rather than all accessible objects using the same material',
        default = True
    )

    ondisk_duplicate : BoolProperty(
        name = 'Duplicate Images on disk',
        description = 'Duplicate images on disk, this will create copies of images sourced from external files',
        default = False
    )

    @classmethod
    def poll(cls, context):
        group_node = get_active_ypaint_node()
        if not group_node: return False

        return True

    @classmethod
    def description(self, context, properties):
        return get_operator_description(self)

    def invoke(self, context, event):
        group_node = get_active_ypaint_node()
        yp = group_node.node_tree.yp

        self.new_name = get_unique_name(group_node.node_tree.name, bpy.data.node_groups)

        self.any_ondisk_image = False

        for layer in yp.layers:
            self.any_ondisk_image = any(get_layer_images(layer, ondisk_only=True))
            if self.any_ondisk_image:
                break

        if get_user_preferences().skip_property_popups and not event.shift:
            return self.execute(context)

        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        row = split_layout(self.layout, 0.35)

        col = row.column()
        col.label(text='New Name:')

        col.label(text='')
        if self.any_ondisk_image:
            col.label(text='')

        col = row.column()
        row = col.row(align=True)
        row.prop(self, 'new_name', text='')
        row.prop(self, 'set_material_name_from_tree_name', text='', icon='MATERIAL_DATA')

        col.prop(self, 'only_active', text='Only Active Object')
        if self.any_ondisk_image:
            col.prop(self, 'ondisk_duplicate')

    def execute(self, context):

        mat = get_active_material()
        if self.only_active:
            objs = [context.object]
        else: objs = get_all_objects_with_same_materials(mat)

        old_name = ''

        if self.duplicate_material:

            # Get new material name
            new_mat_name = self.new_name if self.set_material_name_from_tree_name else get_unique_name(mat.name, bpy.data.materials)

            # Duplicate the material
            dup_mat = duplicate_mat(mat, new_mat_name)
            for obj in objs:
                for i, m in enumerate(obj.data.materials):
                    if m == mat:
                        obj.data.materials[i] = dup_mat

            mat = dup_mat

        if self.duplicate_material or self.duplicate_node:
            # Get to be duplicated trees
            tree_dict = {}
            for node in mat.node_tree.nodes:
                if node.type == 'GROUP' and node.node_tree and node.node_tree.yp.is_ypaint_node and node.node_tree.name not in tree_dict:
                    tree_dict[node.node_tree.name] = node
                    #node.node_tree = node.node_tree.copy()

            # Duplicate the trees
            for tree_name, node in tree_dict.items():
                old_name = tree_name
                tree = bpy.data.node_groups.get(tree_name)
                node.node_tree = tree.copy()
                if self.new_name:
                    node.node_tree.name = self.new_name

        group_node = get_active_ypaint_node()
        tree = group_node.node_tree
        yp = tree.yp

        ori_enable_baked_outside = yp.enable_baked_outside
        if yp.enable_baked_outside:
            yp.enable_baked_outside = False

        # Duplicate all layers
        layer_common.duplicate_layer_nodes_and_images(tree, packed_duplicate=True, ondisk_duplicate=self.ondisk_duplicate)

        # Duplicate uv nodes
        for uv in yp.uvs:
            tangent_process = tree.nodes.get(uv.tangent_process)
            if tangent_process and '_Copy' in tangent_process.node_tree.name: 
                tangent_process.node_tree = tangent_process.node_tree.copy()

        # Delete parallax node because it's too complicated to duplicate
        parallax = tree.nodes.get(PARALLAX)
        if parallax: tree.nodes.remove(parallax)
        baked_parallax = tree.nodes.get(BAKED_PARALLAX)
        if baked_parallax: tree.nodes.remove(baked_parallax)

        # Duplicate single user lib tree
        #for node in ttree.nodes:
        #    if (node.type == 'GROUP' and node.node_tree and 
        #            re.match(r'^.+_Copy\.*\d{0,3}$', node.node_tree.name)):
        #        node.node_tree = node.node_tree.copy()

        #if ypui.make_image_single_user:

        # Duplicate image data and rename bake targets
        old_name = old_name.replace(get_addon_title()+' ', '')
        new_name = self.new_name.replace(get_addon_title()+' ', '')
        rename_bake_target_tree_names(yp, old_name, new_name, duplicate_data=True)

        # Recover possibly deleted parallax
        height_root_ch = get_root_height_channel(yp)
        if height_root_ch:
            height_root_ch.enable_parallax = height_root_ch.enable_parallax

        # Refresh mapping and stuff
        yp.active_layer_index = yp.active_layer_index

        # Recover enable baked outside
        if ori_enable_baked_outside:
            yp.enable_baked_outside = True

        return {'FINISHED'}

def fix_missing_img(name, src, is_mask=False):
    img = bpy.data.images.new(
        name=name, width=1024, height=1024,
        alpha=not is_mask, float_buffer=False
    )
    if is_mask:
        img.generated_color = (1, 1, 1, 1)
    else: img.generated_color = (0, 0, 0, 0)
    src.image = img

class YOptimizeNormalProcess(bpy.types.Operator):
    bl_idname = "wm.y_optimize_normal_process"
    bl_label = "Optimize Normal Process"
    bl_description = "Optimize normal process by not processing normal input when it's not connected"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def execute(self, context):
        node = get_active_ypaint_node()
        group_tree = node.node_tree
        yp = group_tree.yp
        root_normal_ch = get_root_height_channel(yp)
        if not root_normal_ch:
            return {'CANCELLED'}

        check_all_channel_ios(yp, reconnect=True)
        #check_start_end_root_ch_nodes(group_tree, specific_channel=root_normal_ch)

        #reconnect_yp_nodes(group_tree)
        #rearrange_yp_nodes(group_tree)

        return {'FINISHED'}

class YFixMissingData(bpy.types.Operator):
    bl_idname = "wm.y_fix_missing_data"
    bl_label = "Fix Missing Data"
    bl_description = "Fix missing image/"+get_vertex_color_label(00)+" data"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def execute(self, context):
        group_node = get_active_ypaint_node()
        tree = group_node.node_tree
        yp = tree.yp
        obj = context.object
        mat = obj.active_material

        # Fix missing sources
        for i, layer in reversed(list(enumerate(yp.layers))):

            # Delete layer if source is not found
            src = get_layer_source(layer)
            if not src:
                layer_common.remove_layer(yp, i)
                continue

            # Delete mask if mask source is not found
            for j, mask in reversed(list(enumerate(layer.masks))):
                src = get_mask_source(mask)
                if not src:
                    Mask.remove_mask(layer, mask, obj)

            # Use default override if channel source is not found
            for ch in layer.channels:

                src = get_channel_source(ch, layer)
                if ch.override and ch.override_type != 'DEFAULT': 
                    if not src or (ch.override_type == 'IMAGE' and not src.image):
                        ltree = get_tree(layer)
                        remove_node(ltree, ch, 'source')
                        ch.override_type = 'DEFAULT'

                src = get_channel_source_1(ch, layer)
                if ch.override_1 and ch.override_1_type != 'DEFAULT': 
                    if not src or (ch.override_1_type == 'IMAGE' and not src.image):
                        ltree = get_tree(layer)
                        remove_node(ltree, ch, 'source_1')
                        ch.override_1_type = 'DEFAULT'

        if yp.active_layer_index > len(yp.layers):
            yp.active_layer_index = len(yp.layers)-1

        # Fix missing images
        for layer in yp.layers:
            
            if layer.type in {'IMAGE' , 'VCOL'}:
                src = get_layer_source(layer)

                if layer.type == 'IMAGE' and not src.image:
                    fix_missing_img(layer.name, src, False)

            for mask in layer.masks:
                if mask.type in {'IMAGE' , 'VCOL'}:
                    src = get_mask_source(mask)

                    if mask.type == 'IMAGE' and not src.image:
                        fix_missing_img(mask.name, src, True)

        # Get relevant objects
        objs = [obj]
        if mat.users > 1:
            for ob in get_scene_objects():
                if ob.type != 'MESH': continue
                if mat.name in ob.data.materials and ob not in objs:
                    objs.append(ob)

        # Fix missing vcols
        fix_missing_object_vcols(yp, objs)

        # Fix missing uvs
        check_uv_nodes(yp, generate_missings=True)

        # If there's height channel, refresh uv maps to get tangent hacks
        if is_tangent_sign_hacks_needed(yp):
            height_root_ch = get_root_height_channel(yp)
            if height_root_ch:
                for uv in yp.uvs:
                    refresh_tangent_sign_vcol(obj, uv.name)

        # Reconnect layer nodes sometimes are necessary
        for layer in yp.layers:
            reconnect_layer_nodes(layer)
            rearrange_layer_nodes(layer)

        # Update list items
        ListItem.refresh_list_items(yp, repoint_active=True)

        return {'FINISHED'}

class YRemoveMio3Checker(bpy.types.Operator):
    bl_idname = "wm.y_remove_mio3_uv_checker"
    bl_label = "Remove Mio3 UV Checker"
    bl_description = "Remove Mio3 UV checker material"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bpy.context.object

    def execute(self, context):

        # Switch to material view
        space = bpy.context.space_data
        if not is_bl_newer_than(2, 80):
            space.viewport_shade = 'MATERIAL'
        else: space.shading.type = 'MATERIAL'

        # Remove Mio3 modifier
        if hasattr(bpy.ops, 'mio3uv') and hasattr(bpy.ops.mio3uv, 'checker_map_cleanup'):
            bpy.ops.mio3uv.checker_map_cleanup()
        else:
            obj = bpy.context.object
            for mod in reversed(bpy.context.object.modifiers):
                if mod.type == 'NODES' and mod.node_group and mod.node_group.name == 'Mio3MaterialOverride':
                    obj.modifiers.remove(mod)

        return {'FINISHED'}

class YRefreshTangentSignVcol(bpy.types.Operator):
    bl_idname = "wm.y_refresh_tangent_sign_vcol"
    bl_label = "Refresh Tangent Sign "+get_vertex_color_label()+"s"
    bl_description = "Refresh tangent sign "+get_vertex_color_label(00)+"s to make it work in Blender 2.8"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def execute(self, context):
        group_node = get_active_ypaint_node()
        tree = group_node.node_tree
        yp = tree.yp
        obj = context.object

        for uv in yp.uvs:
            refresh_tangent_sign_vcol(obj, uv.name)

        return {'FINISHED'}

class YRemoveYPaintNode(bpy.types.Operator):
    bl_idname = "wm.y_remove_yp_node"
    bl_label = "Remove " + get_addon_title() + " Node"
    bl_description = "Remove " + get_addon_title() + " node, but keep all baked channel image(s)"""
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def is_baked(self, yp=None):
        if not yp:
            group_node = get_active_ypaint_node()
            tree = group_node.node_tree
            yp = tree.yp
        else:
            tree = yp.id_data

        baked_found = False
        for ch in yp.channels:
            bt = yp.bake_targets.get(ch.bake_target_name)
            if bt:
                baked_node = tree.nodes.get(bt.baked_node)
                if baked_node:
                    baked_found = True
                    break

        return baked_found

    def invoke(self, context, event):
        if self.is_baked():
            return self.execute(context)
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.label(text="This " + get_addon_title() + " node setup isn't baked yet!")
        self.layout.label(text="Are you sure want to delete?")

    def execute(self, context):
        mat = get_active_material()
        group_node = get_active_ypaint_node()
        tree = group_node.node_tree
        yp = tree.yp

        if self.is_baked(yp):
            if not yp.use_baked:
                yp.use_baked = True
        else:
            # Search for AO node
            if 'Ambient Occlusion' in yp.channels:
                ao_node = mat.node_tree.nodes.get(channel_common.AO_MULTIPLY)
                ao_mixcol0, ao_mixcol1, ao_mixout = get_mix_color_indices(ao_node)
                if ao_node: 
                    socket_ins = [l.from_socket for l in ao_node.inputs[ao_mixcol0].links]
                    socket_outs = [l.to_socket for l in ao_node.outputs[ao_mixout].links]

                    for si in socket_ins:
                        for so in socket_outs:
                            mat.node_tree.links.new(si, so)

                    mat.node_tree.nodes.remove(ao_node)

        if self.is_baked(yp) and not yp.enable_baked_outside:
            yp.enable_baked_outside = True

        # Bye bye yp node
        simple_remove_node(mat.node_tree, group_node, True, True)

        return {'FINISHED'}

class YCleanYPCaches(bpy.types.Operator):
    bl_idname = "wm.y_clean_yp_caches"
    bl_label = "Clean " + get_addon_title() + " Caches"
    bl_description = "Clean " + get_addon_title() + " caches"""
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return get_active_ypaint_node()

    def execute(self, context):
        node = get_active_ypaint_node()
        tree = node.node_tree
        yp = tree.yp

        for layer in yp.layers:
            layer_tree = get_tree(layer)

            for prop in dir(layer):
                if prop.startswith('cache_'):
                    remove_node(layer_tree, layer, prop)

            for ch in layer.channels:
                for prop in dir(ch):
                    if prop.startswith('cache_'):
                        remove_node(layer_tree, ch, prop)

            for mask in layer.masks:
                for prop in dir(mask):
                    if prop.startswith('cache_'):
                        remove_node(layer_tree, mask, prop)

        # Remove tangent and bitangent images
        for image in reversed(bpy.data.images):
            if image.name.endswith(CACHE_TANGENT_IMAGE_SUFFIX) or image.name.endswith(CACHE_BITANGENT_IMAGE_SUFFIX):
                remove_datablock(bpy.data.images, image)

        return {'FINISHED'}

def update_channel_name(self, context):
    T = time.time()

    wm = context.window_manager
    group_tree = self.id_data
    yp = group_tree.yp

    if yp.halt_reconnect or yp.halt_update:
        return

    # Make sure there's no duplicate name
    if any([ch for ch in yp.channels if ch != self and self.name == ch.name]):
        self.halt_update = True
        self.name = get_unique_name(self.name, yp.channels)
        self.halt_update = False

    # Update bake target channel name
    for bt in yp.bake_targets:
        for letter in rgba_letters:
            btc = getattr(bt, letter)
            if btc.channel_name != '' and btc.channel_name == self.original_name:
                btc.channel_name  = self.name

    input_index = get_tree_input_index_by_name(group_tree, self.original_name)
    output_index = get_tree_output_index_by_name(group_tree, self.original_name)

    # Update channel's original name
    self.original_name = self.name

    get_tree_input_by_index(group_tree, input_index).name = self.name
    get_tree_output_by_index(group_tree, output_index).name = self.name

    input_shift = 1
    output_shift = 1
    if self.enable_alpha:
        get_tree_input_by_index(group_tree, input_index+input_shift).name = self.name + io_suffix['ALPHA']
        input_shift += 1

        get_tree_output_by_index(group_tree, output_index+output_shift).name = self.name + io_suffix['ALPHA']

    if self.special_type == 'HEIGHT':
        if self.use_height_normalize:
            get_tree_input_by_index(group_tree, input_index+input_shift).name = self.name + io_suffix['SCALE']
            input_shift += 1

            get_tree_output_by_index(group_tree, output_index+output_shift).name = self.name + io_suffix['MIDLEVEL']
            output_shift += 1

            get_tree_output_by_index(group_tree, output_index+output_shift).name = self.name + io_suffix['SCALE']
            output_shift += 1

    for layer in yp.layers:
        tree = get_tree(layer)
        check_all_layer_channel_io_and_nodes(layer, tree)
        reconnect_layer_nodes(layer)
        rearrange_layer_nodes(layer)

        rearrange_layer_frame_nodes(layer, tree)
    
    rearrange_yp_frame_nodes(yp)
    reconnect_yp_nodes(group_tree)
    rearrange_yp_nodes(group_tree)

    print('INFO: Channel renamed in', '{:0.2f}'.format((time.time() - T) * 1000), 'ms!')
    wm.yptimer.time = str(time.time())

def update_sculpt_mode(self, context):
    reconnect_yp_nodes(self.id_data)
    rearrange_yp_nodes(self.id_data)

def update_active_yp_channel(self, context):
    ypup = get_user_preferences()
    obj = context.object
    tree = self.id_data
    yp = tree.yp
    if len(yp.channels) == 0: return
    ch = yp.channels[yp.active_channel_index]

    # Set the active preview mode channel
    # NOTE: Will only happens for non-popover channel settings UI
    if yp.preview_mode and (ypup.ui_non_popup_settings or not is_bl_newer_than(2, 80)):
        yp.preview_mode_channel_index = yp.active_channel_index

        # Update preview mode
        preview_mode.update_preview_mode(yp, context)

    # Also select bake target
    bt = yp.bake_targets.get(ch.bake_target_name)
    if bt:
        bt_idx = get_bake_target_index(bt)
        yp.active_bake_target_index = bt_idx

    # Set active baked image to paint slot
    set_active_paint_slot_entity(yp)

    if yp.use_baked:
        if obj.type == 'MESH':
            uv_layers = get_uv_layers(obj)

            baked_uv_map = uv_layers.get(yp.baked_uv_name)
            if baked_uv_map: 
                uv_layers.active = baked_uv_map
                # NOTE: Blender 2.90 or lower need to use active render so the UV in image editor paint mode is updated
                if not is_bl_newer_than(2, 91):
                    baked_uv_map.active_render = True

def update_layer_index(self, context):
    #T = time.time()
    scene = context.scene
    if hasattr(bpy.context, 'object'): obj = bpy.context.object
    elif is_bl_newer_than(2, 80): obj = bpy.context.view_layer.objects.active
    if not obj: return
    group_tree = self.id_data
    nodes = group_tree.nodes
    ypui = context.window_manager.ypui

    yp = self

    if (len(yp.layers) == 0 or yp.active_layer_index >= len(yp.layers) or yp.active_layer_index < 0): 
        set_image_paint_canvas(None)
        return

    # Set active node to be layer group node so active keyframe can be visible on fcurve
    for i, l in enumerate(yp.layers):
        layer_node = group_tree.nodes.get(l.group_node)
        if layer_node:
            if i == yp.active_layer_index:
                layer_node.select = True
                #group_tree.nodes.active = layer_node
            else: layer_node.select = False

    if is_layer_preview_mode_enabled(yp): preview_mode.update_preview_mode(yp, context)

    # Get active image and stuff
    image, uv_name, src_of_img, entity, mapping, vcol = get_active_image_and_stuffs(obj, yp)

    # Set active image to paint slot
    set_active_paint_slot_entity(yp)

    # Update active vertex color
    if vcol and get_active_vertex_color(obj) != vcol:
        set_active_vertex_color(obj, vcol)

    mat = get_active_material()
    objs = get_all_objects_with_same_materials(mat, selected_only=True)
    for ob in objs:
        refresh_temp_uv(ob, entity)

    #update_image_editor_image(context, image)

def update_channel_colorspace(self, context):

    group_tree = self.id_data
    yp = group_tree.yp
    nodes = group_tree.nodes

    # Check for modifier that aware of colorspace
    channel_index = -1
    for i, c in enumerate(yp.channels):
        if c == self:
            channel_index = i
            for mod in c.modifiers:

                if mod.type == 'RGB_TO_INTENSITY':
                    rgb2i = nodes.get(mod.rgb2i)
                    if self.colorspace == 'LINEAR':
                        rgb2i.inputs['Gamma'].default_value = 1.0
                    else: rgb2i.inputs['Gamma'].default_value = 1.0 / GAMMA

                if mod.type == 'COLOR_RAMP':

                    color_ramp_linear_start = nodes.get(mod.color_ramp_linear_start)
                    if color_ramp_linear_start:
                        if self.colorspace == 'SRGB':
                            color_ramp_linear_start.inputs[1].default_value = GAMMA
                        else: color_ramp_linear_start.inputs[1].default_value = 1.0

                    color_ramp_linear = nodes.get(mod.color_ramp_linear)
                    if color_ramp_linear:
                        if self.colorspace == 'SRGB':
                            color_ramp_linear.inputs[1].default_value = 1.0 / GAMMA
                        else: color_ramp_linear.inputs[1].default_value = 1.0

    for layer in yp.layers:
        ch = layer.channels[channel_index]
        tree = get_tree(layer)

        #Layer.set_layer_channel_linear_node(tree, layer, self, ch)
        check_layer_channel_linear_node(ch, layer, self, reconnect=True)

        # Change modifier colorspace only on image layer
        if layer.type == 'IMAGE':
            mod_tree = get_mod_tree(layer)

            for mod in layer.modifiers:

                if mod.type == 'RGB_TO_INTENSITY':
                    rgb2i = mod_tree.nodes.get(mod.rgb2i)
                    if self.colorspace == 'LINEAR':
                        rgb2i.inputs['Gamma'].default_value = 1.0
                    else: rgb2i.inputs['Gamma'].default_value = 1.0 / GAMMA

                if mod.type == 'OVERRIDE_COLOR':
                    oc = mod_tree.nodes.get(mod.oc)
                    if self.colorspace == 'LINEAR':
                        oc.inputs['Gamma'].default_value = 1.0
                    else: oc.inputs['Gamma'].default_value = 1.0 / GAMMA

                if mod.type == 'COLOR_RAMP':

                    color_ramp_linear_start = mod_tree.nodes.get(mod.color_ramp_linear_start)
                    if color_ramp_linear_start:
                        if self.colorspace == 'SRGB':
                            color_ramp_linear_start.inputs[1].default_value = GAMMA
                        else: color_ramp_linear_start.inputs[1].default_value = 1.0

                    color_ramp_linear = mod_tree.nodes.get(mod.color_ramp_linear)
                    if color_ramp_linear:
                        if self.colorspace == 'SRGB':
                            color_ramp_linear.inputs[1].default_value = 1.0 / GAMMA
                        else: color_ramp_linear.inputs[1].default_value = 1.0

        if ch.enable_transition_ramp:
            tr_ramp = tree.nodes.get(ch.tr_ramp)
            if tr_ramp:
                if self.colorspace == 'SRGB':
                    tr_ramp.inputs['Gamma'].default_value = 1.0 / GAMMA
                else: tr_ramp.inputs['Gamma'].default_value = 1.0

        if ch.enable_transition_ao:
            tao = tree.nodes.get(ch.tao)
            if tao:
                if self.colorspace == 'SRGB':
                    tao.inputs['Gamma'].default_value = 1.0 / GAMMA
                else: tao.inputs['Gamma'].default_value = 1.0

        for mod in ch.modifiers:

            if mod.type == 'RGB_TO_INTENSITY':
                rgb2i = tree.nodes.get(mod.rgb2i)
                if self.colorspace == 'LINEAR':
                    rgb2i.inputs['Gamma'].default_value = 1.0
                else: rgb2i.inputs['Gamma'].default_value = 1.0 / GAMMA

            if mod.type == 'OVERRIDE_COLOR':
                oc = tree.nodes.get(mod.oc)
                if self.colorspace == 'LINEAR':
                    oc.inputs['Gamma'].default_value = 1.0
                else: oc.inputs['Gamma'].default_value = 1.0 / GAMMA

            if mod.type == 'COLOR_RAMP':

                color_ramp_linear_start = tree.nodes.get(mod.color_ramp_linear_start)
                if color_ramp_linear_start:
                    if self.colorspace == 'SRGB':
                        color_ramp_linear_start.inputs[1].default_value = GAMMA
                    else: color_ramp_linear_start.inputs[1].default_value = 1.0

                color_ramp_linear = tree.nodes.get(mod.color_ramp_linear)
                if color_ramp_linear:
                    if self.colorspace == 'SRGB':
                        color_ramp_linear.inputs[1].default_value = 1.0 / GAMMA
                    else: color_ramp_linear.inputs[1].default_value = 1.0

    check_start_end_root_ch_nodes(group_tree, self)

    if not yp.halt_reconnect:
        reconnect_yp_nodes(group_tree)
        rearrange_yp_nodes(group_tree)

def update_enable_smooth_bump(self, context):
    yp = self.id_data.yp

    # Update channel io
    check_all_channel_ios(yp)

    # Clean unused libraries
    lib.clean_unused_libraries()

def update_channel_parallax(self, context):
    yp = self.id_data.yp

    # Update channel io
    check_all_channel_ios(yp)

#def update_displacement_height_ratio(self, context):
#
#    group_tree = self.id_data
#    yp = group_tree.yp
#
#    max_height = self.displacement_height_ratio
#
#    baked_parallax = group_tree.nodes.get(BAKED_PARALLAX)
#    if baked_parallax:
#        baked_parallax.inputs['depth_scale'].default_value = max_height
#
#    parallax = group_tree.nodes.get(PARALLAX)
#    if parallax:
#        depth_source_0 = parallax.node_tree.nodes.get('_depth_source_0')
#        if depth_source_0:
#            pack = depth_source_0.node_tree.nodes.get('_normalize')
#            if pack:
#                if max_height != 0.0:
#                    pack.inputs['Max Height'].default_value = max_height
#                else: pack.inputs['Max Height'].default_value = 1.0
#
#        end_linear = group_tree.nodes.get(self.end_linear)
#        if end_linear:
#            if max_height != 0.0:
#                end_linear.inputs['Max Height'].default_value = max_height
#            else: end_linear.inputs['Max Height'].default_value = 1.0
#
#            if self.enable_smooth_bump:
#                end_linear.inputs['Bump Height Scale'].default_value = get_fine_bump_distance(max_height)
#
#    for uv in yp.uvs:
#        parallax_prep = group_tree.nodes.get(uv.parallax_prep)
#        if parallax_prep:
#            parallax_prep.inputs['depth_scale'].default_value = max_height

#def update_parallax_samples(self, context):
#    group_tree = self.id_data
#    yp = group_tree.yp
#
#    parallax = group_tree.nodes.get(BAKED_PARALLAX)
#    if parallax:
#        set_relief_mapping_nodes(yp, parallax)
#
#        rearrange_relief_mapping_nodes(group_tree)
#        reconnect_relief_mapping_nodes(yp, parallax)

def update_parallax_rim_hack(self, context):
    group_tree = self.id_data
    yp = group_tree.yp

    #parallax = group_tree.nodes.get(BAKED_PARALLAX)
    #if parallax:
    #    try:
    #        parallax.inputs['Rim Hack'].default_value = 1.0 if self.parallax_rim_hack else 0.0
    #        parallax.inputs['Rim Hack Hardness'].default_value = self.parallax_rim_hack_hardness
    #    except: pass

    for uv in yp.uvs:
        parallax_prep = group_tree.nodes.get(uv.parallax_prep)
        if parallax_prep:
            parallax_prep.inputs['Rim Hack'].default_value = 1.0 if self.parallax_rim_hack else 0.0
            parallax_prep.inputs['Rim Hack Hardness'].default_value = self.parallax_rim_hack_hardness

def update_parallax_height_tweak(self, context):
    group_tree = self.id_data
    yp = group_tree.yp

    for uv in yp.uvs:
        parallax_prep = group_tree.nodes.get(uv.parallax_prep)
        if parallax_prep:
            parallax_prep.inputs['depth_scale'].default_value = get_displacement_max_height(self) * self.parallax_height_tweak

def update_parallax_num_of_layers(self, context):

    group_tree = self.id_data
    yp = group_tree.yp

    # Baked parallax
    #baked_parallax = group_tree.nodes.get(BAKED_PARALLAX)
    #if baked_parallax:
    #    set_baked_parallax_node(yp, baked_parallax)

    #    rearrange_parallax_layer_nodes(yp, baked_parallax)
    #    reconnect_baked_parallax_layer_nodes(yp, baked_parallax)

    if yp.use_baked:

        num_of_layers = int(self.baked_parallax_num_of_layers)

        baked_parallax = group_tree.nodes.get(BAKED_PARALLAX)
        if baked_parallax:
            loop = baked_parallax.node_tree.nodes.get('_parallax_loop')
            #create_delete_iterate_nodes(loop.node_tree, num_of_layers)
            #create_delete_iterate_nodes_(loop.node_tree, num_of_layers)
            create_delete_iterate_nodes__(loop.node_tree, num_of_layers)

            #rearrange_parallax_layer_nodes(yp, baked_parallax)
            #reconnect_parallax_layer_nodes(group_tree, baked_parallax, yp.baked_uv_name)
            rearrange_parallax_layer_nodes_(yp, baked_parallax)
            reconnect_parallax_layer_nodes__(group_tree, baked_parallax, yp.baked_uv_name)

            baked_parallax.inputs['layer_depth'].default_value = 1.0 / num_of_layers

    else:

        num_of_layers = int(self.parallax_num_of_layers)

        # Parallax
        parallax = group_tree.nodes.get(PARALLAX)
        if parallax:
            loop = parallax.node_tree.nodes.get('_parallax_loop')
            #create_delete_iterate_nodes(loop.node_tree, num_of_layers)
            #create_delete_iterate_nodes_(loop.node_tree, num_of_layers)
            create_delete_iterate_nodes__(loop.node_tree, num_of_layers)

            #rearrange_parallax_layer_nodes(yp, parallax)
            #reconnect_parallax_layer_nodes(group_tree, parallax)
            rearrange_parallax_layer_nodes_(yp, parallax)
            reconnect_parallax_layer_nodes__(group_tree, parallax)

            parallax.inputs['layer_depth'].default_value = 1.0 / num_of_layers

    for uv in yp.uvs:
        parallax_prep = group_tree.nodes.get(uv.parallax_prep)
        if parallax_prep:
            parallax_prep.inputs['layer_depth'].default_value = 1.0 / num_of_layers

def update_displacement_ref_plane(self, context):
    group_tree = self.id_data
    yp = group_tree.yp

    for uv in yp.uvs:
        parallax_prep = group_tree.nodes.get(uv.parallax_prep)
        if parallax_prep:
            parallax_prep.inputs['ref_plane'].default_value = self.parallax_ref_plane

def update_channel_alpha(self, context):
    mat = get_active_material()
    group_tree = self.id_data
    yp = group_tree.yp
    nodes = group_tree.nodes
    inputs = get_tree_inputs(group_tree)
    outputs = get_tree_outputs(group_tree)

    # Baked outside nodes
    frame = get_node(mat.node_tree, yp.baked_outside_frame) if mat else None
    tex = get_node(mat.node_tree, self.baked_outside, parent=frame) if mat else None

    # Shift fcurves
    if self.enable_alpha:
        shift_channel_fcurves(yp, get_channel_index(self), 'DOWN', remove_ch_mode=False)
    else: shift_channel_fcurves(yp, get_channel_index(self), 'UP', remove_ch_mode=False)

    # Check any alpha channels
    alpha_chs = []
    for ch in yp.channels:
        if ch.enable_alpha:
            alpha_chs.append(ch)

    if not self.enable_alpha:

        if yp.alpha_auto_setup and not any(alpha_chs) and mat:

            # Set material to use opaque (only for legacy renderer)
            if not is_bl_newer_than(4, 2):
                if is_bl_newer_than(2, 80):
                    mat.blend_method = 'OPAQUE'
                    mat.shadow_method = 'OPAQUE'
                else:
                    mat.game_settings.alpha_blend = 'OPAQUE'

        node = get_active_ypaint_node()
        inp = node.inputs.get(self.name + io_suffix['ALPHA']) if node else None
        outp = None

        if yp.use_baked and yp.enable_baked_outside and tex:
            outp = tex.outputs[1]
        elif node:
            outp = node.outputs.get(self.name + io_suffix['ALPHA'])

        # Remember the connections
        if inp and len(inp.links) > 0:
            self.ori_alpha_from.node = inp.links[0].from_node.name
            self.ori_alpha_from.socket = inp.links[0].from_socket.name

        if outp:
            for link in outp.links:
                con = self.ori_alpha_to.add()
                con.node = link.to_node.name
                con.socket = link.to_socket.name

        # Remove connection for baked outside
        if yp.use_baked and yp.enable_baked_outside and tex and outp and mat:
            for l in outp.links:
                mat.node_tree.links.remove(link)

        # Try to reconnect input to output
        fn = mat.node_tree.nodes.get(self.ori_alpha_from.node) if mat else None
        if fn:
            fs = fn.outputs.get(self.ori_alpha_from.socket)
            if fs:
                for oat in self.ori_alpha_to:
                    n = mat.node_tree.nodes.get(oat.node)
                    if not n: continue
                    s = n.inputs.get(oat.socket)
                    if not s: continue

                    mat.node_tree.links.new(fs, s)

    # Update channel io
    check_all_channel_ios(yp)

    if self.enable_alpha:

        if yp.alpha_auto_setup and any(alpha_chs) and mat:

            if is_bl_newer_than(4, 2):
                # Settings for eevee next
                mat.use_transparent_shadow = True

            elif is_bl_newer_than(2, 80):
                # Settings for eevee legacy
                mat.blend_method = self.alpha_blend_mode
                mat.shadow_method = self.alpha_shadow_mode
            else:
                # Set material to use alpha blend
                mat.game_settings.alpha_blend = 'ALPHA'

        # Get alpha index
        alpha_name = self.name + io_suffix['ALPHA']

        # Set node default_value
        node = get_active_ypaint_node()
        node.inputs[alpha_name].default_value = self.ori_alpha_value

        alpha_connected = False

        # Try to relink to original connections
        tree = mat.node_tree if mat else None
        if tree:
            try:
                node_from = tree.nodes.get(self.ori_alpha_from.node)
                socket_from = node_from.outputs[self.ori_alpha_from.socket]
                tree.links.new(socket_from, node.inputs[alpha_name])
            except: pass

            for con in self.ori_alpha_to:
                node_to = tree.nodes.get(con.node)
                if not node_to: continue
                socket_to = node_to.inputs.get(con.socket)
                if not socket_to: continue
                if len(socket_to.links) < 1:
                    if yp.use_baked and yp.enable_baked_outside and tex:
                        mat.node_tree.links.new(tex.outputs[1], socket_to)
                    else:
                        tree.links.new(node.outputs[alpha_name], socket_to)
                    alpha_connected = True

        # Try to connect alpha without prior memory
        if yp.alpha_auto_setup and not alpha_connected:
            channel_common.do_alpha_setup(mat, node, self)

        # Reset memory
        self.ori_alpha_from.node = ''
        self.ori_alpha_from.socket = ''
        self.ori_alpha_to.clear()

    yp.refresh_tree = True

def update_channel_alpha_pair_name(self, context):
    yp = self.id_data.yp
    
    if yp.halt_update: return

    if self.alpha_pair_name == self.name:
        yp.halt_update = True
        self.alpha_pair_name = ''
        yp.halt_update = False

    check_all_channel_ios(yp)

def update_channel_alpha_blend_mode(self, context):
    mat = get_active_material()
    group_tree = self.id_data
    yp = group_tree.yp

    if not self.enable_alpha or not is_bl_newer_than(2, 80): return

    # Set material alpha blend
    mat.blend_method = self.alpha_blend_mode
    mat.shadow_method = self.alpha_shadow_mode

#def update_disable_quick_toggle(self, context):
#    yp = self
#
#    for layer in yp.layers:
#        Layer.update_layer_enable(layer, context)
#
#        for mod in layer.modifiers:
#            Modifier.update_modifier_enable(mod, context)
#
#        for ch in layer.channels:
#            for mod in ch.modifiers:
#                Modifier.update_modifier_enable(mod, context)
#
#        for mask in layer.masks:
#            Mask.update_layer_mask_enable(mask, context)
#
#    for ch in yp.channels:
#        for mod in ch.modifiers:
#            Modifier.update_modifier_enable(mod, context)

def update_flip_backface(self, context):

    yp = self
    group_tree = yp.id_data

    for ch in yp.channels:
        baked_normal_flip = group_tree.nodes.get(ch.baked_normal_flip)
        if baked_normal_flip:
            set_normal_backface_flip(baked_normal_flip, yp.enable_backface_always_up)

        baked_normal_prep = group_tree.nodes.get(ch.baked_normal_prep)
        if baked_normal_prep:
            baked_normal_prep.inputs['Backface Always Up'].default_value = 1.0 if yp.enable_backface_always_up else 0.0

    for uv in yp.uvs:
        #tangent_flip = group_tree.nodes.get(uv.tangent_flip)
        #if tangent_flip:
        #    set_tangent_backface_flip(tangent_flip, yp.enable_backface_always_up)

        #bitangent_flip = group_tree.nodes.get(uv.bitangent_flip)
        #if bitangent_flip:
        #    set_bitangent_backface_flip(bitangent_flip, yp.enable_backface_always_up)

        tangent_process = group_tree.nodes.get(uv.tangent_process)
        if tangent_process:
            tangent_process.inputs['Backface Always Up'].default_value = 1.0 if yp.enable_backface_always_up else 0.0

def update_channel_use_clamp(self, context):

    if self.special_type in {'NORMAL', 'HEIGHT', 'VDISP'}: return

    group_tree = self.id_data
    check_start_end_root_ch_nodes(group_tree, self)

    reconnect_yp_nodes(group_tree)
    rearrange_yp_nodes(group_tree)

def update_channel_disable_global_baked(self, context):
    root_ch = self
    group_tree = self.id_data
    yp = group_tree.yp

    normal_ch, height_ch = get_normal_height_ch_pairs(yp)

    if yp.use_baked and root_ch == height_ch and not height_ch.use_height_as_bump:
        check_all_channel_ios(group_tree.yp)
        connect_outside_displacement_node(yp, root_ch, get_active_ypaint_node())
    else:
        reconnect_yp_nodes(group_tree)
        rearrange_yp_nodes(group_tree)

def update_backface_mode(self, context):
    yp = self.id_data.yp

    check_all_channel_ios(yp)

def update_channel_main_uv(self, context):
    yp = self.id_data.yp

    if self.main_uv in {TEMP_UV, ''} and len(yp.uvs) > 0:
        for uv in yp.uvs:
            self.main_uv = uv.name
            break

def update_enable_height_tweak(self, context):
    check_start_end_root_ch_nodes(self.id_data)

    reconnect_yp_nodes(self.id_data)
    rearrange_yp_nodes(self.id_data)

def update_use_linear_blending(self, context):
    modifier_common.check_yp_modifier_linear_nodes(self)
    check_start_end_root_ch_nodes(self.id_data)
    check_yp_linear_nodes(self)

    if is_layer_preview_mode_enabled(self):
        preview_mode.update_preview_mode(self, context)

    reconnect_yp_nodes(self.id_data)
    rearrange_yp_nodes(self.id_data)

class YNodeConnections(bpy.types.PropertyGroup):
    node : StringProperty(default='')
    socket : StringProperty(default='')
    socket_index : IntProperty(default=-1)
    original_value : FloatProperty(default=0.0)

class YPaintChannel(bpy.types.PropertyGroup):
    name : StringProperty(
        name = 'Channel Name', 
        description = 'Name of the channel',
        default = 'Albedo',
        update = update_channel_name,
    )

    original_name : StringProperty(
        name = 'Original Channel Name',
        description = 'Original channel name for updating',
        default = ''
    )

    type : EnumProperty(
        name = 'Channel Type',
        items = (
            ('VALUE', 'Value', ''),
            ('RGB', 'RGB', ''),
            #('NORMAL', 'Normal', ''), # Deprecated
            ('VECTOR', 'Vector', '')
        ),
        default = 'RGB'
    )

    enable_smooth_bump : BoolProperty(
        name = 'Enable Smooth Bump',
        description = 'Enable smooth bump map.\nLooks better but bump height scaling will be different than standard bump map.\nSmooth bump map -> Texture space.\nStandard bump map -> World space',
        default = True,
        update = update_enable_smooth_bump
    )

    use_clamp : BoolProperty(
        name = 'Use Clamp',
        description = 'Clamp result to 0..1 range.\nDisabling this will make the baked channel uses float image',
        default = True,
        update = update_channel_use_clamp
    )

    # Input output index
    io_index : IntProperty(default=-1)

    # Alpha for transparent materials

    # Deprecated
    enable_alpha : BoolProperty(
        name = 'Enable Alpha Blend on Channel',
        description = 'Enable alpha blend on channel',
        default = False,
        update = update_channel_alpha
    )

    # Depcrecated
    is_alpha : BoolProperty(
        name = 'Is Alpha Channel',
        description = 'Is channel an alpha channel',
        default=False
    )

    special_type : EnumProperty(
        name = 'Special Channel Type',
        description = 'Special channel type',
        items = (
            ('NONE', 'None', 'Not a special channel'),
            ('ALPHA', 'Alpha', 'Alpha channel for transparency (can be paired with color channel)'),
            ('NORMAL', 'Normal', 'Normal channel (has special blending mode and outputs object space normal)'),
            ('HEIGHT', 'Height', 'Height channel for bump or displacement (can be paired with normal channel)'),
            ('VDISP', 'Vector Displacement', 'Vector displacement channel (can be paired with normal channel)'),
        ),
        default = 'NONE',
    )

    alpha_pair_name : StringProperty(
        name = 'Alpha Channel Pair',
        description = 'Color channel pair for alpha channel',
        default='',
        update = update_channel_alpha_pair_name
    )

    alpha_combine_to_baked_color : BoolProperty(
        name = 'Combine Alpha to Baked Color',
        description = 'Combine bake result of color and alpha channel',
        default = True
    )

    alpha_blend_mode : EnumProperty(
        name = 'Alpha Blend Mode',
        description = 'This will change your material blend mode if alpha is enabled',
        items = (
            ('CLIP', 'Alpha Clip', ''),
            ('HASHED', 'Alpha Hashed', ''),
            ('BLEND', 'Alpha Blend', ''),
        ),
        default = 'HASHED',
        update = update_channel_alpha_blend_mode
    )

    alpha_shadow_mode : EnumProperty(
        name = 'Alpha Shadow Mode',
        description = 'This will change your material shadow mode if alpha is enabled',
        items = (
            ('NONE', 'None', ''),
            ('OPAQUE', 'Opaque', ''),
            ('HASHED', 'Alpha Hashed', ''),
            ('CLIP', 'Alpha Clip', ''),
        ),
        default = 'HASHED',
        update = update_channel_alpha_blend_mode
    )

    use_height_as_bump : BoolProperty(
        name = 'Use Height as Bump',
        description = 'Use final height as bump normal rather than displacement.\nNote: Need normal channel to work.',
        default=False,
        update=update_channel_use_height_as_bump
    )

    use_height_normalize : BoolProperty(
        name = 'Normalize height output',
        description = 'Normalize height to 0..1 range. Height Midlevel and Scale socket will available to access if this enabled',
        default=False,
        update=update_channel_use_height_normalize
    )

    # Backface mode for alpha
    backface_mode : EnumProperty(
        name = 'Backface Mode',
        description = 'Backface mode',
        items = (
            ('BOTH', 'Both', ''),
            ('FRONT_ONLY', 'Front Only / Backface Culling', ''),
            ('BACK_ONLY', 'Back Only', ''),
        ),
        default = 'BOTH',
        update = update_backface_mode
    )

    enable_bake_to_vcol : BoolProperty(
        name = 'Enable Bake to '+get_vertex_color_label(),
        description = 'Enable '+get_vertex_color_label(00)+' as bake target',
        default = False,
        update = Bake.update_enable_bake_to_vcol
    )

    use_baked_vcol : BoolProperty(
        name = 'Use Baked '+get_vertex_color_label(),
        description = 'Use baked '+get_vertex_color_label(00),
        default = False,
        update = Bake.update_enable_bake_to_vcol
    )

    bake_to_vcol_alpha : BoolProperty(
        name = 'Bake To '+get_vertex_color_label()+' Alpha', 
        description = 'When enabled, the channel are baked only to Alpha with '+get_vertex_color_label(00), 
        default = False
    )

    bake_to_vcol_name : StringProperty(
        name = 'Target '+get_vertex_color_label()+' Name',
        description = 'Target '+get_vertex_color_label(00)+' name',
        default = '',
    )

    # Unconnected warning
    disable_unconnected_warning : BoolProperty(
        name = 'Ignore Unconnected Warning',
        description = 'Disable warning popup on this channel if it is not connected to main shader node',
        default = False
    )

    # Displacement for normal channel
    enable_parallax : BoolProperty(
        name = 'Enable Parallax Mapping',
        description = 'Enable Parallax Mapping.\nIt will use texture space scaling, so it may looks different when using it as real displacement map',
        default = False,
        update = update_channel_parallax
    )

    parallax_num_of_layers : EnumProperty(
        name = 'Parallax Mapping Number of Layers',
        description = 'Parallax Mapping Number of Layers',
        items = (
            ('4', '4', ''),
            ('8', '8', ''),
            ('16', '16', ''),
            ('24', '24', ''),
            ('32', '32', ''),
            ('64', '64', ''),
            ('96', '96', ''),
            ('128', '128', ''),
        ),
        default = '8',
        update = update_parallax_num_of_layers
    )

    baked_parallax_num_of_layers : EnumProperty(
        name = 'Baked Parallax Mapping Number of Layers',
        description = 'Baked Parallax Mapping Number of Layers',
        items = (
            ('4', '4', ''),
            ('8', '8', ''),
            ('16', '16', ''),
            ('24', '24', ''),
            ('32', '32', ''),
            ('64', '64', ''),
            ('96', '96', ''),
            ('128', '128', ''),
            ('192', '192', ''),
            ('256', '256', ''),
        ),
        default = '32',
        update = update_parallax_num_of_layers
    )

    disable_global_baked : BoolProperty(
        name = 'Disable Global Baked', 
        description = 'Disable baked image for this channel if global baked is on',
        default = False,
        update = update_channel_disable_global_baked
    )

    #use_baked : BoolProperty(
    #        name = 'Use Baked Image', 
    #        description = 'Use baked image for this channel',
    #        default=False)

    #parallax_num_of_binary_samples : IntProperty(default=5, min=4, max=64,
    #        update=update_parallax_samples)

    # To mark if channel needed to be baked or not
    no_layer_using : BoolProperty(default=True)

    parallax_rim_hack : BoolProperty(
        default = False, 
        update = update_parallax_rim_hack
    )

    parallax_rim_hack_hardness : FloatProperty(
        default=1.0, min=1.0, max=100.0, 
        update = update_parallax_rim_hack
    )

    parallax_height_tweak : FloatProperty(
        subtype = 'FACTOR',
        default=1.0, min=0.0, max=1.0,
        update = update_parallax_height_tweak
    )

    # Currently unused
    parallax_ref_plane : FloatProperty(
        subtype = 'FACTOR',
        default=0.5, min=0.0, max=1.0,
        update = update_displacement_ref_plane
    )

    # Real displacement using height map
    enable_subdiv_setup : BoolProperty(
        name = 'Enable Displacement Setup',
        description = 'Enable displacement setup. Only works with Cycles or Eevee Next.',
        default = False,
        #update = Bake.update_enable_subdiv_setup
    ) # Deprecated

    #subdiv_standard_type : EnumProperty(
    #        name = 'Subdivision Standard Type',
    #        description = 'Subdivision Standard Type',
    #        items = (
    #            ('CATMULL_CLARK', 'Catmull-Clark', ''),
    #            ('SIMPLE', 'Simple', ''),
    #            ),
    #        default = 'CATMULL_CLARK',
    #        update=Bake.update_subdiv_standard_type
    #        )

    subdiv_adaptive : BoolProperty(
        name = 'Use Adaptive Subdivision',
        description = 'Use Adaptive Subdivision (only works with Cycles)',
        default = False,
        update = Bake.update_subdiv_setup
    )
    
    subdiv_on_max_polys : IntProperty(
        name = 'Subdiv On Max Polygons',
        description = 'Max Polygons (in thousand) when displacement setup is on',
        default=1000, min=1, max=10000, 
        update = Bake.update_subdiv_max_polys
    )

    #subdiv_on_level : IntProperty(
    #        name = 'Subdiv On Level',
    #        description = 'Subdivision level when displacement setup is on',
    #        default=3, min=0, max=10, 
    #        update=Bake.update_subdiv_on_off_level)

    #subdiv_off_level : IntProperty(
    #        name = 'Subdiv Off Level',
    #        description = 'Subdivision level when displacement setup is off',
    #        default=1, min=0, max=10, update=Bake.update_subdiv_on_off_level
    #        )

    # Depcrecated
    subdiv_tweak : FloatProperty(
        name = 'Subdiv Tweak',
        description = 'Tweak displacement height',
        default=1.0, min=-1000.0, max=1000.0
    )

    height_tweak : FloatProperty(
        name = 'Height Tweak',
        description = 'Multiply height value',
        default=1.0, min=-1000.0, max=1000.0
    )

    enable_height_tweak : BoolProperty(
        name = 'Height Tweak',
        description = 'Tweak displacement height',
        default = False,
        update = update_enable_height_tweak
    )

    enable_smooth_normal_tweak : BoolProperty(
        name = 'Smooth Normal Tweak',
        description = 'Tweak smooth normal',
        default = False,
        update = update_enable_height_tweak
    )

    smooth_normal_tweak : FloatProperty(
        name = 'Smooth Normal Tweak',
        description = 'Tweak smooth normal value',
        default=1.0, min=-1000.0, max=1000.0
    )

    subdiv_global_dicing : FloatProperty(
        subtype = 'PIXEL',
        default=1.0, min=0.5, max=1000,
        update = Bake.update_subdiv_global_dicing
    )

    subdiv_subsurf_only : BoolProperty(
        name = 'Use Subsurf Modifier Only',
        description = 'Ignore Multires and use subsurf modifier exclusively (useful if you already baked the multires to layer)',
        default = False,
        update = Bake.update_subdiv_setup
    )

    # Main uv is used for normal calculation of normal channel
    main_uv : StringProperty(
        name = 'Main Normal UV',
        description = "Main normal UV for tangent calculation",
        default = '', 
        update=update_channel_main_uv
    )

    colorspace : EnumProperty(
        name = 'Color Space',
        description = "Non-color won't be converted to linear first before blending",
        items = colorspace_items,
        default = 'LINEAR',
        update = update_channel_colorspace
    )

    modifiers : CollectionProperty(type=Modifier.YPaintModifier)
    active_modifier_index : IntProperty(default=0)

    bake_target_name : StringProperty(
        name = 'Bake Target Name',
        description = "Bake target name that will be used for the baked version of the channel",
        default=''
    )

    # Node names
    start_linear : StringProperty(default='')
    end_linear : StringProperty(default='')
    end_start_bump_overlay : StringProperty(default='')
    end_normal_engine_filter : StringProperty(default='')
    clamp : StringProperty(default='')
    start_normal_filter : StringProperty(default='')
    start_bump_process : StringProperty(default='')
    start_height_process : StringProperty(default='')
    bump_process : StringProperty(default='')
    end_height_normalize : StringProperty(default='')
    end_bump_process : StringProperty(default='')
    end_max_height : StringProperty(default='')
    end_max_height_tweak : StringProperty(default='')
    end_backface : StringProperty(default='')

    # Baked nodes
    baked : StringProperty(default='')
    baked_normal : StringProperty(default='')
    baked_normal_flip : StringProperty(default='')
    baked_normal_prep : StringProperty(default='')
    baked_vcol : StringProperty(default='')

    baked_disp : StringProperty(default='')
    baked_vdisp : StringProperty(default='')
    baked_normal_overlay : StringProperty(default='')
    baked_normal_no_disp : StringProperty(default='')

    baked_combine_xyz : StringProperty(default='')

    # Outside baked nodes
    baked_outside : StringProperty(default='') # Deprecated
    baked_outside_disp : StringProperty(default='') # Deprecated
    baked_outside_vdisp : StringProperty(default='') # Deprecated
    baked_outside_normal_overlay : StringProperty(default='') # Deprecated
    baked_outside_normal_no_disp : StringProperty(default='') # Deprecated

    baked_outside_disp_process : StringProperty(default='') # Deprecated
    baked_outside_vdisp_process : StringProperty(default='') # Deprecated
    baked_outside_disp_addition : StringProperty(default='') # Deprecated
    baked_outside_normal_process : StringProperty(default='') # Deprecated

    baked_outside_ori_disp_from_node : StringProperty(default='') # Deprecated
    baked_outside_ori_disp_from_socket : StringProperty(default='') # Deprecated

    baked_outside_vcol : StringProperty(default='') # Deprecated

    baked_combine_xyz_outside : StringProperty(default='')
    baked_normal_prep_outside : StringProperty(default='')
    baked_normal_outside : StringProperty(default='')

    # UI related
    expand_content : BoolProperty(default=True)
    expand_base_vector : BoolProperty(default=True)
    expand_subdiv_settings : BoolProperty(default=False)
    expand_parallax_settings : BoolProperty(default=False)
    expand_alpha_settings : BoolProperty(default=False)
    expand_bake_to_vcol_settings : BoolProperty(default=False)
    expand_input_bump_settings : BoolProperty(default=False)
    expand_smooth_bump_settings : BoolProperty(default=False)
    expand_baked_data : BoolProperty(default=False)

    # Connection related
    ori_alpha_to : CollectionProperty(type=YNodeConnections)
    ori_alpha_from : PointerProperty(type=YNodeConnections)

    ori_to : CollectionProperty(type=YNodeConnections)
    ori_midlevel_to : CollectionProperty(type=YNodeConnections)
    ori_scale_to : CollectionProperty(type=YNodeConnections)
    ori_height_to : CollectionProperty(type=YNodeConnections)
    ori_max_height_to : CollectionProperty(type=YNodeConnections)

    # Default value related
    ori_alpha_value : FloatProperty(default=0.0)
    ori_midlevel_value : FloatProperty(default=0.0)
    ori_max_height_value : FloatProperty(default=1.0)

class YPaintUV(bpy.types.PropertyGroup):
    name : StringProperty(default='')

    # Nodes
    uv_map : StringProperty(default='')
    tangent : StringProperty(default='')
    tangent_flip : StringProperty(default='')
    bitangent : StringProperty(default='')
    bitangent_flip : StringProperty(default='')
    tangent_process : StringProperty(default='')

    parallax_prep : StringProperty(default='')
    parallax_current_uv_mix : StringProperty(default='')
    parallax_current_uv : StringProperty(default='')
    parallax_delta_uv : StringProperty(default='')
    parallax_mix : StringProperty(default='')

    baked_parallax_current_uv_mix : StringProperty(default='')
    baked_parallax_current_uv : StringProperty(default='')
    baked_parallax_delta_uv : StringProperty(default='')
    baked_parallax_mix : StringProperty(default='')

    # For baking
    temp_tangent : StringProperty(default='')
    temp_bitangent : StringProperty(default='')

class YPaint(bpy.types.PropertyGroup, preview_mode.BasePreviewMode):

    is_ypaint_node : BoolProperty(default=False)
    is_ypaint_layer_node : BoolProperty(default=False)
    version : StringProperty(default='')
    blender_version : StringProperty(default='1.0.0')

    is_unstable : BoolProperty(
        name = 'Unstable Save Flag',
        description = 'Flag to check if the node saved using unstable (Alpha/Beta) version',
        default = False
    )

    # Channels
    channels : CollectionProperty(type=YPaintChannel)

    active_channel_index : IntProperty(
        name = 'Active Channel Index',
        description = 'Active channel index',
        default = 0,
        update = update_active_yp_channel
    )

    # Layers
    layers : CollectionProperty(type=Layer.YLayer)

    active_layer_index : IntProperty(
        name = 'Active Layer Index',
        description = 'Active layer index',
        default = 0,
        update = update_layer_index
    )

    # List Items
    list_items : CollectionProperty(type=ListItem.YListItem)

    active_item_index : IntProperty(
        name = 'Active Item Index',
        description = 'Active item index',
        default = 0,
        update = ListItem.update_list_item_index
    )

    enable_expandable_subitems : BoolProperty(
        name = 'Expandable Subitems',
        description = 'Subitems (masks and editable custom layer inputs) can have their own item entries',
        default = False,
        update = ListItem.update_expand_subitems
    )

    enable_inline_subitems : BoolProperty(
        name = 'Inline Subitems',
        description = 'Subitems (masks and editable custom layer inputs) will have their icons beside layer icon',
        default = True,
    )

    # UVs
    uvs : CollectionProperty(type=YPaintUV)

    # Bake Targets
    bake_targets : CollectionProperty(type=BakeTarget.YBakeTarget)

    active_bake_target_index : IntProperty(
        name = 'Active Bake Target Index',
        description = 'Active bake target index',
        default = 0,
        update = BakeTarget.update_active_bake_target_index
    )

    bake_target_global_settings : PointerProperty(type=BakeTarget.YBakeTargetGlobalSettings)

    # Disable all vector displacement layers when sculpt mode is on
    sculpt_mode : BoolProperty(default=False, update=update_sculpt_mode)

    # Toggle to use baked results or not
    use_baked : BoolProperty(
        default = False, 
        name = 'Use Baked',
        description = 'Use baked channels rather than layer channels',
        update = Bake.update_use_baked
    )

    baked_uv_name : StringProperty(default='')

    enable_baked_outside : BoolProperty(
        name = 'Enable Baked Outside',
        description = 'Create baked texture nodes outside of main node\n(Can be useful for exporting material to other application)',
        default = False,
        update = Bake.update_enable_baked_outside
    )
    
    # Outside nodes
    baked_outside_uv : StringProperty(default='')
    baked_outside_frame : StringProperty(default='')
    bake_target_outside_frame : StringProperty(default='')
    baked_outside_x_shift : IntProperty(default=0)

    # Flip backface
    enable_backface_always_up : BoolProperty(
        name = 'Make backface normal always up',
        description = 'Make sure normal will face toward camera even at backface\n(Need Normal channel with smooth bump on to enable this feature)',
        default = True,
        update = update_flip_backface
    )

    # Path folder for auto save bake
    #bake_folder : StringProperty(default='')

    # Disable quick toggle for better shader performance
    #disable_quick_toggle : BoolProperty(
    #        name = 'Disable Quick Toggle',
    #        description = 'Disable quick toggle to improve shader performance',
    #        default=False, update=update_disable_quick_toggle)

    enable_tangent_sign_hacks : BoolProperty(
        name = 'Enable Tangent Sign VCol Hacks for Blender 2.80+ Cycles',
        description = "Tangent sign "+get_vertex_color_label(00)+" needed to make sure Blender 2.8 Cycles normal and parallax works.\n(This is because Blender 2.8 normal map node has different behavior than Blender 2.7)",
        default = False,
        update = update_enable_tangent_sign_hacks
    )

    # When enabled, alpha can create some node setup and change material settings, disable this to avoid that
    alpha_auto_setup : BoolProperty(default=False)

    # HACK: Refresh tree to remove glitchy normal
    refresh_tree : BoolProperty(default=False)

    # Useful to suspend update when adding new stuff
    halt_update : BoolProperty(default=False)

    # Useful to suspend node rearrangements and reconnections when adding new stuff
    halt_reconnect : BoolProperty(default=False)

    # Remind user to refresh UV after edit image layer mapping
    need_temp_uv_refresh : BoolProperty(default=False)

    # Use linear color blending
    use_linear_blending : BoolProperty(
        name = 'Use Linear Color Blending',
        description = 'Use more accurate linear color blending (it will behave differently than Photoshop)',
        default = False,
        update = update_use_linear_blending
    )

    # Index pointer to the UI
    #ui_index : IntProperty(default=0)

    #random_prop : BoolProperty(default=False)

    # Trash node for collecting disabled nodes
    trash : StringProperty(default='')

class YPaintMaterialProps(bpy.types.PropertyGroup):
    ori_bsdf : StringProperty(default='')
    ori_bsdf_output_index : IntProperty(default=0)
    #ori_blend_method : StringProperty(default='')
    active_ypaint_node : StringProperty(default='')

    expand_content : BoolProperty(default=False)

class YPaintTimer(bpy.types.PropertyGroup):
    time : StringProperty(default='')

class YPaintCacheAnimatedTree(bpy.types.PropertyGroup):
    name : StringProperty(default='')

class YPaintWMProps(bpy.types.PropertyGroup):
    clipboard_tree : StringProperty(default='')
    clipboard_layer : StringProperty(default='')

    last_object : StringProperty(default='')
    last_material : StringProperty(default='')
    last_mode : StringProperty(default='')

    all_icons_loaded : BoolProperty(default=False)

    edit_image_editor_window_index : IntProperty(default=-1)
    edit_image_editor_area_index : IntProperty(default=-1)

    custom_srgb_name : StringProperty(default='')
    custom_noncolor_name : StringProperty(default='')

    test_result_run : IntProperty(default=0)
    test_result_error : IntProperty(default=0)
    test_result_failed : IntProperty(default=0)

    default_builtin_brush : StringProperty(default='')

    correct_paint_image_name : StringProperty(default='')

    clipboard_bake_target : CollectionProperty(type=BakeTarget.YBakeTarget)

    image_editor_dict : StringProperty(default='')
    image_editor_pins : StringProperty(default='')

    use_paint_slot_hacks : BoolProperty(default=False)
    halt_last_object_update : BoolProperty(default=False)

    cache_animated_trees : CollectionProperty(type=YPaintCacheAnimatedTree)

class YPaintSceneProps(bpy.types.PropertyGroup):
    ori_display_device : StringProperty(default='')
    ori_view_transform : StringProperty(default='')
    ori_exposure : FloatProperty(default=0.0)
    ori_gamma : FloatProperty(default=1.0)
    ori_look : StringProperty(default='')
    ori_use_curve_mapping : BoolProperty(default=False)
    ori_use_compositing : BoolProperty(default=False)
    ori_compositing_node_name : StringProperty(default='')

class YPaintObjectUVHash(bpy.types.PropertyGroup):
    name : StringProperty(default='')
    uv_hash : StringProperty(default='')

class YPaintObjectProps(bpy.types.PropertyGroup):
    ori_has_subsurf : BoolProperty(default=False)
    ori_subsurf_render_levels : IntProperty(default=1)
    ori_subsurf_levels : IntProperty(default=1)
    ori_subsurf_use_adapative : BoolProperty(default=False)

    ori_has_multires : BoolProperty(default=False)
    ori_multires_render_levels : IntProperty(default=1)
    ori_multires_levels : IntProperty(default=1)

    ori_mirror_offset_u : FloatProperty(default=0.0)
    ori_mirror_offset_v : FloatProperty(default=0.0)
    ori_offset_u : FloatProperty(default=0.0)
    ori_offset_v : FloatProperty(default=0.0)

    mesh_hash : StringProperty(default='')
    uv_hashes : CollectionProperty(type=YPaintObjectUVHash)

    texpaint_translation : FloatVectorProperty(size=3, default=(0.0, 0.0, 0.0))
    texpaint_rotation : FloatVectorProperty(size=3, default=(0.0, 0.0, 0.0))
    texpaint_scale : FloatVectorProperty(size=3, default=(1.0, 1.0, 1.0))

#class YPaintMeshProps(bpy.types.PropertyGroup):
#    parallax_scale_min : FloatProperty(default=0.0)
#    parallax_scale_span : FloatProperty(default=1.0)
#    parallax_curvature_min : FloatProperty(default=0.0)
#    parallax_curvature_span : FloatProperty(default=1.0)

@persistent
def ypaint_hacks_and_scene_updates(scene):
    # Get active yp node
    group_node = get_active_ypaint_node()
    if not group_node: return
    tree = group_node.node_tree
    yp = tree.yp

    # HACK: Refresh normal
    if yp.refresh_tree:
        # Just reconnect any connection twice to refresh normal
        for link in tree.links:
            from_socket = link.from_socket
            to_socket = link.to_socket
            tree.links.new(from_socket, to_socket)
            tree.links.new(from_socket, to_socket)
            break
        yp.refresh_tree = False

    # Check single user image layer
    if len(yp.layers) > 0:
        layer = yp.layers[yp.active_layer_index]

        if layer.type == 'IMAGE':
            source = get_layer_source(layer)
            img = source.image

            if img and img.name != layer.image_name:
                # Update active layer paint image
                layer.image_name = img.name
                yp.active_layer_index = yp.active_layer_index

@persistent
def ypaint_object_changes_update(scene):
    ypwm = bpy.context.window_manager.ypprops
    if ypwm.halt_last_object_update: return

    try: obj = bpy.context.object
    except: return
    if not obj: return

    mat = obj.active_material
    node = get_active_ypaint_node()
    yp = node.node_tree.yp if node else None

    if ypwm.last_object != obj.name or (mat and mat.name != ypwm.last_material):
        ypwm.last_object = obj.name
        if mat: ypwm.last_material = mat.name

        # NOTE: This code can causes context error with some file
        # Multiple materials will create temporary image in non-active materials
        # since it's the only way texture paint mode won't mess with other material image
        #check_other_mats_to_use_temp_image(obj)

        # Refresh layer index to update editor image
        if yp:
            if yp.use_baked and len(yp.channels) > 0:
                update_active_yp_channel(yp, bpy.context)

            elif len(yp.layers) > 0:
                try: set_active_paint_slot_entity(yp)
                except: print('EXCEPTIION: Cannot set image canvas!')

    # HACK: Remember original image editor images before entering texture paint mode
    if yp and obj.type == 'MESH' and obj.mode != 'TEXTURE_PAINT':
        editor_images, editor_pins = get_editor_images_dict(return_pins=True)
        ypwm.image_editor_dict = str(editor_images)
        ypwm.image_editor_pins = str(editor_pins)

    if obj.type == 'MESH' and ypwm.last_object == obj.name and ypwm.last_mode != obj.mode:

        if obj.mode == 'TEXTURE_PAINT' or ypwm.last_mode == 'TEXTURE_PAINT':

            # HACK: Set original image editor images since going into texture paint mode will replace all of them
            if yp and obj.mode == 'TEXTURE_PAINT' and ypwm.image_editor_dict != '':
                import ast
                editor_images = ast.literal_eval(ypwm.image_editor_dict)
                editor_pins = ast.literal_eval(ypwm.image_editor_pins) if ypwm.image_editor_pins != '' else {}
                set_editor_images(editor_images, editor_pins)

            ypwm.last_mode = obj.mode
            if yp and len(yp.layers) > 0:
                image, uv_name, src_of_img, entity, mapping, vcol = get_active_image_and_stuffs(obj, yp)

                # Store original uv mirror offsets
                if obj.mode == 'TEXTURE_PAINT':
                    mirror = get_first_mirror_modifier(obj)
                    if mirror:
                        try: 
                            obj.yp.ori_mirror_offset_u = mirror.mirror_offset_u
                            obj.yp.ori_mirror_offset_v = mirror.mirror_offset_v
                            if is_bl_newer_than(2, 80):
                                obj.yp.ori_offset_u = mirror.offset_u
                                obj.yp.ori_offset_v = mirror.offset_v
                        except: print('EXCEPTIION: Cannot remember original mirror offset!')

                # HACK: Just in case active image is not correct (Necessary for Blender 5.0 and lower)
                if image and not is_bl_newer_than(5, 1): 
                    ypwm.correct_paint_image_name = image.name

                # Set image editor image
                update_image_editor_image(bpy.context, image)

                # Refresh temporary UV
                refresh_temp_uv(obj, src_of_img)

        # Into edit mode
        if obj.mode == 'EDIT' and ypwm.last_mode != 'EDIT':
            ypwm.last_mode = obj.mode
            # Remember the space
            space, window_index, area_index = get_first_unpinned_image_editor_space(bpy.context, return_index=True)
            if space and area_index != -1 and window_index != -1:
                ypwm.edit_image_editor_window_index = window_index
                ypwm.edit_image_editor_area_index = area_index

            # Trigger updating active index to update image
            #if yp: 
            #    if yp.use_baked:
            #        yp.active_channel_index = yp.active_channel_index
            #    else: yp.active_layer_index = yp.active_layer_index

        # Out of edit mode
        if obj.mode != 'EDIT' and ypwm.last_mode == 'EDIT':
            ypwm.last_mode = obj.mode
            space = get_edit_image_editor_space(bpy.context)
            if space:
                space.use_image_pin = False
            ypwm.edit_image_editor_area_index = -1

            # Trigger updating active index to update image
            #if yp: 
            #    if yp.use_baked:
            #        yp.active_channel_index = yp.active_channel_index
            #    else: yp.active_layer_index = yp.active_layer_index

        if ypwm.last_mode != obj.mode:
            ypwm.last_mode = obj.mode

@persistent
def ypaint_missmatch_paint_slot_hack(scene):
    # HACK: Update material active slot when necessary
    wmyp = bpy.context.window_manager.ypprops
    if wmyp.use_paint_slot_hacks and wmyp.correct_paint_image_name != '':

        if scene.tool_settings.image_paint.mode == 'MATERIAL':

            mat = get_active_material()

            try: active_img = mat.texture_paint_images[mat.paint_active_slot]
            except: active_img = None

            try: correct_img = bpy.data.images.get(wmyp.correct_paint_image_name)
            except: correct_img = None

            if active_img and correct_img and active_img != correct_img:
                for idx, img in enumerate(mat.texture_paint_images):
                    if img == None: continue
                    if img.name == correct_img.name:

                        # HACK: Remember all original images in all image editors since setting canvas/paint slot will replace all of them
                        ori_editor_imgs, ori_editor_pins = get_editor_images_dict(return_pins=True)

                        success = False
                        try: 
                            mat.paint_active_slot = idx
                            success = True
                        except: print('EXCEPTIION: Cannot set active paint slot image!')

                        # HACK: Revert back to original editor images
                        if success: set_editor_images(ori_editor_imgs, ori_editor_pins)

                        break

        wmyp.correct_paint_image_name = ''
        wmyp.use_paint_slot_hacks = False

bus_owner = object()

def obj_changes_callback(*args):
    ypaint_object_changes_update(bpy.context.scene)

@persistent
def yp_load_msgbus_subscription(dummy):
    # Clear owner first
    bpy.msgbus.clear_by_owner(bus_owner) 

    keys = (
        (bpy.types.LayerObjects, "active"), # Active object changes
        (bpy.types.Object, "mode"), # Mode changes
        (bpy.types.Object, "active_material_index"), # Active material changes
    )

    # Subscribe to object changes update
    for key in keys:
        bpy.msgbus.subscribe_rna(key=key, owner=bus_owner, args=(), notify=obj_changes_callback)

def get_yp_animated_tree_names():
    wmyp = bpy.context.window_manager.ypprops

    animated_tree_names = []

    if any_yp_dot_fcurves():

        trees = [ng for ng in bpy.data.node_groups if hasattr(ng, 'yp') and ng.yp.is_ypaint_node and ng.animation_data and ng.animation_data.action]
        for tree in trees:
            fcs = get_datablock_fcurves(tree)
            fc_found = False
            for fc in fcs:
                if not fc.mute and fc.data_path.startswith('yp.'):
                    fc_found = True
                    break

            if fc_found:
                animated_tree_names.append(tree.name)

    return animated_tree_names

@persistent
def ypaint_playback_preparations(scene):
    wmyp = bpy.context.window_manager.ypprops

    # When animation is started playing, clear and repopulate all yp tress that has animation data
    wmyp.cache_animated_trees.clear()

    for tree_name in get_yp_animated_tree_names():
        at = wmyp.cache_animated_trees.add()
        at.name = tree_name

@persistent
def ypaint_force_update_on_anim(scene):
    wmyp = bpy.context.window_manager.ypprops
    ypup = get_user_preferences()

    # When the preference is enabled, always get the updated animated tree names rather than using caches on window manager
    if ypup.always_evaluate_frame:
        animated_tree_names = get_yp_animated_tree_names()
    else: animated_tree_names = [at.name for at in wmyp.cache_animated_trees]

    # Loop animated tree datas 
    for name in animated_tree_names:
        ng = bpy.data.node_groups.get(name)
        if not ng: continue
        fcs = get_datablock_fcurves(ng)
        for fc in fcs:
            if not fc.mute and fc.data_path.startswith('yp.'):

                # Get evaluated value
                val = fc.evaluate(scene.frame_current)

                # Get prop name
                m = re.match(r'(.+)\.(.+)$', fc.data_path)
                if m:
                    entity_path = m.group(1)
                    prop_name = m.group(2)
                else: 
                    entity_path = ''
                    prop_name = ''

                if type(ng.path_resolve(fc.data_path)) == str:

                    # Check if path is a string enum
                    if hasattr(ng.path_resolve(entity_path).bl_rna.properties[prop_name], 'enum_items'):
                        enum_items = ng.path_resolve(entity_path).bl_rna.properties[prop_name].enum_items

                        # NOTE: Dynamic enums can't be accesed using this
                        if len(enum_items) > 0:
                            val = enum_items[int(val)].identifier
                        else: continue

                    else: continue

                # Check if path is an array
                elif hasattr(ng.path_resolve(fc.data_path), '__len__'):
                    if ng.path_resolve(fc.data_path)[fc.array_index] != val:
                        ng.path_resolve(fc.data_path)[fc.array_index] = val
                    continue

                # Check if path is a boolean
                elif type(ng.path_resolve(fc.data_path)) == bool:
                    val = val == 1.0

                if ng.path_resolve(fc.data_path) != val and entity_path != '' and prop_name != '':
                    setattr(ng.path_resolve(entity_path), prop_name, val)

classes = (
    YSelectMaterialPolygons,
    YRenameUVMaterial,
    YQuickYPaintNodeSetup,
    YNewYPaintNode,
    YPaintNodeInputCollItem,
    YConnectYPaintChannel,
    YConnectYPaintChannelAlpha,
    YNewYPaintChannel,
    YSetChannelSpecialType,
    YAutoSetupNewYPaintChannel,
    YMoveYPaintChannel,
    YRemoveYPaintChannel,
    YAddSimpleUVs,
    YSwitchToMaterialView,
    YFixChannelMissmatch,
    YFixMissingUV,
    YRenameYPaintTree,
    YChangeActiveYPaintNode,
    YDuplicateYPNodes,
    YOptimizeNormalProcess,
    YFixMissingData,
    YRemoveMio3Checker,
    YRefreshTangentSignVcol,
    YRemoveYPaintNode,
    YCleanYPCaches,
    YNodeConnections,
    YPaintChannel,
    YPaintUV,
    YPaint,
    YPaintMaterialProps,
    YPaintTimer,
    YPaintCacheAnimatedTree,
    YPaintWMProps,
    YPaintSceneProps,
    YPaintObjectUVHash,
    YPaintObjectProps,
    #YPaintMeshProps,
)

def register():
    for cls in classes: bpy.utils.register_class(cls)

    # YPaint Props
    bpy.types.ShaderNodeTree.yp = PointerProperty(type=YPaint)
    bpy.types.Material.yp = PointerProperty(type=YPaintMaterialProps)
    bpy.types.WindowManager.yptimer = PointerProperty(type=YPaintTimer)
    bpy.types.WindowManager.ypprops = PointerProperty(type=YPaintWMProps)
    bpy.types.Scene.yp = PointerProperty(type=YPaintSceneProps)
    bpy.types.Object.yp = PointerProperty(type=YPaintObjectProps)
    #bpy.types.Mesh.yp = PointerProperty(type=YPaintMeshProps)

    # Handlers
    if is_bl_newer_than(2, 80):
        # Paint slot hack is no longer necessary with Blender 5.1
        if not is_bl_newer_than(5, 1):
            bpy.app.handlers.depsgraph_update_post.append(ypaint_missmatch_paint_slot_hack)
    else:
        bpy.app.handlers.scene_update_pre.append(ypaint_object_changes_update)
        bpy.app.handlers.scene_update_pre.append(ypaint_hacks_and_scene_updates)

    if is_bl_newer_than(3, 6):
        bpy.app.handlers.animation_playback_pre.append(ypaint_playback_preparations)

    bpy.app.handlers.frame_change_pre.append(ypaint_force_update_on_anim)

    if is_bl_newer_than(2, 80):
        # Msgbus Subscription
        yp_load_msgbus_subscription(None)
        bpy.app.handlers.load_post.append(yp_load_msgbus_subscription)

def unregister():
    for cls in classes: bpy.utils.unregister_class(cls)

    # Remove handlers
    if is_bl_newer_than(2, 80):
        if not is_bl_newer_than(5, 1):
            bpy.app.handlers.depsgraph_update_post.remove(ypaint_missmatch_paint_slot_hack)
    else:
        bpy.app.handlers.scene_update_pre.remove(ypaint_hacks_and_scene_updates)
        bpy.app.handlers.scene_update_pre.remove(ypaint_object_changes_update)

    if is_bl_newer_than(3, 6):
        bpy.app.handlers.animation_playback_pre.remove(ypaint_playback_preparations)

    bpy.app.handlers.frame_change_pre.remove(ypaint_force_update_on_anim)

    if is_bl_newer_than(2, 80):
        # Remove msgbus subscription
        bpy.msgbus.clear_by_owner(bus_owner) 
        bpy.app.handlers.load_post.remove(yp_load_msgbus_subscription)

