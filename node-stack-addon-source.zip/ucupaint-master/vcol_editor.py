import bpy, bmesh, numpy, time, os
from bpy.app.handlers import persistent
from mathutils import *
from pathlib import Path
from bpy.props import *
from .common import *

tex_default_brush_eraser_pairs = {
    'Paint Hard' : 'Erase Hard',
    'Paint Soft' : 'Erase Soft',
    'Paint Hard Pressure' : 'Erase Hard Pressure',
    'Smear' : 'Erase Soft',
    'Airbrush' : 'Erase Soft',
    'Paint Soft Pressure' : 'Erase Soft',
    'Paint Pixel Art' : 'Erase Pixel Art',
    'Clone' : 'Erase Hard',
    'Blur' : 'Erase Soft',
    'Fill' : 'Erase Hard',
    'Mask' : 'Erase Soft',
}

class YSetActiveVcol(bpy.types.Operator):
    bl_idname = "mesh.y_set_active_vcol"
    bl_label = "Set Active "+get_vertex_color_label()
    bl_description = "Set active "+get_vertex_color_label(00)
    bl_options = {'REGISTER', 'UNDO'}

    vcol_name : StringProperty(default='')

    @classmethod
    def poll(cls, context):
        return context.object and context.object.type == 'MESH'

    def execute(self, context):
        obj = context.object
        vcols = get_vertex_colors(obj)
        vcol = vcols.get(self.vcol_name)

        if vcol:
            set_active_vertex_color(obj, vcol)
            return {'FINISHED'}

        self.report({'ERROR'}, "There's no "+get_vertex_color_label(00)+" named " + self.vcol_name + '!')
        return {'CANCELLED'}

def activate_essential_brush(brush_name, essential_asset_identifier):
    try:
        bpy.ops.brush.asset_activate(
            asset_library_type = 'ESSENTIALS', 
            asset_library_identifier = '',
            relative_asset_identifier = essential_asset_identifier + os.sep + "Brush" + os.sep + brush_name
        )
        return True
    except Exception as e: print('EXCEPTIION:', e) 

    return False

def activate_local_brush(brush_name):
    try:
        bpy.ops.brush.asset_activate(
            asset_library_type = 'LOCAL', 
            asset_library_identifier = '', 
            relative_asset_identifier = 'Brush' + os.sep + brush_name
        )
        return True
    except Exception as e: print('EXCEPTIION:', e) 

    return False

def activate_custom_brush(brush_name, filepath):
    # Get asset library name and blend path
    asset_libraries = bpy.context.preferences.filepaths.asset_libraries
    library_name = ''
    blend_path = ''
    for al in asset_libraries:
        if filepath.startswith(al.path):
            library_name = al.name
            blend_path = str(filepath).replace(str(al.path) + os.sep, '')
            break

    try:
        bpy.ops.brush.asset_activate(
            asset_library_type = 'CUSTOM', 
            asset_library_identifier = library_name,
            relative_asset_identifier = blend_path + os.sep + "Brush" + os.sep + brush_name
        )
        return True
    except Exception as e: print('EXCEPTIION:', e) 

    return False

def activate_unknown_custom_brush(brush_name):
    asset_libraries = bpy.context.preferences.filepaths.asset_libraries

    # Look for brush in all asset libraries
    for asset_library in asset_libraries:
        library_name = asset_library.name
        library_path = Path(asset_library.path)
        blend_files = [fp for fp in library_path.glob("**/*.blend") if fp.is_file()]
        #print('INFO: Checking library', library_name, 'for brushes')
        for blend_file in blend_files:
            with bpy.data.libraries.load(str(blend_file), assets_only=True) as (file_contents, _):
                if brush_name in file_contents.brushes:
                    blend_path = str(blend_file).replace(str(library_path) + os.sep, '')
                    try:
                        bpy.ops.brush.asset_activate(
                            asset_library_type = 'CUSTOM', 
                            asset_library_identifier = library_name, 
                            relative_asset_identifier = blend_path + "\\Brush\\" + brush_name
                        )

                        return True
                    except Exception as e: print(e) 

    return False

def set_brush_asset(brush_name, mode='TEXTURE_PAINT'):
    # Get essential asset identifier path
    essential_asset_prefix = "brushes\\essentials_brushes-mesh_"
    mode_type = ''
    if mode == 'TEXTURE_PAINT': mode_type = 'texture'
    elif mode == 'VERTEX_PAINT': mode_type = 'vertex'
    elif mode == 'SCULPT': mode_type = 'sculpt'
    essential_asset_identifier = essential_asset_prefix + mode_type + ".blend"

    # Try to get brush from local data
    brush = bpy.data.brushes.get(brush_name)

    if not brush:
        # Look for essential brush
        activated = activate_essential_brush(brush_name, essential_asset_identifier)

        # Look for local brush
        if not activated:
            activated = activate_local_brush(brush_name)

        # Look for custom brush
        if not activated:
            activated = activate_unknown_custom_brush(brush_name)
    else:

        if brush.library and brush.library.name.startswith('essentials_'):
            # Essential brush
            activate_essential_brush(brush_name, essential_asset_identifier)
        elif not brush.library:
            # Local brush
            activate_local_brush(brush_name)
        else:
            # Custom brush
            activate_custom_brush(brush_name, brush.library.filepath)

def set_custom_eraser_brush_icon(eraser_brush):
    eraser_icon = 'eraser.png' #if is_bl_newer_than(2, 92) else 'eraser_small.png'
    filepath = get_addon_filepath() + os.sep + 'asset_icons' + os.sep + eraser_icon

    if is_bl_newer_than(2, 92):
        override = bpy.context.copy()
        override['id'] = eraser_brush
        if is_bl_newer_than(4):
            #with bpy.context.temp_override(id=eraser_brush):
            with bpy.context.temp_override(**override):
                bpy.ops.ed.lib_id_load_custom_preview(filepath=filepath)
        else: bpy.ops.ed.lib_id_load_custom_preview(override, filepath=filepath)
    else:
        eraser_brush.icon_filepath = filepath

    if not is_bl_newer_than(4, 3):
        eraser_brush.use_custom_icon = True

class YToggleEraser(bpy.types.Operator):
    bl_idname = "paint.y_toggle_eraser"
    bl_label = "Toggle Eraser Brush"
    bl_description = "Toggle eraser brush"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.object and context.object.type == 'MESH' and context.object.mode in {'VERTEX_PAINT', 'TEXTURE_PAINT', 'SCULPT'}

    def execute(self, context):

        ve = context.scene.ve_edit
        mode = context.object.mode
        wmyp = context.window_manager.ypprops

        # Blender 4.3+ texture paint will switch between available brush asset
        if mode == 'TEXTURE_PAINT' and is_bl_newer_than(4, 3):
            # Get current brush
            brush = context.tool_settings.image_paint.brush

            brush_name = brush.name
            image_tool = get_brush_image_tool(brush)
            use_pressure_strength = brush.use_pressure_strength
            use_pressure_size = brush.use_pressure_size

            # Get eraser name
            if brush.name not in tex_eraser_asset_names:

                if brush.name in tex_default_brush_eraser_pairs:
                    # Get eraser name based on dictionary
                    new_brush_name = tex_default_brush_eraser_pairs[brush.name]
                elif get_brush_image_tool(brush) == 'DRAW':
                    # Only toggle erase alpha if the draw brush is custom
                    new_brush_name = brush.name
                else: 
                    new_brush_name = 'Erase Soft'

                ve.ori_texpaint_brush = brush.name
                if brush.blend != 'ERASE_ALPHA':
                    ve.ori_texpaint_blending_mode = brush.blend

            # Get original brush name
            else:
                if ve.ori_texpaint_brush != '':
                    new_brush_name = ve.ori_texpaint_brush
                else: new_brush_name = 'Paint Soft'

            # Toggle 'Erase Alpha' if new brush is the same
            if brush.name == new_brush_name:
                if brush.blend == 'ERASE_ALPHA': 
                    brush.blend = ve.ori_texpaint_blending_mode if ve.ori_texpaint_blending_mode != '' else 'MIX'
                else: brush.blend = 'ERASE_ALPHA'
            else:

                # HACK: Set brush to 'builtin.brush' brush first before using non-draw brush
                # This is to avoid confusion since by default, if user go back to use 'Brush' tool, it will point to eraser brush
                new_brush = bpy.data.brushes.get(new_brush_name)
                if new_brush and get_brush_image_tool(new_brush) != 'DRAW':
                    if wmyp.default_builtin_brush != '':
                        set_brush_asset(wmyp.default_builtin_brush, mode)
                    else: set_brush_asset('Paint Soft', mode)

                # HACK: Remember what brush the last time used if user use non-draw brush
                if get_brush_image_tool(brush) != 'DRAW':
                    try: bpy.ops.wm.tool_set_by_id(name="builtin.brush")
                    except Exception as e: print('EXCEPTIION:', e)
                    brush = context.tool_settings.image_paint.brush
                    if brush and brush.name not in tex_eraser_asset_names and get_brush_image_tool(brush) == 'DRAW':
                        wmyp.default_builtin_brush = brush.name

                # Set brush asset
                set_brush_asset(new_brush_name, mode)

                # If original brush name in default erasers, make sure the new brush do not use erase alpha blending
                brush = context.tool_settings.image_paint.brush
                if brush_name in tex_eraser_asset_names and brush.blend == 'ERASE_ALPHA' and ve.ori_texpaint_blending_mode not in {'', 'ERASE_ALPHA'}:
                    brush.blend = ve.ori_texpaint_blending_mode 

            # HACK: Default 'Erase Soft' brush has use_pressure_strength turned off, so match it to the previous brush
            if new_brush_name == 'Erase Soft' and image_tool == 'DRAW':
                brush = context.tool_settings.image_paint.brush
                brush.use_pressure_strength = use_pressure_strength
                brush.use_pressure_size = use_pressure_size

            return {'FINISHED'}

        if mode == 'TEXTURE_PAINT':
            brush = context.tool_settings.image_paint.brush
            draw_brush_name = 'Paint Soft' if is_bl_newer_than(4, 3) else 'TexDraw'
            draw_brush = bpy.data.brushes.get(draw_brush_name)
        elif mode == 'VERTEX_PAINT' and is_bl_newer_than(2, 80): 
            brush = context.tool_settings.vertex_paint.brush
            draw_brush_name = 'Paint Soft' if is_bl_newer_than(4, 3) else 'Draw'
            draw_brush = bpy.data.brushes.get(draw_brush_name)
        elif mode == 'SCULPT' and is_bl_newer_than(3, 2): 
            brush = context.tool_settings.sculpt.brush
            draw_brush_name = 'Paint Blend' if is_bl_newer_than(4, 3) else 'Paint'
            draw_brush = bpy.data.brushes.get(draw_brush_name)

            # Sometime Blender 4.3+ need paint tool to be selected first
            if not draw_brush and is_bl_newer_than(4, 3):
                if ve.ori_sculpt_tool == '': 
                    ve.ori_sculpt_tool = get_active_tool_idname()
                bpy.ops.wm.tool_set_by_id(name="builtin_brush.paint")
                draw_brush = bpy.data.brushes.get(draw_brush_name)

            if not draw_brush:
                draw_brushes = [d for d in bpy.data.brushes if d.use_paint_sculpt and get_brush_sculpt_tool(d) == 'PAINT']
                if draw_brushes: draw_brush = draw_brushes[0]
                else:
                    self.report({'ERROR'}, "Cannot find a paint brush!")
                    return {'CANCELLED'}
        else:
            self.report({'ERROR'}, "There's no need to use this operator in this blender version!")
            return {'CANCELLED'}
        
        # Get eraser brush
        eraser_name = eraser_names[mode]
        eraser_brush = bpy.data.brushes.get(eraser_name)

        if not eraser_brush:
            if mode == 'SCULPT':
                eraser_brush = draw_brush.copy()
                eraser_brush.name = eraser_name
            else:
                eraser_brush = bpy.data.brushes.new(eraser_name, mode=mode)
            eraser_brush.blend = 'ERASE_ALPHA'

        # Mark eraser brush as asset for Blender 4.3+
        if is_bl_newer_than(4, 3) and not eraser_brush.asset_data:
            eraser_brush.asset_mark()
            set_custom_eraser_brush_icon(eraser_brush)

        # NOTE: Custom brush icon actually works on Blender 2.92+, 
        # but it can't save the icon to the blend file until Blender 3.6
        # I decided custom brush icon is only for Blender 4.3+ to avoid unknown behavior

        # Set eraser brush thumbnail
        #elif is_bl_newer_than(3, 6) and not eraser_brush.use_custom_icon:
        #    set_custom_eraser_brush_icon(eraser_brush)

        if brush == eraser_brush:

            if mode == 'VERTEX_PAINT':
                new_brush = bpy.data.brushes.get(ve.ori_brush)
            elif mode == 'TEXTURE_PAINT':
                new_brush = bpy.data.brushes.get(ve.ori_texpaint_brush)
            elif mode == 'SCULPT':
                new_brush = bpy.data.brushes.get(ve.ori_sculpt_brush)

            if new_brush: 
                if mode == 'VERTEX_PAINT':
                    new_brush.blend = ve.ori_blending_mode
                elif mode == 'TEXTURE_PAINT':
                    new_brush.blend = ve.ori_texpaint_blending_mode
                elif mode == 'SCULPT':
                    new_brush.blend = ve.ori_sculpt_blending_mode
            elif draw_brush:
                new_brush = draw_brush
                new_brush.blend = 'MIX'

            if mode == 'VERTEX_PAINT':
                ve.ori_brush = ''
                ve.ori_blending_mode = ''
            elif mode == 'TEXTURE_PAINT':
                ve.ori_texpaint_brush = ''
                ve.ori_texpaint_blending_mode = ''
            elif mode == 'SCULPT':
                if ve.ori_sculpt_tool != '': 
                    bpy.ops.wm.tool_set_by_id(name=ve.ori_sculpt_tool)
                ve.ori_sculpt_brush = ''
                ve.ori_sculpt_blending_mode = ''
                ve.ori_sculpt_tool = ''

        else:

            if mode == 'VERTEX_PAINT':
                ve.ori_brush = brush.name
                ve.ori_blending_mode = brush.blend
            elif mode == 'TEXTURE_PAINT':
                ve.ori_texpaint_brush = brush.name
                ve.ori_texpaint_blending_mode = brush.blend
            if mode == 'SCULPT':
                ve.ori_sculpt_brush = brush.name
                ve.ori_sculpt_blending_mode = brush.blend
                if is_bl_newer_than(4, 3): # and ve.ori_sculpt_tool == '': 
                    ve.ori_sculpt_tool = get_active_tool_idname()

            new_brush = eraser_brush

        if new_brush:
            if is_bl_newer_than(4, 3):
                set_brush_asset(new_brush.name, mode)
            else:
                if mode == 'TEXTURE_PAINT':
                    context.tool_settings.image_paint.brush = new_brush

                elif mode == 'VERTEX_PAINT': 
                    context.tool_settings.vertex_paint.brush = new_brush

                elif mode == 'SCULPT': 
                    context.tool_settings.sculpt.brush = new_brush

        return {'FINISHED'}

class YSelectFacesByVcol(bpy.types.Operator):
    bl_idname = "mesh.y_select_faces_by_vcol"
    bl_label = "Select Faces based on "+get_vertex_color_label()
    bl_description = "Select faces based on "+get_vertex_color_label(00)
    bl_options = {'REGISTER', 'UNDO'}

    color : FloatVectorProperty(
        name = 'Color',
        size = 4,
        subtype = 'COLOR',
        default = (1.0, 0.0, 1.0, 1.0),
        min=0.0, max=1.0,
    )

    #deselect : BoolProperty(
    #        name='Deselect Faces',
    #        description='Deselect faces with '+get_vertex_color_label(00), 
    #        default=False)

    @classmethod
    def poll(cls, context):
        obj = context.object
        if not obj or obj.type != 'MESH' or not any(get_vertex_colors(obj)): return False

        if is_bl_newer_than(3, 2):
            vcol = obj.data.color_attributes.active_color
            if not vcol or vcol.domain != 'CORNER':
                return False

        return obj.mode == 'EDIT'

    def execute(self, context):

        threshold = .004
        mat = context.object.active_material
        vcol_name = get_active_vertex_color(context.object).name
        target = Vector(linear_to_srgb(Color((self.color[0], self.color[1], self.color[2]))))

        if mat.users > 1 and is_bl_newer_than(2, 80):
            objs = get_all_objects_with_same_materials(mat, mesh_only=True)
        else: objs = [context.object]

        # Select the objects first
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action='DESELECT')
        for obj in objs:
            set_object_hide(obj, False)
            set_object_select(obj, True)
            
        # Reveal all hidden polygons
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.context.tool_settings.mesh_select_mode = (False, False, True)
        bpy.ops.mesh.reveal()

        # Select polygons based on target color
        for obj in objs:
            mesh = obj.data
            
            # Create bmesh from the object mesh
            bm = bmesh.from_edit_mesh(mesh)
            
            lcol = bm.loops.layers.color.get(vcol_name)
            if not lcol: continue
            
            # Select the faces
            for face in bm.faces:
                # Alpha is not considered for now
                face.select = any((Vector((l[lcol][0], l[lcol][1], l[lcol][2])) - target).length < threshold for l in face.loops)
            
            # Write changes back to the mesh
            bmesh.update_edit_mesh(mesh)
            
        return {'FINISHED'}

class YVcolFillFaceCustom(bpy.types.Operator):
    bl_idname = "mesh.y_vcol_fill_face_custom"
    bl_label = get_vertex_color_label()+" Fill Face with Custom Color"
    bl_description = "Fill selected polygon with "+get_vertex_color_label(00)+" with custom color"
    bl_options = {'REGISTER', 'UNDO'}

    color : FloatVectorProperty(
        name = 'Color ID',
        size = 4,
        subtype = 'COLOR',
        default = (1.0, 0.0, 1.0, 1.0),
        min=0.0, max=1.0,
    )

    @classmethod
    def poll(cls, context):
        obj = context.object
        if not obj or obj.type != 'MESH' or not any(get_vertex_colors(obj)): return False

        if is_bl_newer_than(3, 2):
            vcol = obj.data.color_attributes.active_color
            if not vcol or vcol.domain != 'CORNER':
                return False

        return obj.mode == 'EDIT'

    def execute(self, context):
        T = time.time()

        # Experiment with numpy
        use_numpy = True #is_bl_newer_than(2, 80)

        if is_bl_newer_than(2, 80):
            objs = context.objects_in_mode

            # Set the same vertex color for all objects first
            vcol = get_active_vertex_color(context.object)
            for obj in objs:
                vcols = get_vertex_colors(obj)
                vc = vcols.get(vcol.name)
                set_active_vertex_color(obj, vc)

        else: objs = [context.object]

        for obj in objs:

            mesh = obj.data
            bm = bmesh.from_edit_mesh(mesh)

            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            loop_indices = []
            for face in bm.faces:
                if face.select:
                    for loop in face.loops:
                        loop_indices.append(loop.index)

            bpy.ops.object.mode_set(mode='OBJECT')
            vcol = get_active_vertex_color(obj)

            if not vcol: 
                bpy.ops.object.mode_set(mode='EDIT')
                continue

            color = Color((self.color[0], self.color[1], self.color[2]))
            if not is_bl_newer_than(3, 2):
                color = linear_to_srgb(color)

            if is_bl_newer_than(2, 80):
                color = (color[0], color[1], color[2], self.color[3])

            # HACK: Sometimes color assigned are different so read the assigned color and write it back to mask color id
            if len(loop_indices) > 0:
                vcol.data[loop_indices[0]].color = color
                if any([color[i] for i in range(3) if color[i] != vcol.data[loop_indices[0]].color[i]]) and hasattr(context, 'mask'):
                    written_col = vcol.data[loop_indices[0]].color
                    color = (written_col[0], written_col[1], written_col[2])
                                
                    set_entity_prop_value(context.mask, 'color_id', Color(color))
                    if not is_bl_newer_than(3, 2):
                        set_entity_prop_value(context.mask, 'color_id', srgb_to_linear(get_mask_color_id_color(context.mask)))
                    if is_bl_newer_than(2, 80):
                        color = (written_col[0], written_col[1], written_col[2], written_col[3])

                # Blender 2.80+ has alpha channel on vertex color
                dimension = 4 if is_bl_newer_than(2, 80) else 3

                if use_numpy:
                    nvcol = numpy.zeros(len(vcol.data) * dimension, dtype=numpy.float32)
                    vcol.data.foreach_get('color', nvcol)
                    nvcol2D = nvcol.reshape(-1, dimension)
                    nvcol2D[loop_indices]= color    
                    vcol.data.foreach_set('color', nvcol)
                else :
                    for i, loop_index in enumerate(loop_indices):
                        vcol.data[loop_index].color = color

            bpy.ops.object.mode_set(mode='EDIT')

        print('VCOL: Fill Color ID is done in', '{:0.2f}'.format(time.time() - T), 'seconds!')

        return {'FINISHED'}

class YVcolFill(bpy.types.Operator):
    bl_idname = "mesh.y_vcol_fill"
    bl_label = get_vertex_color_label()+" Fill"
    bl_description = "Fill selected polygon with "+get_vertex_color_label(00)
    bl_options = {'REGISTER', 'UNDO'}

    color_option : EnumProperty(
        name = 'Color Option',
        description = 'Color Option',
        items = (
            ('WHITE', 'White', ''),
            ('BLACK', 'Black', ''),
            #('TRANSPARENT', 'Transparent', ''),
            ('CUSTOM', 'Custom', ''),
        ),
        default='WHITE'
    )

    @classmethod
    def poll(cls, context):
        obj = context.object
        if not obj or obj.type != 'MESH' or not any(get_vertex_colors(obj)): return False

        if is_bl_newer_than(3, 2):
            vcol = obj.data.color_attributes.active_color
            if not vcol or vcol.domain not in {'CORNER', 'POINT'}:
                return False

        return obj.mode == 'EDIT'

    def execute(self, context):
        T = time.time()

        # Experiment with numpy
        use_numpy = True #is_bl_newer_than(2, 80)

        if is_bl_newer_than(2, 80):
            objs = context.objects_in_mode
        else: objs = [context.object]

        if context.tool_settings.mesh_select_mode[0] or context.tool_settings.mesh_select_mode[1]:
            fill_mode = 'VERTEX'
        else: fill_mode = 'FACE'

        for obj in objs:

            mesh = obj.data
            ve = context.scene.ve_edit
            bm = bmesh.from_edit_mesh(mesh)

            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            loop_indices = []
            for face in bm.faces:
                if face.select:
                    for loop in face.loops:
                        loop_indices.append(loop.index)

            vert_indices = []
            for vert in bm.verts:
                if vert.select:
                    vert_indices.append(vert.index)

            bpy.ops.object.mode_set(mode='OBJECT')
            vcol = get_active_vertex_color(obj)

            if not vcol: 
                bpy.ops.object.mode_set(mode='EDIT')
                continue

            color = Color((ve.color[0], ve.color[1], ve.color[2]))
            alpha = context.scene.ve_edit.color[3]

            if self.color_option == 'WHITE':
                color = (1, 1, 1)
                alpha = 1.0
            elif self.color_option == 'BLACK':
                color = (0, 0, 0)
                alpha = 1.0
            elif not is_bl_newer_than(3, 2):
                color = linear_to_srgb(color)

            # Blender 2.80+ has alpha channel on vertex color
            dimension = 4 if is_bl_newer_than(2, 80) else 3
            if is_bl_newer_than(2, 80):
                color = (color[0], color[1], color[2], alpha)

            if is_bl_newer_than(3, 2) and vcol.domain == 'POINT':
                if use_numpy:
                    nvcol = numpy.zeros(len(vcol.data) * dimension, dtype=numpy.float32)
                    vcol.data.foreach_get('color', nvcol)
                    nvcol2D = nvcol.reshape(-1, dimension)
                    nvcol2D[vert_indices]= color
                    vcol.data.foreach_set('color', nvcol)
                else:
                    for vert_index in vert_indices:
                        vcol.data[vert_index].color = color
            else:
                if fill_mode == 'FACE':
                    if use_numpy:
                        nvcol = numpy.zeros(len(vcol.data) * dimension, dtype=numpy.float32)
                        vcol.data.foreach_get('color', nvcol)
                        nvcol2D = nvcol.reshape(-1, dimension)
                        nvcol2D[loop_indices]= color
                        vcol.data.foreach_set('color', nvcol)
                    else:                    
                        for loop_index in loop_indices:
                            vcol.data[loop_index].color = color
                else:
                    if use_numpy:
                        loop_to_vert = numpy.zeros(len(mesh.loops), dtype=numpy.uint32)
                        mesh.loops.foreach_get('vertex_index', loop_to_vert)
                        # Numpy in1d is deprecated since numpy version 2.0
                        if version_tuple(numpy.__version__) >= (2, 0, 0):
                            loop_indices = (numpy.isin(loop_to_vert, vert_indices)).nonzero()[0]
                        else: loop_indices = (numpy.in1d(loop_to_vert, vert_indices)).nonzero()[0]
                        nvcol = numpy.zeros(len(vcol.data) * dimension, dtype=numpy.float32)
                        vcol.data.foreach_get('color', nvcol)
                        nvcol2D = nvcol.reshape(-1, dimension)
                        nvcol2D[loop_indices] = color
                        vcol.data.foreach_set('color', nvcol)   
                    else:
                        for poly in mesh.polygons:
                            for loop_index in poly.loop_indices:
                                loop_vert_index = mesh.loops[loop_index].vertex_index
                                if loop_vert_index in vert_indices:
                                    vcol.data[loop_index].color = color

            bpy.ops.object.mode_set(mode='EDIT')

        print('VCOL: Fill '+get_vertex_color_label(00)+' is done in', '{:0.2f}'.format(time.time() - T), 'seconds!')

        return {'FINISHED'}

def vcol_editor_draw(self, context):
    obj = context.object
    mesh = obj.data
    ve = context.scene.ve_edit

    col = self.layout.column() #align=True)
    vcols = get_vertex_colors(obj)
    vcol = get_active_vertex_color(obj)

    #if len(vcols) == 0:
    #    col.label(text='No '+get_vertex_color_label(00)+' found!', icon='GROUP_VCOL')
    #    return

    row = col.row(align=True)

    if not ve.show_vcol_list:
        row.prop(ve, 'show_vcol_list', text='', emboss=False, icon='TRIA_RIGHT')
        if vcol: row.label(text='Active: ' + vcol.name)
        else: row.label(text='Active: -')
    else:
        row.prop(ve, 'show_vcol_list', text='', emboss=False, icon='TRIA_DOWN')
        row.label(text=get_vertex_color_label()+'s')

        row = col.row()
        rcol = row.column()
        if is_bl_newer_than(3, 2):
            rcol.template_list("MESH_UL_color_attributes", "vcols", mesh, 
                    "color_attributes", vcols, "active_color_index", rows=2)
            rcol = row.column(align=True)
            rcol.operator("geometry.color_attribute_add", icon='ADD', text="")
            rcol.operator("geometry.color_attribute_remove", icon='REMOVE', text="")
        else:
            if is_bl_newer_than(2, 80):
                rcol.template_list("MESH_UL_vcols", "vcols", mesh, 
                        "vertex_colors", vcols, "active_index", rows=3)
                rcol = row.column(align=True)
                rcol.operator("mesh.vertex_color_add", icon='ADD', text="")
                rcol.operator("mesh.vertex_color_remove", icon='REMOVE', text="")
            else:
                rcol.template_list("MESH_UL_uvmaps_vcols", "vcols", mesh, 
                        "vertex_colors", vcols, "active_index", rows=3)
                rcol = row.column(align=True)
                rcol.operator("mesh.vertex_color_add", icon='ZOOMIN', text="")
                rcol.operator("mesh.vertex_color_remove", icon='ZOOMOUT', text="")

    col.separator()

    ccol = col.column(align=True)
    ccol.operator("mesh.y_vcol_fill", icon='BRUSH_DATA', text='Fill with White').color_option = 'WHITE'
    ccol.operator("mesh.y_vcol_fill", icon='BRUSH_DATA', text='Fill with Black').color_option = 'BLACK'
    #if is_bl_newer_than(2, 80):
    #    ccol.operator("mesh.y_vcol_fill", icon='BRUSH_DATA', text='Fill with Black').color_option = 'TRANSPARENT'

    col.separator()
    ccol = col.column(align=True)
    ccol.operator("mesh.y_vcol_fill", icon='BRUSH_DATA', text='Fill with Color').color_option = 'CUSTOM'
    #col.separator()
    #col.template_color_picker(ve, 'color', value_slider=True)

    ccol.prop(ve, "color", text="")

    #col.separator()

    #row = col.row(align=True)
    #row.label(text='Mode:')
    #row.prop(ve, 'fill_mode', expand=True)

    #col.template_palette(ve, "palette", color=True)

class VIEW3D_PT_y_vcol_editor_ui(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_label = get_vertex_color_label()+" Editor"
    bl_context = "mesh_edit"
    bl_region_type = 'UI'
    bl_category = 'VCol Edit'
    #bl_options = {'DEFAULT_CLOSED'} 

    @classmethod
    def poll(cls, context):
        ypup = get_user_preferences()
        return ypup and (not hasattr(ypup, 'show_experimental') or ypup.show_experimental) and context.object and context.object.type == 'MESH'

    def draw(self, context):
        vcol_editor_draw(self, context)

class VIEW3D_PT_y_vcol_editor_tools(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_label = get_vertex_color_label()+" Editor"
    bl_context = "mesh_edit"
    bl_region_type = 'TOOLS'

    @classmethod
    def poll(cls, context):
        ypup = get_user_preferences()
        return ypup and (not hasattr(ypup, 'show_experimental') or ypup.show_experimental) and context.object and context.object.type == 'MESH'

    def draw(self, context):
        vcol_editor_draw(self, context)

class YVcolEditorProps(bpy.types.PropertyGroup):
    color : FloatVectorProperty(name='Color', size=4, subtype='COLOR', default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0)
    #palette : PointerProperty(type=bpy.types.Palette)

    show_vcol_list : BoolProperty(
        name = 'Show '+get_vertex_color_label()+' List',
        description = 'Show '+get_vertex_color_label(00)+' list',
        default = True
    )

    ori_blending_mode : StringProperty(default='')
    ori_brush : StringProperty(default='')

    ori_texpaint_blending_mode : StringProperty(default='')
    ori_texpaint_brush : StringProperty(default='')
    ori_texpaint_builtin_brush : StringProperty(default='')

    ori_sculpt_blending_mode : StringProperty(default='')
    ori_sculpt_brush : StringProperty(default='')
    ori_sculpt_tool : StringProperty(default='')

classes = [
    YVcolEditorProps,
    YVcolFill,
    YSelectFacesByVcol,
    YVcolFillFaceCustom,
    YToggleEraser,
    YSetActiveVcol,
    VIEW3D_PT_y_vcol_editor_ui,
]
if not is_bl_newer_than(2, 80):
    classes.append(VIEW3D_PT_y_vcol_editor_tools)

def register():
    for cls in classes: bpy.utils.register_class(cls)

    bpy.types.Scene.ve_edit = PointerProperty(type=YVcolEditorProps)

def unregister():
    for cls in classes: bpy.utils.unregister_class(cls)
